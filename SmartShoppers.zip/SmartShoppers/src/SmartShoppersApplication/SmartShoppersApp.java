package SmartShoppersApplication;

import java.io.IOException;

import GUI.LoginAndCreation.LandingPage;

public class SmartShoppersApp {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// Loading landing page
		LandingPage.main(null);
	}
}
