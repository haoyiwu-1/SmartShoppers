package SmartShoppers;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class CustomerAccount implements UserAccount, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7686078706470267472L;
	private String name;
	private String identifier;
	private String password;
	private Map<String, Store> savedStores;
	private String email;
	private Store prefStore;
	private Map<String, ShoppingList> savedShoppingLists;
	private boolean auth2;

	public CustomerAccount(String id, String password, String name, String email) {
		this.identifier = id;
		this.password = password;
		this.email = email;
		this.name = name;
		this.auth2 = false;
		savedStores = new HashMap<String, Store>();
		savedShoppingLists = new HashMap<String, ShoppingList>();
	}

	@Override
	public String getIdentifier() {
		return this.identifier;
	}

	@Override
	public void setIdentifier(String id) {
		this.identifier = id;
	}

	@Override
	public String getPassword() {
		return this.password;
	}

	@Override
	public void setPassword(String pass) {
		this.password = pass;
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String getEmail() {
		return this.email;
	}

	@Override
	public void setEmail(String email) {
		this.email = email;
	}

	public void addSavedStore(Store store) {
		this.savedStores.put(store.getId(), store);
	}

	public void removeSavedStore(Store store) {
		this.savedStores.remove(store.getId());
	}

	public void changePrefStore(Store store) {
		this.prefStore = store;
	}

	public String getPrefStore() {
		if (this.prefStore != null) {
			return this.prefStore.toString();
		} else {
			return "N/A";
		}
	}

	public String getSavedStoresString() {
		List<String> savedOnAcc = new ArrayList<String>();
		for (Entry<String, Store> entry : savedStores.entrySet()) {
			savedOnAcc.add(entry.getKey() + " - " + entry.getValue().getLocation());
		}
		if (savedOnAcc != null && savedOnAcc.size() > 0) {
			return savedOnAcc.toString();
		}
		return "No stores saved on this account.";
	}

	public List<String> getSavedStoreIds() {
		List<String> savedOnAcc = new ArrayList<String>();
		for (String id : this.savedStores.keySet()) {
			savedOnAcc.add(id);
		}
		return savedOnAcc;
	}

	public void addNewShoppingListToStore(String storeid) {
		this.savedShoppingLists.put(storeid, new ShoppingList(storeid));
	}
	
	public ShoppingList getShoppingListFromStore(String storeid) {
		return this.savedShoppingLists.get(storeid);
	}

	public String toString() {
		return "Name: " + this.name + ", Username: " + this.identifier + ", Password: " + this.password + ", Email: "
				+ this.email + ".";
	}

	@Override
	public void setAuth(Boolean change) {
		if (change) {
			this.auth2 = true;
		} else {
			this.auth2 = false;
		}
	}

	@Override
	public boolean getAuth() {
		return this.auth2;
	}
}
