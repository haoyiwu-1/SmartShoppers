package SmartShoppers;

import java.io.Serializable;

public class Item implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3551009131969545988L;
	private String id;
	public String name;
	public String description;
	public Double price;
	public String size;
	public String category;
	
	public Item(String id, String name, Double price, String cat) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.category = cat;
	}
	
	public void modifyItemId(String id) {
		this.id = id;
	}
	
	public String getId() {
		return this.id;
	}
	
	public String toString() {
		return this.id;
	}
}
