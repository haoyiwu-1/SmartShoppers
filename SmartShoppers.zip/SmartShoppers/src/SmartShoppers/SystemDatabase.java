package SmartShoppers;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.io.File;

public class SystemDatabase {

	private String path = System.getProperty("user.dir");
	private static SystemDatabase databaseInstance = null;
	private final String storeDataPath = path + "\\database\\stores.txt";
	private final String accDataPath = path + "\\database\\AccountMapping.txt";
	private final String weeklySaleItemsDataPath = path + "\\database\\WeeklySaleItems.txt";
	private List<String> randomlyGeneratedWeeklySaleItems = new ArrayList<String>();
	private Map<String, Store> stores = new HashMap<String, Store>();
	private Map<String, UserAccount> accIds = new HashMap<String, UserAccount>();
	private UserAccount currentUser;

	private SystemDatabase() {
		// create database files
		File databaseFolder = new File(path + "\\database");
		databaseFolder.mkdir();
		File storeDataFile = new File(path + "\\database\\stores.txt");
		File accDataFile = new File(path + "\\database\\AccountMapping.txt");
		File weeklySaleItemsDataFile = new File(path + "\\database\\WeeklySaleItems.txt");
		
		try {
			boolean storeDataFileCreated = storeDataFile.createNewFile();
			boolean accDataFileCreated = accDataFile.createNewFile();
			boolean weeklySaleItemsDataFileCreated = weeklySaleItemsDataFile.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		loadStoreData();
		loadAccMapData();
		loadWeeklySaleItemsData();

		System.out.println("For testing purposes and ease of use...");

		if (stores != null) {
			System.out.println("Stores");
			stores.entrySet().forEach(entry -> {
				System.out.println("Store id: " + entry.getKey() + ", Location: " + entry.getValue().getLocation()
						+ ", Opens: " + entry.getValue().getOpentime() + ", Closes: "
						+ entry.getValue().getClosingtime() + ", Manager name: " + entry.getValue().getManagerName()
						+ ", Manager Username: " + entry.getValue().getManagerUsername());
			});
		}

		if (accIds != null) {
			System.out.println("Accounts");

			accIds.entrySet().forEach(entry -> {
				System.out.println("Username: " + entry.getKey() + ", Password: " + entry.getValue().getPassword()
						+ ", Name: " + entry.getValue().getName() + ", Email: " + entry.getValue().getEmail()
						+ ", Auth: " + entry.getValue().getAuth() + ", Acc Type: "
						+ entry.getValue().getClass().getSimpleName());
			});
		}

		if (randomlyGeneratedWeeklySaleItems != null) {
			System.out.println("Weekly Sale Items");
			System.out.println(this.randomlyGeneratedWeeklySaleItems.toString());
		}
	}

	// get instance of system database
	public static SystemDatabase getInstance() {
		if (databaseInstance == null) {
			databaseInstance = new SystemDatabase();
		}
		return databaseInstance;
	}

	// loading store data
	@SuppressWarnings("unchecked")
	public void loadStoreData() {
		try {
			FileInputStream in = new FileInputStream(storeDataPath);
			ObjectInputStream is = new ObjectInputStream(in);
			this.stores = (Map<String, Store>) is.readObject();
			in.close();
			is.close();
		} catch (Exception e1) {
			if (e1.toString().equals("java.io.EOFException")) {
				System.out.println("Empty database file for store data (stores.txt)...");
			} else {
				System.out.println(e1.toString());
			}
		}
	}

	// load acc data
	@SuppressWarnings("unchecked")
	public void loadAccMapData() {
		try {
			FileInputStream in = new FileInputStream(accDataPath);
			ObjectInputStream is = new ObjectInputStream(in);
			this.accIds = (Map<String, UserAccount>) is.readObject();
			in.close();
			is.close();
		} catch (Exception e1) {
			if (e1.toString().equals("java.io.EOFException")) {
				System.out.println("Empty database file for account data (AccountMapping.txt)...");
			} else {
				System.out.println(e1.toString());
			}
		}
	}

	// load acc data
	@SuppressWarnings("unchecked")
	public void loadWeeklySaleItemsData() {
		try {
			FileInputStream in = new FileInputStream(weeklySaleItemsDataPath);
			ObjectInputStream is = new ObjectInputStream(in);
			this.randomlyGeneratedWeeklySaleItems = (List<String>) is.readObject();
			in.close();
			is.close();
		} catch (Exception e1) {
			if (e1.toString().equals("java.io.EOFException")) {
				System.out.println("Empty database file for weekly sale items data (WeeklySaleItems.txt)...");
			} else {
				System.out.println(e1.toString());
			}
		}
	}

	// saving the store data
	public void saveStoreData() {
		try {
			FileOutputStream out = new FileOutputStream(storeDataPath);
			ObjectOutputStream os = new ObjectOutputStream(out);
			os.writeObject(stores);
			os.close();
			out.close();
		} catch (Exception e1) {
			System.out.println(e1.toString());
		}
	}

	// saving acc mapping
	public void saveAccMapData() {
		try {
			FileOutputStream out = new FileOutputStream(accDataPath);
			ObjectOutputStream os = new ObjectOutputStream(out);
			os.writeObject(accIds);
			os.close();
			out.close();
		} catch (Exception e1) {
			System.out.println(e1.toString());
		}
	}

	public void saveWeeklySaleItems() {
		try {
			FileOutputStream out = new FileOutputStream(weeklySaleItemsDataPath);
			ObjectOutputStream os = new ObjectOutputStream(out);
			os.writeObject(randomlyGeneratedWeeklySaleItems);
			os.close();
			out.close();
		} catch (Exception e1) {
			System.out.println(e1.toString());
		}
	}

	// add store to system
	public void addStore(Store store) {
		this.stores.put(store.getId(), store);
	}

	// remove store from system if it exists
	public void removeStore(String storeId) {
		this.stores.remove(storeId);
	}

	// returns if the store is in the system
	public boolean checkStore(String storeId) {
		return this.stores.containsKey(storeId);
	}

	// return list of all possible store names
	public List<String> getStoresID() {
		List<String> storeNames = new ArrayList<String>();
		stores.entrySet().forEach(entry -> {
			String storeID = entry.getValue().getId();
			storeNames.add(storeID);
		});
		return storeNames;
	}

	// get all manager accounts
	public List<UserAccount> getManagers() {
		List<UserAccount> managers = new ArrayList<UserAccount>();
		accIds.entrySet().forEach(entry -> {
			if (entry.getValue() instanceof ManagerAccount) {
				managers.add(entry.getValue());
			}
		});
		return managers;
	}

	// get all stores
	public List<Store> getStores() {
		List<Store> existingStores = new ArrayList<Store>();
		stores.entrySet().forEach(entry -> {
			existingStores.add(entry.getValue());
		});
		return existingStores;
	}

	// get store by id
	public Store getStoreById(String id) {
		return this.stores.get(id);
	}

	public boolean doesAccExists(String username) {
		if (this.accIds.containsKey(username)) {
			return true;
		}
		return false;
	}

	public UserAccount getAccDetails(String username) {
		UserAccount wanted = this.accIds.get(username);
		if (wanted instanceof CustomerAccount) {
			return (CustomerAccount) wanted;
		} else if (wanted instanceof ManagerAccount) {
			return (ManagerAccount) wanted;
		} else {
			return (AdministratorAccount) wanted;
		}
	}

	public void addUserAcc(UserAccount user) {
		this.accIds.put(user.getIdentifier(), user);
	}

	public void removeUserAccount(String username) {
		this.accIds.remove(username);
	}

	public void loadCurrentUser(String user) {
		this.currentUser = this.getAccDetails(user);
	}

	public UserAccount getCurrentUser() {
		return this.currentUser;
	}

	public void setWeeklySaleItems(List<String> list) {
		this.randomlyGeneratedWeeklySaleItems = list;
	}

	public List<String> getWeeklySaleItems() {
		return this.randomlyGeneratedWeeklySaleItems;
	}

	public void removeWeeklySaleItem(String name, String storeid) {
		String toRemove = storeid + " - " + name;
		this.randomlyGeneratedWeeklySaleItems.remove(toRemove);
	}

	public void addWeeklySaleItem(String name, String storeid) {
		String toAdd = storeid + " - " + name;
		this.randomlyGeneratedWeeklySaleItems.add(toAdd);
	}

	public List<String> generateSuggestedList(String storeid, String user) {
		List<String> recommendedItemList = new ArrayList<String>();
		List<Item> possibleItemsToRecommend = new ArrayList<Item>();
		ShoppingList currentUserList = ((CustomerAccount) accIds.get(user)).getShoppingListFromStore(storeid);
		Map<String, Item> shopItems = stores.get(storeid).getItems();

		for (Entry<String, Item> entry : shopItems.entrySet()) {
			if (!currentUserList.getList().containsKey(entry.getKey())) {
				possibleItemsToRecommend.add(entry.getValue());
			}
		}
		// generate a random number of items to grab from the possible items to put into
		// the recommended list
		if (possibleItemsToRecommend.size() > 0) {
			Random rand = new Random();
			int amount;
			if (possibleItemsToRecommend.size() > 1) {
				amount = rand.nextInt(possibleItemsToRecommend.size() - 1) + 1;
				for (int i = 0; i < amount; i++) {
					recommendedItemList.add(possibleItemsToRecommend.get(i).name);
				}
			} else {
				recommendedItemList.add(possibleItemsToRecommend.get(0).name);
			}
		}
		return recommendedItemList;
	}

	public List<String> generateShoppingOrder(String user, String storeid) {
		ShoppingList currentShoppingList = ((CustomerAccount) this.getAccDetails(user))
				.getShoppingListFromStore(storeid);
		Map<Integer, List<String>> storeCategories = this.stores.get(storeid).getStoreMap();
		Map<Integer, Integer> itemsInAisle = new HashMap<Integer, Integer>();
		List<String> shoppingOrder = new ArrayList<String>();
		for (Entry<String, Integer> entry : currentShoppingList.getList().entrySet()) {
			for (Entry<Integer, List<String>> entry2 : storeCategories.entrySet()) {
				if (entry2.getValue().contains(this.stores.get(storeid).getItems().get(entry.getKey()).category)) {
					if (itemsInAisle.get(entry2.getKey()) != null) {
						int oldValue = itemsInAisle.get(entry2.getKey());
						itemsInAisle.put(entry2.getKey(), oldValue + entry.getValue());
					} else {
						itemsInAisle.put(entry2.getKey(), entry.getValue());
					}
				}
			}
		}
		List<Entry<Integer, Integer>> list = new ArrayList<>(itemsInAisle.entrySet());
		list.sort(Entry.comparingByValue());

		Map<Integer, Integer> result = new LinkedHashMap<>();
		for (Entry<Integer, Integer> entry : list) {
			result.put(entry.getKey(), entry.getValue());
		}
		
		for (Map.Entry<Integer, Integer> entry : result.entrySet()) {
			for (String cat : storeCategories.get(entry.getKey())) {
				for (Item item : this.stores.get(storeid).getCategoryItems().get(cat)) {
					if (currentShoppingList.getList().containsKey(item.getId())) {
						int amount = currentShoppingList.getList().get(item.getId());
						shoppingOrder.add(item.name + " - " + String.valueOf(amount));
					}
				}
			}
		}
		return shoppingOrder;
	}
}
