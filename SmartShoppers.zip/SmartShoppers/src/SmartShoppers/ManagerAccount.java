package SmartShoppers;

import java.io.Serializable;

public class ManagerAccount implements UserAccount, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3401050690357707694L;
	private String name;
	private String identifier;
	private String password;
	private Store store;
	private String email;
	private boolean auth2;

	public ManagerAccount(String id, String password, String name, String email) {
		this.identifier = id;
		this.password = password;
		this.name = name;
		this.email = email;
		this.auth2 = false;
	}

	@Override
	public String getIdentifier() {
		return this.identifier;
	}

	@Override
	public void setIdentifier(String id) {
		this.identifier = id;
	}

	@Override
	public String getPassword() {
		return this.password;
	}

	@Override
	public void setPassword(String pass) {
		this.password = pass;
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String getEmail() {
		return this.email;
	}

	@Override
	public void setEmail(String email) {
		this.email = email;
	}

	public void changeStore(Store store) {
		this.store = store;
	}

	public Store getStore() {
		if (this.store != null) {
			return this.store;
		}
		return null;
	}

	public String toString() {
		return "Name: " + this.name + ", Username: " + this.identifier + ", Password: " + this.password + ", Email: "
				+ this.email + ".";
	}

	@Override
	public void setAuth(Boolean change) {
		if (change) {
			this.auth2 = true;
		} else {
			this.auth2 = false;
		}
	}

	@Override
	public boolean getAuth() {
		return this.auth2;
	}

}
