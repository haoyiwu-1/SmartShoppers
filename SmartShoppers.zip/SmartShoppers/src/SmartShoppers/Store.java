package SmartShoppers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Store implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7211822744197415650L;
	private String id;
	private String location;
	private String openTime;
	private String closeTime;
	private ManagerAccount manager;
	private Map<String, Item> items;
	private Map<Item, Integer> inventory;
	private Map<String, Set<Item>> category; // to search by category
	private Map<Integer, List<String>> storeMap;
	private Set<Item> saleItems;
	private List<String> itemNames; // to search by name
	private List<String> suggestedItemList; //items suggested to the user based on their cart and their current store

	public Store(String id, String location, String open, String close) {
		this.location = location;
		this.id = id;
		this.openTime = open;
		this.closeTime = close;
		this.inventory = new HashMap<Item, Integer>();
		this.items = new HashMap<String, Item>();
		this.category = new HashMap<String, Set<Item>>();
		this.saleItems = new HashSet<Item>();
		this.storeMap = new HashMap<Integer, List<String>>(); // mapping aisle number to the categories available in
																// that aisle
		this.itemNames = new ArrayList<String>(); //list of all item names
		this.suggestedItemList = new ArrayList<String>();
	}

	public String getId() {
		return this.id;
	}

	public String getLocation() {
		return this.location;
	}

	public void changeLocation(String loc) {
		this.location = loc;
	}

	public String getOpentime() {
		return this.openTime;
	}

	public String getClosingtime() {
		return this.closeTime;
	}

	public String getManagerName() {
		if (this.manager != null) {
			return this.manager.getName();
		} else {
			return "N/A (Empty)";
		}
	}

	public String getManagerUsername() {
		if (this.manager != null) {
			return this.manager.getIdentifier();
		} else {
			return "N/A (Empty)";
		}
	}

	public void addItem(Item newItem) {
		this.inventory.put(newItem, 0);
		this.itemNames.add(newItem.name);
		this.items.put(newItem.getId(), newItem);
		// get old category list if one exists
		Set<Item> newCategoryList = this.category.get(newItem.category);
		if (newCategoryList != null) {
			newCategoryList.add(newItem);
		} else {
			newCategoryList = new HashSet<Item>();
			newCategoryList.add(newItem);
		}
		this.category.put(newItem.category, newCategoryList);
	}

	public void removeItem(Item item) {
		this.inventory.remove(item);
		this.items.remove(item.getId());
		Set<Item> oldCat = null;
		if (this.category.get(item.category) != null && this.category.get(item.category).size() > 1) {
			oldCat = this.category.get(item.category);
			oldCat.remove(item);
			this.category.put(item.category, oldCat);
		} else if (this.category.get(item.category) != null && this.category.get(item.category).size() == 1) {
			this.category.remove(item.category);
		}
		this.itemNames.remove(item.name);
	}

	public void changeInventory(Item item, int count) {
		this.inventory.put(item, count);
	}

	public void addSaleItem(Item item) {
		this.saleItems.add(item);
	}

	public void removeSaleItem(Item item) {
		this.saleItems.remove(item);
	}

	public void updateOpening(String time) {
		this.openTime = time;
	}

	public void updateClosing(String time) {
		this.closeTime = time;
	}

	public String showStaffSaleItems() {
		List<Item> saleItemList = new ArrayList<Item>(saleItems);
		if (this.saleItems != null && this.saleItems.size() > 0) {
			return saleItemList.toString();
		}
		return "No items on sale currently.";
	}
	
	public String showCustomerSaleItems() {
		List<Item> saleItemList = new ArrayList<Item>(saleItems);
		List<String> saleItemNameList = new ArrayList<String>();
		if (this.saleItems != null && this.saleItems.size() > 0) {
			for (Item i: saleItemList) {
				saleItemNameList.add(i.name);
			}
			return saleItemNameList.toString();
		}
		return "No items on sale currently.";
	}

	public Set<Item> getSaleItems() {
		return this.saleItems;
	}

	public Map<Item, Integer> getInv() {
		return this.inventory;
	}

	public Map<String, Item> getItems() {
		return this.items;
	}

	public Map<String, Set<Item>> getCategoryItems() {
		return this.category;
	}

	public List<String> getItemsByName() {
		return this.itemNames;
	}

	public void changeManager(ManagerAccount newManager) {
		this.manager = newManager;
	}

	public void removeManager() {
		this.manager = null;
	}

	public String toString() {
		return this.id + " - " + this.getLocation();
	}

	public Map<Integer, List<String>> getStoreMap() {
		return this.storeMap;
	}

	public void addtoAisle(int aisle, String cat) {
		if (this.storeMap.get(aisle) != null) {
			List<String> oldCategoriesContained = this.storeMap.get(aisle);
			oldCategoriesContained.add(cat);
			this.storeMap.put(aisle, oldCategoriesContained);
		} else {
			List<String> newCategoriesContained = new ArrayList<String>();
			newCategoriesContained.add(cat);
			this.storeMap.put(aisle, newCategoriesContained);
		}
	}

	public void removeFromAisle(int aisle, String cat) {
		this.storeMap.get(aisle).remove(cat);
		if (this.storeMap.get(aisle).size() < 1) {
			this.storeMap.remove(aisle);
		}
	}
	
	public void setSuggestedItemList(List<String> suggested) {
		this.suggestedItemList = suggested;
	}
	
	public List<String> getSuggestedItemList() {
		return this.suggestedItemList;
	}
	

}
