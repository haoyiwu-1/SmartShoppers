package SmartShoppers;

public interface UserAccount {
	public String getIdentifier();
	public void setIdentifier(String id);
	public String getPassword();
	public void setPassword(String pass);
	public String getName();
	public void setName(String name);
	public String getEmail();
	public void setEmail(String email);
	public void setAuth(Boolean b);
	public boolean getAuth();
}
