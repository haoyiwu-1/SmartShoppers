package SmartShoppers;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ShoppingList implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6000637518717167620L;
	private String id; //id of store this shopping list belongs to
	private Map<String, Integer> itemList; //itemid and amount
	
	public ShoppingList(String id) {
		this.id = id;
		itemList = new HashMap<String, Integer>();
	}
	
	public void addItem(String itemId, int amount) {
		if (this.itemList.get(itemId) != null) {
			int oldAmount = this.itemList.get(itemId);
			this.itemList.put(itemId, amount + oldAmount);
		} else {
			this.itemList.put(itemId, amount);
		}
		
	}
	
	public void removeItem(String itemId, int amount) {
		if (this.itemList.get(itemId) != null) {
			if (amount == this.itemList.get(itemId)) {
				this.itemList.remove(itemId);
			} else {
				int oldAmount = this.itemList.get(itemId);
				this.itemList.put(itemId, oldAmount - amount);
			}
		}
	}
	
	public Map<String, Integer> getList(){
		return this.itemList;
	}
	
	public String getId() {
		return this.id;
	}
}
