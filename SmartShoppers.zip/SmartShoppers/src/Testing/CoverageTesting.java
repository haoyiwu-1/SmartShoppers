package Testing;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import SmartShoppers.AdministratorAccount;
import SmartShoppers.CustomerAccount;
import SmartShoppers.Item;
import SmartShoppers.ManagerAccount;
import SmartShoppers.ShoppingList;
import SmartShoppers.Store;
import SmartShoppers.SystemDatabase;
import SmartShoppersApplication.SmartShoppersApp;

public class CoverageTesting {

	@Before
	public void emptyFiles() throws FileNotFoundException {
		// to empty text files for each run of all junit tests
		PrintWriter writer = new PrintWriter("Database/AccountMapping.txt");
		PrintWriter writer1 = new PrintWriter("Database/stores.txt");
		PrintWriter writer2 = new PrintWriter("Database/WeeklySaleItems.txt");
	}

	@Test
	public void testCustomerAccConstructor() {
		CustomerAccount cust1 = new CustomerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		assertEquals(cust1.getIdentifier(), "Tommy1");
		assertEquals(cust1.getPassword(), "123");
		assertEquals(cust1.getName(), "Tommy Jones");
		assertEquals(cust1.getEmail(), "Tommy@gmail.com");
	}

	@Test
	public void testManagerAccConstructor() {
		ManagerAccount manager1 = new ManagerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		assertEquals(manager1.getIdentifier(), "Tommy1");
		assertEquals(manager1.getPassword(), "123");
		assertEquals(manager1.getName(), "Tommy Jones");
		assertEquals(manager1.getEmail(), "Tommy@gmail.com");
	}

	@Test
	public void testAdminAccConstructor() {
		AdministratorAccount admin1 = new AdministratorAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		assertEquals(admin1.getIdentifier(), "Tommy1");
		assertEquals(admin1.getPassword(), "123");
		assertEquals(admin1.getName(), "Tommy Jones");
		assertEquals(admin1.getEmail(), "Tommy@gmail.com");
	}
	
	@Test
	public void testSetAccIds() {
		CustomerAccount cust1 = new CustomerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		ManagerAccount manager1 = new ManagerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		AdministratorAccount admin1 = new AdministratorAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		cust1.setIdentifier("Timmy1");
		manager1.setIdentifier("Timmy1");
		admin1.setIdentifier("Timmy1");
		assertEquals(cust1.getIdentifier(), "Timmy1");
		assertEquals(manager1.getIdentifier(), "Timmy1");
		assertEquals(admin1.getIdentifier(), "Timmy1");
	}
	
	@Test
	public void testSetAccPasswords() {
		CustomerAccount cust1 = new CustomerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		ManagerAccount manager1 = new ManagerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		AdministratorAccount admin1 = new AdministratorAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		cust1.setPassword("456");
		manager1.setPassword("456");
		admin1.setPassword("456");
		assertEquals(cust1.getPassword(), "456");
		assertEquals(manager1.getPassword(), "456");
		assertEquals(admin1.getPassword(), "456");
	}
	
	@Test
	public void testSetAccNames() {
		CustomerAccount cust1 = new CustomerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		ManagerAccount manager1 = new ManagerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		AdministratorAccount admin1 = new AdministratorAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		cust1.setName("Timmy Jones");
		manager1.setName("Timmy Jones");
		admin1.setName("Timmy Jones");
		assertEquals(cust1.getName(), "Timmy Jones");
		assertEquals(manager1.getName(), "Timmy Jones");
		assertEquals(admin1.getName(), "Timmy Jones");
	}
	
	@Test
	public void testSetAccEmails() {
		CustomerAccount cust1 = new CustomerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		ManagerAccount manager1 = new ManagerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		AdministratorAccount admin1 = new AdministratorAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		cust1.setEmail("Timmy@gmail.com");
		manager1.setEmail("Timmy@gmail.com");
		admin1.setEmail("Timmy@gmail.com");
		assertEquals(cust1.getEmail(), "Timmy@gmail.com");
		assertEquals(manager1.getEmail(), "Timmy@gmail.com");
		assertEquals(admin1.getEmail(), "Timmy@gmail.com");
	}
	
	@Test
	public void testSetAccAuths() {
		CustomerAccount cust1 = new CustomerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		ManagerAccount manager1 = new ManagerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		AdministratorAccount admin1 = new AdministratorAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		cust1.setAuth(false);
		cust1.setAuth(true);
		manager1.setAuth(true);
		manager1.setAuth(false);
		admin1.setAuth(true);
		admin1.setAuth(false);
		assertEquals(cust1.getAuth(), true);
		assertEquals(manager1.getAuth(), false);
		assertEquals(admin1.getAuth(), false);
	}

	@Test
	public void testAccsToString() {
		CustomerAccount cust1 = new CustomerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		ManagerAccount manager1 = new ManagerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		AdministratorAccount admin1 = new AdministratorAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		assertEquals(cust1.toString(), "Name: Tommy Jones, Username: Tommy1, Password: 123, Email: Tommy@gmail.com.");
		assertEquals(manager1.toString(),
				"Name: Tommy Jones, Username: Tommy1, Password: 123, Email: Tommy@gmail.com.");
		assertEquals(admin1.toString(), "Name: Tommy Jones, Username: Tommy1, Password: 123, Email: Tommy@gmail.com.");
	}

	@Test
	public void testCustChangePrefStore() {
		CustomerAccount cust1 = new CustomerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		Store newStore = new Store("Store#1234", "Toronto", "8:00am", "8:00pm");
		assertEquals(cust1.getPrefStore(), "N/A");
		cust1.changePrefStore(newStore);
		assertEquals(cust1.getPrefStore().toString(), "Store#1234 - Toronto");
	}
	
	@Test
	public void testCustAddSavedStore() {
		CustomerAccount cust1 = new CustomerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		Store newStore = new Store("Store#1234", "Toronto", "8:00am", "8:00pm");
		cust1.addSavedStore(newStore);
		assertTrue(cust1.getSavedStoreIds().size() == 1);
		assertEquals(cust1.getSavedStoresString(), "[Store#1234 - Toronto]");
	}
	
	@Test
	public void testCustRemoveSavedStore() {
		CustomerAccount cust1 = new CustomerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		Store newStore = new Store("Store#1234", "Toronto", "8:00am", "8:00pm");
		cust1.removeSavedStore(newStore);
		assertTrue(cust1.getSavedStoreIds().size() == 0);
		assertEquals(cust1.getSavedStoresString(), "No stores saved on this account.");
	}
	
	@Test public void testCustShoppingListMethods() {
		CustomerAccount cust1 = new CustomerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		cust1.addNewShoppingListToStore("store1");
		assertTrue(cust1.getShoppingListFromStore("store1").getList().size() == 0);
	}

	@Test
	public void testManagerGetAndSetStore() {
		ManagerAccount manager1 = new ManagerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		Store newStore = new Store("Store#1234", "Toronto", "8:00am", "8:00pm");
		manager1.changeStore(newStore);
		assertEquals(manager1.getStore(), newStore);
	}

	@Test
	public void testManagerGetAndSetNullStore() {
		ManagerAccount manager1 = new ManagerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		assertEquals(manager1.getStore(), null);
	}
	
	@Test
	public void testGetSystemDatabaseInstance() {
		SystemDatabase Database = SystemDatabase.getInstance();
		assertEquals(Database.getClass().getCanonicalName(), "SmartShoppers.SystemDatabase");
	}
	
	@Test
	public void testSystemDatabaseAddUserAccs() {
		SystemDatabase Database = SystemDatabase.getInstance();
		CustomerAccount cust1 = new CustomerAccount("Cust1", "123", "Tommy Jones", "Tommy@gmail.com");
		ManagerAccount manager1 = new ManagerAccount("Manage1", "123", "Tommy Jones", "Tommy@gmail.com");
		AdministratorAccount admin1 = new AdministratorAccount("Admin1", "123", "Tommy Jones", "Tommy@gmail.com");
		Database.addUserAcc(cust1);
		Database.addUserAcc(manager1);
		Database.addUserAcc(admin1);
		assertEquals(Database.doesAccExists("Cust1"), true);
		assertEquals(Database.doesAccExists("Manage1"), true);
		assertEquals(Database.doesAccExists("Admin1"), true);
	}
	
	@Test
	public void testSystemDatabaseGetAccDetails() {
		SystemDatabase Database = SystemDatabase.getInstance();
		CustomerAccount cust1 = new CustomerAccount("Cust1", "123", "Tommy Jones", "Tommy@gmail.com");
		ManagerAccount manager1 = new ManagerAccount("Manage1", "123", "Tommy Jones", "Tommy@gmail.com");
		AdministratorAccount admin1 = new AdministratorAccount("Admin1", "123", "Tommy Jones", "Tommy@gmail.com");
		Database.addUserAcc(cust1);
		Database.addUserAcc(manager1);
		Database.addUserAcc(admin1);
		assertEquals(Database.getAccDetails(cust1.getIdentifier()).getIdentifier(), cust1.getIdentifier());
		assertEquals(Database.getAccDetails(manager1.getIdentifier()).getName(), manager1.getName());
		assertEquals(Database.getAccDetails(admin1.getIdentifier()).getPassword(), admin1.getPassword());
	}
	
	@Test
	public void testSystemDatabaseRemoveUserAccs() {
		SystemDatabase Database = SystemDatabase.getInstance();
		Database.removeUserAccount("Cust1");
		Database.removeUserAccount("Manage1");
		Database.removeUserAccount("Admin1");
		assertEquals(Database.doesAccExists("Cust1"), false);
		assertEquals(Database.doesAccExists("Manage1"), false);
		assertEquals(Database.doesAccExists("Admin1"), false);
	}
	
	@Test
	public void testSystemDatabaseDoesAccExist() {
		SystemDatabase Database = SystemDatabase.getInstance();
		CustomerAccount cust1 = new CustomerAccount("Cust1", "123", "Tommy Jones", "Tommy@gmail.com");
		Database.addUserAcc(cust1);
		assertEquals(Database.doesAccExists("Cust1"), true);
	}
	
	@Test
	public void testSystemDatabaseGetAndSetCurrentUser() {
		SystemDatabase Database = SystemDatabase.getInstance();
		CustomerAccount cust1 = new CustomerAccount("Cust1", "123", "Tommy Jones", "Tommy@gmail.com");
		Database.loadCurrentUser(cust1.getIdentifier());
		assertEquals(Database.getCurrentUser().getIdentifier(), "Cust1");
	}

	@Test
	public void testSystemDatabaseLoadAndSaveMethods() {
		SystemDatabase Database = SystemDatabase.getInstance();
		CustomerAccount cust1 = new CustomerAccount("Cust1", "123", "Tommy Jones", "Tommy@gmail.com");
		Database.addUserAcc(cust1);
		Database.saveAccMapData();
		SystemDatabase Database2 = SystemDatabase.getInstance();
		assertEquals(Database2.doesAccExists(cust1.getIdentifier()), true);
		Store newStore = new Store("Store#4345", "Toronto", "8:00am", "8:00pm");
		Database.addStore(newStore);
		Database.saveStoreData();
		SystemDatabase Database3 = SystemDatabase.getInstance();
		assertEquals(Database3.getStoresID().size(), 1);
	}
	
	//split?
	@Test
	public void testSystemDatabaseStoreRelatedMethods() {
		SystemDatabase Database = SystemDatabase.getInstance();
		Store newStore2 = new Store("Store#4346", "Toronto", "10:00am", "10:00pm");
		Boolean result = Database.checkStore(newStore2.getId());
		assertEquals(result, false);
		assertEquals(Database.getStoreById("Store#4346"), null);
		List<String> tester = new ArrayList<String>();
		Database.setWeeklySaleItems(tester);
		assertEquals(Database.getWeeklySaleItems(), tester);
		int oldSize = Database.getStores().size();
		Database.addStore(newStore2);
		assertTrue(Database.getStoresID().size() == oldSize + 1);
		int newOldSize = Database.getStores().size();
		Database.removeStore(newStore2.getId());
		assertTrue(Database.getStoresID().size() == newOldSize - 1);
		assertTrue(Database.getManagers().size() == 1);
		Item Item1 = new Item("Item1", "Apples", 9.99, "Produce");
		Database.addWeeklySaleItem(Item1.name, newStore2.getId());
		assertTrue(Database.getWeeklySaleItems().size() == 1);
		Database.removeWeeklySaleItem(Item1.name, newStore2.getId());
		assertTrue(Database.getWeeklySaleItems().size() == 0);
		Database.addWeeklySaleItem(Item1.name, newStore2.getId());
		Database.saveWeeklySaleItems();
		SystemDatabase DatabaseAfterWeeklyItemAdded = SystemDatabase.getInstance();
		assertTrue(DatabaseAfterWeeklyItemAdded.getWeeklySaleItems().size() == 1);
	}
	
	@Test
	public void testSystemDatabaseSuggestedListRelatedMethods() {
		SystemDatabase Database = SystemDatabase.getInstance();
		Item Item1 = new Item("Item1", "Apples", 9.99, "Produce");
		Store newStore = new Store("Store#4345", "Toronto", "8:00am", "8:00pm");
		CustomerAccount cust1 = new CustomerAccount("Cust1", "123", "Tommy Jones", "Tommy@gmail.com");
		Database.addUserAcc(cust1);
		Database.addStore(newStore);
		List<String> simulatedSuggestedList = new ArrayList<String>();
		((CustomerAccount) Database.getAccDetails(cust1.getIdentifier())).addNewShoppingListToStore(newStore.getId());
		assertEquals(Database.generateSuggestedList(newStore.getId(), cust1.getIdentifier()), simulatedSuggestedList);
		newStore.addItem(Item1);
		newStore.changeInventory(Item1, 10);
		simulatedSuggestedList.add(Item1.name);
		assertEquals(Database.generateSuggestedList(newStore.getId(), cust1.getIdentifier()), simulatedSuggestedList);
		Item Item2 = new Item("Item2", "Rocks", 200.99, "Rocks");
		newStore.addItem(Item2);
		newStore.changeInventory(Item2, 100);
		assertEquals(Database.generateSuggestedList(newStore.getId(), cust1.getIdentifier()), simulatedSuggestedList);
	}
	
	@Test
	public void testDatabaseSystemShoppingOrderRelatedMethods() {
		SystemDatabase Database = SystemDatabase.getInstance();
		Store newStore = new Store("Store#4345", "Toronto", "8:00am", "8:00pm");
		CustomerAccount cust1 = new CustomerAccount("Cust1", "123", "Tommy Jones", "Tommy@gmail.com");
		Database.addUserAcc(cust1);
		Database.addStore(newStore);
		Item Item1 = new Item("Item1", "Apples", 9.99, "Produce");
		newStore.addItem(Item1);
		newStore.changeInventory(Item1, 100);
		Item Item2 = new Item("Item2", "Rocks", 200.99, "Rocks");
		newStore.addItem(Item2);
		newStore.changeInventory(Item2, 100);
		Item Item3 = new Item("Item3", "Minerals", 300.99, "Rocks");
		newStore.addItem(Item3);
		newStore.changeInventory(Item3, 100);
		((CustomerAccount) Database.getAccDetails(cust1.getIdentifier())).addNewShoppingListToStore(newStore.getId());
		List<String> generatedShoppingOrder = new ArrayList<String>();
		((CustomerAccount) Database.getAccDetails(cust1.getIdentifier())).getShoppingListFromStore(newStore.getId())
				.addItem(Item1.getId(), 1);
		((CustomerAccount) Database.getAccDetails(cust1.getIdentifier())).getShoppingListFromStore(newStore.getId())
				.addItem(Item2.getId(), 10);
		((CustomerAccount) Database.getAccDetails(cust1.getIdentifier())).getShoppingListFromStore(newStore.getId())
				.addItem(Item3.getId(), 30);
		newStore.addtoAisle(0, "Produce");
		newStore.addtoAisle(1, "Rocks");
		generatedShoppingOrder.add("Apples - 1");
		generatedShoppingOrder.add("Rocks - 10");
		generatedShoppingOrder.add("Minerals - 30");
		assertEquals(Database.generateShoppingOrder(cust1.getIdentifier(), newStore.getId()).size(),
				generatedShoppingOrder.size());
	}
	
	@Test
	public void testStoreConstructor() {
		Store store1 = new Store("Store1", "Toronto", "8:00am", "8:00pm");
		assertEquals(store1.getId(), "Store1");
		assertEquals(store1.getLocation(), "Toronto");
		assertEquals(store1.getOpentime(), "8:00am");
		assertEquals(store1.getClosingtime(), "8:00pm");
		assertEquals(store1.getManagerName(), "N/A (Empty)");
		assertEquals(store1.getManagerUsername(), "N/A (Empty)");
	}

	@Test
	public void testSimpleStoreMethods() {
		Store store1 = new Store("Store1", "Toronto", "8:00am", "8:00pm");
		ManagerAccount manager1 = new ManagerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		store1.changeManager(manager1);
		store1.removeManager();
		store1.changeLocation("Ottawa");
		store1.updateOpening("9:00am");
		store1.updateClosing("10:00pm");
		assertEquals(store1.getId(), "Store1");
		assertEquals(store1.getLocation(), "Ottawa");
		assertEquals(manager1.getStore(), null);
		assertEquals(store1.getOpentime(), "9:00am");
		assertEquals(store1.getClosingtime(), "10:00pm");
		assertEquals(store1.getManagerName(), "N/A (Empty)");
		assertEquals(store1.getManagerUsername(), "N/A (Empty)");
		store1.addtoAisle(0, "Produce");
		List<String> listOfCategories = new ArrayList<String>();
		listOfCategories.add("Produce");
		assertEquals(store1.getStoreMap().get(0), listOfCategories);
		store1.addtoAisle(0, "Fruits");
		listOfCategories.add("Fruits");
		assertEquals(store1.getStoreMap().get(0), listOfCategories);
		store1.addtoAisle(1, "Rocks");
		store1.removeFromAisle(1, "Rocks");
		assertEquals(store1.getStoreMap().get(1), null);
	}

	//split?
	@Test
	public void testComplexStoreMethods() {
		Store store1 = new Store("Store1", "Toronto", "8:00am", "8:00pm");
		ManagerAccount manager1 = new ManagerAccount("Tommy1", "123", "Tommy Jones", "Tommy@gmail.com");
		store1.changeManager(manager1);
		assertEquals(store1.getManagerName(), "Tommy Jones");
		assertEquals(store1.getManagerUsername(), "Tommy1");
		Item item1 = new Item("Item1", "Apple", 9.99, "Produce");
		Item item2 = new Item("Item2", "Oranges", 3.99, "Produce");
		Item item3 = new Item("Item3", "Rocks", 100.99, "Rocks");
		store1.addItem(item1);
		store1.addItem(item2);
		store1.addItem(item3);
		store1.removeItem(item1);
		assertEquals(store1.getItems().size(), 2);
		store1.removeItem(item3);
		assertEquals(store1.getItems().size(), 1);
		store1.addItem(item1);
		store1.changeInventory(item1, 100);
		assertTrue(store1.getInv().get(item1).equals(100));
		assertTrue(store1.getSaleItems().size() == 0);
		assertTrue(store1.getItemsByName().size() == 2);
		assertTrue(store1.getStoreMap().size() == 0);
		assertTrue(store1.getSuggestedItemList().size() == 0);
		List<String> test = new ArrayList<String>();
		test.add("Store1 - Bananas");
		store1.setSuggestedItemList(test);
		assertTrue(store1.getSuggestedItemList().size() == 1);
		assertEquals(store1.showStaffSaleItems(), "No items on sale currently.");
		assertEquals(store1.showCustomerSaleItems(), "No items on sale currently.");
		store1.addSaleItem(item1);
		assertEquals(store1.showStaffSaleItems(), "[Item1]");
		assertEquals(store1.showCustomerSaleItems(), "[Apple]");
		store1.removeSaleItem(item1);
		assertEquals(store1.showStaffSaleItems(), "No items on sale currently.");
	}
	
	@Test
	public void testItemConstructor() {
		Item book = new Item("Item#456", "Book", 9.99, "Entertainment");
		assertEquals(book.getId(), "Item#456");
		assertEquals(book.name, "Book");
		assertTrue(book.price.equals(9.99));
		assertEquals(book.category, "Entertainment");
	}

	@Test
	public void testItemGetAndSetMethods() {
		Item book = new Item("Item#456", "Book", 9.99, "Entertainment");
		book.modifyItemId("Item#457");
		book.description = "A simple picture book for children.";
		book.size = "S - Small";
		assertEquals(book.getId(), "Item#457");
		assertEquals(book.name, "Book");
		assertEquals(book.description, "A simple picture book for children.");
		assertTrue(book.price.equals(9.99));
		assertEquals(book.size, "S - Small");
		assertEquals(book.category, "Entertainment");
		assertEquals(book.toString(), "Item#457");
	}
	
	@Test
	public void testShoppingListConstructor() {
		ShoppingList shoppingList = new ShoppingList("Store1");
		assertTrue(shoppingList.getList().size() == 0);
		assertEquals(shoppingList.getId(), "Store1");
	}
	
	@Test
	public void testShoppingListAddToList() {
		ShoppingList shoppingList = new ShoppingList("Store1");
		shoppingList.addItem("item1", 10);
		shoppingList.addItem("item1", 5);
		assertTrue(shoppingList.getList().get("item1") == 15);
	}

	@Test
	public void testShoppingListRemoveFromList() {
		ShoppingList shoppingList = new ShoppingList("Store1");
		shoppingList.addItem("item1", 10);
		shoppingList.addItem("item2", 10);
		shoppingList.removeItem("item1", 5);
		shoppingList.removeItem("item2", 10);
		assertTrue(shoppingList.getList().size() == 1);
		assertTrue(shoppingList.getList().get("item1") == 5);
	}
	
	@Test
	public void testShoppingListGetList() {
		ShoppingList shoppingList = new ShoppingList("Store1");
		shoppingList.addItem("item1", 10);
		assertTrue(shoppingList.getList().size() == 1);
	}
	
}
