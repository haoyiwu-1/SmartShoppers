package GUI.LoginAndCreation;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import GUI.MainPages.AdministratorMainPage;
import GUI.MainPages.CustomerMainPage;
import GUI.MainPages.ManagerMainPage;
import SmartShoppers.CustomerAccount;
import SmartShoppers.ManagerAccount;
import SmartShoppers.SystemDatabase;
import SmartShoppers.UserAccount;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.GridBagConstraints;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Insets;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.Random;
import java.awt.event.ActionEvent;

public class Login extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2641415562250325961L;
	private JPanel contentPane;
	private JLabel lblNewLabel_1;
	private JButton btnNewButton;
	private JTextField textField;
	private JPasswordField passwordField;
	private JLabel lblNewLabel_2;
	private JLabel lblDontHaveAn;
	private JButton btnCreateAccount;
	private static SystemDatabase Database;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		Database = SystemDatabase.getInstance();
		setTitle("SmartShoppers V1.0 - Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] { 200, 200, 30, 50, 30, 200 };
		gbl_contentPane.rowHeights = new int[] { 75, 75, 75, 0, 75, 0, 75, 50 };
		gbl_contentPane.columnWeights = new double[] { 0.0, 0.0, 0.0, 1.0 };
		gbl_contentPane.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		contentPane.setLayout(gbl_contentPane);

		lblNewLabel_1 = new JLabel("Login Page");
		lblNewLabel_1.setBackground(Color.BLACK);
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.BOLD, 40));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.gridwidth = 4;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 1;
		gbc_lblNewLabel_1.gridy = 0;
		contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);

		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.gridwidth = 2;
		gbc_lblNewLabel.fill = GridBagConstraints.BOTH;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 1;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);

		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 11));
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.insets = new Insets(0, 0, 5, 5);
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.gridx = 3;
		gbc_textField.gridy = 1;
		contentPane.add(textField, gbc_textField);
		textField.setColumns(10);

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(Color.BLACK);
		lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassword.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_lblPassword = new GridBagConstraints();
		gbc_lblPassword.gridwidth = 2;
		gbc_lblPassword.insets = new Insets(0, 0, 5, 5);
		gbc_lblPassword.gridx = 1;
		gbc_lblPassword.gridy = 2;
		contentPane.add(lblPassword, gbc_lblPassword);

		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 11));
		GridBagConstraints gbc_passwordField = new GridBagConstraints();
		gbc_passwordField.insets = new Insets(0, 0, 5, 5);
		gbc_passwordField.fill = GridBagConstraints.HORIZONTAL;
		gbc_passwordField.gridx = 3;
		gbc_passwordField.gridy = 2;
		contentPane.add(passwordField, gbc_passwordField);

		btnNewButton = new JButton("Login");
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String inputtedUsername = textField.getText();
				@SuppressWarnings("deprecation")
				String inputtedPassword = passwordField.getText();

				if (e.getSource() == btnNewButton) {
					// check for match in DB here and print out incorrect
					if (Database.doesAccExists(inputtedUsername)) {
						if (!Database.getAccDetails(inputtedUsername).getPassword().equals(inputtedPassword) ) {
							lblNewLabel_2.setForeground(Color.RED);
							lblNewLabel_2.setText("Incorrect password");
						} else {
							JOptionPane.showMessageDialog(null, "Login Successful...");
							UserAccount accType = SystemDatabase.getInstance().getAccDetails(inputtedUsername);
							Database.loadCurrentUser(inputtedUsername);
							if (accType instanceof CustomerAccount) {
								setVisible(false);
								dispose();
								// generate randomness of location based on login (number of stores they will see)
								// this only occurs if there exists more than one store
								Random rand = new Random();
								int amount;
								if (Database.getStoresID().size() > 1) {
									amount = rand.nextInt(Database.getStoresID().size() - 1) + 1;
								} else {
									amount = 1;
								}
								String amountAsStr = String.valueOf(amount);
								String[] randomStoreCount = {amountAsStr};
								CustomerMainPage.main(randomStoreCount);
							} else if (accType instanceof ManagerAccount) {
								setVisible(false);
								dispose();
								ManagerMainPage.main(null);
							} else {
								setVisible(false);
								dispose();
								AdministratorMainPage.main(null);
							}
						}
					} else {
						lblNewLabel_2.setForeground(Color.RED);
						lblNewLabel_2.setText("Account doesn't exist");
					}
				}
			}
		});

		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		lblNewLabel_2.setForeground(Color.WHITE);
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.gridwidth = 3;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 1;
		gbc_lblNewLabel_2.gridy = 3;
		contentPane.add(lblNewLabel_2, gbc_lblNewLabel_2);
		btnNewButton.setFont(new Font("Arial Narrow", Font.BOLD, 35));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridwidth = 4;
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 1;
		gbc_btnNewButton.gridy = 4;
		contentPane.add(btnNewButton, gbc_btnNewButton);

		lblDontHaveAn = new JLabel("Don't have an account? Create one now!");
		lblDontHaveAn.setHorizontalAlignment(SwingConstants.CENTER);
		lblDontHaveAn.setForeground(Color.BLACK);
		lblDontHaveAn.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_lblDontHaveAn = new GridBagConstraints();
		gbc_lblDontHaveAn.gridwidth = 4;
		gbc_lblDontHaveAn.insets = new Insets(0, 0, 5, 5);
		gbc_lblDontHaveAn.gridx = 1;
		gbc_lblDontHaveAn.gridy = 5;
		contentPane.add(lblDontHaveAn, gbc_lblDontHaveAn);

		btnCreateAccount = new JButton("Register");
		btnCreateAccount.setBackground(Color.LIGHT_GRAY);
		btnCreateAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				CreateAccount.main(null);
			}
		});
		btnCreateAccount.setFont(new Font("Arial Narrow", Font.BOLD, 35));
		GridBagConstraints gbc_btnCreateAccount = new GridBagConstraints();
		gbc_btnCreateAccount.gridwidth = 4;
		gbc_btnCreateAccount.insets = new Insets(0, 0, 5, 5);
		gbc_btnCreateAccount.gridx = 1;
		gbc_btnCreateAccount.gridy = 6;
		contentPane.add(btnCreateAccount, gbc_btnCreateAccount);
	}

}
