package GUI.LoginAndCreation;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import GUI.MainPages.AdministratorMainPage;
import GUI.MainPages.CustomerMainPage;
import GUI.MainPages.ManagerMainPage;
import SmartShoppers.CustomerAccount;
import SmartShoppers.ManagerAccount;
import SmartShoppers.SystemDatabase;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SuccessfulAccCreationPage extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -434819017386062088L;
	private JPanel contentPane;
	private static SystemDatabase Database;

	/**
	 * Launch the application.
	 */
	public static void main(String[] username) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SuccessfulAccCreationPage frame = new SuccessfulAccCreationPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SuccessfulAccCreationPage() {
		Database = SystemDatabase.getInstance();
		setTitle("SmartShoppers V1.0 - Successful Account Creation");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] {200, 200, 200, 200, 200};
		gbl_contentPane.rowHeights = new int[] {100, 100, 100, 100, 100};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNewLabel = new JLabel("Account created. You now have access to the SmartShoppers system.");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel.fill = GridBagConstraints.BOTH;
		gbc_lblNewLabel.ipady = 40;
		gbc_lblNewLabel.gridwidth = 5;
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 1;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		JButton btnNewButton = new JButton("To Main Page");
		btnNewButton.setFont(new Font("Arial Narrow", Font.BOLD, 35));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				String currentUser = Database.getCurrentUser().getIdentifier();
				if (Database.getAccDetails(currentUser) instanceof CustomerAccount) {
					CustomerMainPage.main(null);
				} else if (Database.getAccDetails(currentUser) instanceof ManagerAccount) {
					ManagerMainPage.main(null);
				} else {
					AdministratorMainPage.main(null);
				}
			}
		});
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridwidth = 3;
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 1;
		gbc_btnNewButton.gridy = 2;
		contentPane.add(btnNewButton, gbc_btnNewButton);
	}

}
