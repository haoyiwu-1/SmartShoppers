package GUI.LoginAndCreation;
import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import SmartShoppers.AdministratorAccount;
import SmartShoppers.CustomerAccount;
import SmartShoppers.ManagerAccount;
import SmartShoppers.SystemDatabase;
import SmartShoppers.UserAccount;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CreateAccount extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8058606452135365018L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private static SystemDatabase Database;
	private String AccType;
	private String[] options = { "Administrator", "Customer", "Manager" };
	private static boolean cancelFlag = false;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateAccount frame = new CreateAccount();
					frame.setVisible(true);
					if (cancelFlag) {
						frame.setVisible(false);
						frame.dispose();
					} else {
						frame.setVisible(true);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CreateAccount() {
		Database = SystemDatabase.getInstance();
		setTitle("SmartShoppers V1.0 - Account Creation");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		String getAccType = (String) JOptionPane.showInputDialog(null, "What account type do you want to create?",
				"Choose Account", JOptionPane.QUESTION_MESSAGE, null, options, options[1]);
		// deal with cancel option
		if (getAccType == null) {
			JOptionPane.showMessageDialog(null, "Going back to login page...");
			setVisible(false);
			dispose();
			cancelFlag = true;
			Login.main(null);
		}

		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] { 150, 150, 0, 150, 150, 150, 150 };
		gbl_contentPane.rowHeights = new int[] { 60, 60, 60, 60, 60, 60, 60, 60 };
		gbl_contentPane.columnWeights = new double[] { 0.0, 0.0, 1.0, 1.0 };
		gbl_contentPane.rowWeights = new double[] { 0.0, 0.0, Double.MIN_VALUE };
		contentPane.setLayout(gbl_contentPane);

		JLabel lblNewLabel = new JLabel("Account Creation");
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 40));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.gridwidth = 5;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 0;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 1;
		gbc_lblNewLabel_1.gridy = 1;
		contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);

		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 11));
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.gridwidth = 3;
		gbc_textField.insets = new Insets(0, 0, 5, 5);
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.gridx = 2;
		gbc_textField.gridy = 1;
		contentPane.add(textField, gbc_textField);
		textField.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("Email");
		lblNewLabel_2.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 1;
		gbc_lblNewLabel_2.gridy = 2;
		contentPane.add(lblNewLabel_2, gbc_lblNewLabel_2);

		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_1.setColumns(10);
		GridBagConstraints gbc_textField_1 = new GridBagConstraints();
		gbc_textField_1.gridwidth = 3;
		gbc_textField_1.insets = new Insets(0, 0, 5, 5);
		gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_1.gridx = 2;
		gbc_textField_1.gridy = 2;
		contentPane.add(textField_1, gbc_textField_1);

		JLabel lblNewLabel_3 = new JLabel("Username (Unique)");
		lblNewLabel_3.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3.gridx = 1;
		gbc_lblNewLabel_3.gridy = 3;
		contentPane.add(lblNewLabel_3, gbc_lblNewLabel_3);

		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_2.setColumns(10);
		GridBagConstraints gbc_textField_2 = new GridBagConstraints();
		gbc_textField_2.gridwidth = 3;
		gbc_textField_2.insets = new Insets(0, 0, 5, 5);
		gbc_textField_2.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_2.gridx = 2;
		gbc_textField_2.gridy = 3;
		contentPane.add(textField_2, gbc_textField_2);

		JLabel lblNewLabel_4 = new JLabel("Password");
		lblNewLabel_4.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
		gbc_lblNewLabel_4.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4.gridx = 1;
		gbc_lblNewLabel_4.gridy = 4;
		contentPane.add(lblNewLabel_4, gbc_lblNewLabel_4);

		textField_3 = new JTextField();
		textField_3.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_3.setColumns(10);
		GridBagConstraints gbc_textField_3 = new GridBagConstraints();
		gbc_textField_3.gridwidth = 3;
		gbc_textField_3.insets = new Insets(0, 0, 5, 5);
		gbc_textField_3.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_3.gridx = 2;
		gbc_textField_3.gridy = 4;
		contentPane.add(textField_3, gbc_textField_3);

		JLabel warning = new JLabel("");
		warning.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_warning = new GridBagConstraints();
		gbc_warning.gridwidth = 3;
		gbc_warning.insets = new Insets(0, 0, 5, 5);
		gbc_warning.gridx = 2;
		gbc_warning.gridy = 5;
		contentPane.add(warning, gbc_warning);

		JButton btnNewButton = new JButton("Create Account");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_2.getText().isBlank() || textField_3.getText().isBlank() || textField.getText().isBlank() || textField_1.getText().isBlank()) {
					warning.setText("Please fill all the fields");
				} else {
					String inputtedUsername = textField_2.getText();
					String inputtedPassword = textField_3.getText();
					String inputtedEmail = textField_1.getText();
					String inputtedName = textField.getText();

					if (SystemDatabase.getInstance().doesAccExists(inputtedUsername)) {
						warning.setText("This username already exists");
						warning.setForeground(Color.RED);
					} else {
						UserAccount newAcc = null;
						if (AccType.equals("Customer")) {
							newAcc = new CustomerAccount(inputtedUsername, inputtedPassword, inputtedName, inputtedEmail);
						} else if (AccType.equals("Administrator")) {
							newAcc = new AdministratorAccount(inputtedUsername, inputtedPassword, inputtedName, inputtedEmail);
						} else if (AccType.equals("Manager")) {
							newAcc = new ManagerAccount(inputtedUsername, inputtedPassword, inputtedName, inputtedEmail);
						}
						Database.addUserAcc(newAcc);
						Database.saveAccMapData();
						setVisible(false);
						dispose();
						Database.loadCurrentUser(inputtedUsername);
						SuccessfulAccCreationPage.main(null);
					}
				}
			}
		});
		btnNewButton.setFont(new Font("Arial Narrow", Font.BOLD, 25));

		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridwidth = 3;
		gbc_btnNewButton.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton.gridx = 2;
		gbc_btnNewButton.gridy = 6;
		contentPane.add(btnNewButton, gbc_btnNewButton);
		AccType = getAccType;
	}

}
