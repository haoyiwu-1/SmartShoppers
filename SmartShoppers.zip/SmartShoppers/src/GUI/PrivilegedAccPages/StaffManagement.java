package GUI.PrivilegedAccPages;

import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.List;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JTable;

import SmartShoppers.ManagerAccount;
import SmartShoppers.SystemDatabase;
import SmartShoppers.UserAccount;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

import javax.swing.JTextField;

public class StaffManagement extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2134304359779481090L;
	private static SystemDatabase Database;
	private JTable existingManagers;
	private JTextField createUsername;
	private JTextField createPassword;
	private JTextField createName;
	private JTextField createEmail;
	private JTextField deleteUsername;

	/**
	 * Create the panel.
	 */
	public StaffManagement() {
		Database = SystemDatabase.getInstance();
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] {100, 100, 100, 100, 100, 200, 200, 200};
		gridBagLayout.rowHeights = new int[] { 70, 30, 30, 70, 70, 0, 70, 70 };
		gridBagLayout.columnWeights = new double[] { 1.0, 1.0, Double.MIN_VALUE, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0,
				0.0 };
		gridBagLayout.rowWeights = new double[] { 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		setLayout(gridBagLayout);

		JTable existingManagers = createNewTable();
		GridBagConstraints gbc_existingManagers = new GridBagConstraints();
		gbc_existingManagers.insets = new Insets(0, 0, 0, 5);
		gbc_existingManagers.gridheight = 5;
		gbc_existingManagers.gridwidth = 7;
		gbc_existingManagers.fill = GridBagConstraints.BOTH;
		gbc_existingManagers.gridx = 2;
		gbc_existingManagers.gridy = 3;
		add(existingManagers, gbc_existingManagers);
		JScrollPane scrollPane = new JScrollPane(existingManagers, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setEnabled(false);
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.insets = new Insets(5, 5, 0, 0);
		gbc_scrollPane.gridwidth = 9;
		gbc_scrollPane.gridheight = 8;
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 3;
		gbc_scrollPane.gridy = 3;
		add(scrollPane, gbc_scrollPane);

		JLabel lblNewLabel_1 = new JLabel("Staff Management");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.BOLD, 65));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.gridwidth = 12;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 0;
		add(lblNewLabel_1, gbc_lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Current Managerial Staff");
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Arial Narrow", Font.BOLD, 50));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.gridwidth = 9;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_2.gridx = 3;
		gbc_lblNewLabel_2.gridy = 2;
		add(lblNewLabel_2, gbc_lblNewLabel_2);

		JLabel lblNewLabel = new JLabel("Create Manager");
		lblNewLabel.setForeground(new Color(154, 205, 50));
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 3;
		add(lblNewLabel, gbc_lblNewLabel);

		createUsername = new JTextField("");
		createUsername.setToolTipText("username");
		GridBagConstraints gbc_createUsername = new GridBagConstraints();
		gbc_createUsername.fill = GridBagConstraints.HORIZONTAL;
		gbc_createUsername.insets = new Insets(15, 35, 15, 35);
		gbc_createUsername.gridx = 0;
		gbc_createUsername.gridy = 4;
		add(createUsername, gbc_createUsername);
		createUsername.setColumns(10);

		createPassword = new JTextField();
		createPassword.setToolTipText("password");
		createPassword.setColumns(10);
		GridBagConstraints gbc_createPassword = new GridBagConstraints();
		gbc_createPassword.gridwidth = 2;
		gbc_createPassword.insets = new Insets(15, 0, 15, 5);
		gbc_createPassword.fill = GridBagConstraints.HORIZONTAL;
		gbc_createPassword.gridx = 1;
		gbc_createPassword.gridy = 4;
		add(createPassword, gbc_createPassword);

		JLabel createWarning = new JLabel("");
		createWarning.setForeground(new Color(154, 205, 50));
		createWarning.setFont(new Font("Arial Narrow", Font.BOLD, 12));
		GridBagConstraints gbc_createWarning = new GridBagConstraints();
		gbc_createWarning.insets = new Insets(0, 0, 5, 5);
		gbc_createWarning.gridx = 0;
		gbc_createWarning.gridy = 5;
		add(createWarning, gbc_createWarning);

		createName = new JTextField();
		createName.setToolTipText("name");
		createName.setColumns(10);
		GridBagConstraints gbc_createName = new GridBagConstraints();
		gbc_createName.insets = new Insets(15, 35, 15, 35);
		gbc_createName.fill = GridBagConstraints.HORIZONTAL;
		gbc_createName.gridx = 0;
		gbc_createName.gridy = 6;
		add(createName, gbc_createName);

		createEmail = new JTextField();
		createEmail.setToolTipText("email");
		createEmail.setColumns(10);
		GridBagConstraints gbc_createEmail = new GridBagConstraints();
		gbc_createEmail.gridwidth = 2;
		gbc_createEmail.insets = new Insets(15, 0, 15, 5);
		gbc_createEmail.fill = GridBagConstraints.HORIZONTAL;
		gbc_createEmail.gridx = 1;
		gbc_createEmail.gridy = 6;
		add(createEmail, gbc_createEmail);

		JLabel lblDeleteManager = new JLabel("Delete Manager");
		lblDeleteManager.setForeground(Color.RED);
		lblDeleteManager.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblDeleteManager = new GridBagConstraints();
		gbc_lblDeleteManager.insets = new Insets(0, 0, 5, 5);
		gbc_lblDeleteManager.gridx = 0;
		gbc_lblDeleteManager.gridy = 7;
		add(lblDeleteManager, gbc_lblDeleteManager);

		deleteUsername = new JTextField();
		deleteUsername.setToolTipText("username");
		deleteUsername.setColumns(10);
		GridBagConstraints gbc_deleteUsername = new GridBagConstraints();
		gbc_deleteUsername.insets = new Insets(15, 35, 15, 35);
		gbc_deleteUsername.fill = GridBagConstraints.HORIZONTAL;
		gbc_deleteUsername.gridx = 0;
		gbc_deleteUsername.gridy = 8;
		add(deleteUsername, gbc_deleteUsername);

		JLabel delWarning = new JLabel("");
		delWarning.setForeground(new Color(154, 205, 50));
		delWarning.setFont(new Font("Arial Narrow", Font.BOLD, 12));
		GridBagConstraints gbc_delWarning = new GridBagConstraints();
		gbc_delWarning.gridwidth = 2;
		gbc_delWarning.insets = new Insets(10, 10, 10, 10);
		gbc_delWarning.gridx = 0;
		gbc_delWarning.gridy = 9;
		add(delWarning, gbc_delWarning);

		JButton btnDelete = new JButton("Delete");
		btnDelete.setEnabled(checkEnableDeleteBtn());
		btnDelete.setHorizontalAlignment(SwingConstants.LEFT);
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Boolean managerAccExists = false;
				String username = deleteUsername.getText();
				if (Database.doesAccExists(username)) {
					if (Database.getAccDetails(username) instanceof ManagerAccount) {
						managerAccExists = true;
					}
				}
				if (!username.isBlank() && managerAccExists) {
					// delete acc
					int result = JOptionPane.showConfirmDialog(null,
							"Are you sure you want to delete this manager account and associated data permanently?",
							"Delete Account", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					if (result == JOptionPane.YES_OPTION) {
						// delete acc
						Database.removeUserAccount(username);
						Database.saveAccMapData();
						JOptionPane.showMessageDialog(null, "The manager account and data has been deleted.");
					} else {
						// don't delete acc
						JOptionPane.showMessageDialog(null, "Redirecting back to staff management page...");
					}
				} else if (!managerAccExists) {
					delWarning.setText("Account doesn't exist (or blank input)");
					delWarning.setForeground(Color.RED);
					JOptionPane.showMessageDialog(null, "Account doesn't exist or invalid input...");
					delWarning.setText("");
				}
				deleteUsername.setText("");
				scrollPane.setViewportView(createNewTable());
				scrollPane.setEnabled(false);
				btnDelete.setEnabled(checkEnableDeleteBtn());
			}
		});
		btnDelete.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_btnDelete = new GridBagConstraints();
		gbc_btnDelete.gridwidth = 2;
		gbc_btnDelete.insets = new Insets(0, 0, 5, 5);
		gbc_btnDelete.gridx = 1;
		gbc_btnDelete.gridy = 7;
		add(btnDelete, gbc_btnDelete);

		JButton btnNewButton = new JButton("Create");
		btnNewButton.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String newUser = null;
				String newPass = null;
				String newName = null;
				String newEmail = null;
				if (!createUsername.getText().isBlank()) {
					newUser = createUsername.getText();
				}
				if (!createPassword.getText().isBlank()) {
					newPass = createPassword.getText();
				}
				if (!createName.getText().isBlank()) {
					newName = createName.getText();
				}
				if (!createEmail.getText().isBlank()) {
					newEmail = createEmail.getText();
				}
				if (Database.doesAccExists(newUser)) {
					// give warning acc exists
					createWarning.setText("Account already exists");
					createWarning.setForeground(Color.RED);
					JOptionPane.showMessageDialog(null, "Account already exists.");
					createWarning.setText("");
					createUsername.setText("");
				} else if (createUsername.getText().isBlank() || createPassword.getText().isBlank()
						|| createName.getText().isBlank() || createEmail.getText().isBlank()) {
					createWarning.setText("Fill all fields");
					createWarning.setForeground(Color.RED);
					JOptionPane.showMessageDialog(null, "Fill all fields.");
					createWarning.setText("");
				} else {
					UserAccount newAcc = new ManagerAccount(newUser, newPass, newName, newEmail);
					Database.addUserAcc(newAcc);
					Database.saveAccMapData();
					JOptionPane.showMessageDialog(null, "Manager account created.");
					createUsername.setText("");
					createPassword.setText("");
					createName.setText("");
					createEmail.setText("");
				}
				scrollPane.setViewportView(createNewTable());
				scrollPane.setEnabled(false);
				btnDelete.setEnabled(checkEnableDeleteBtn());
			};
		});
		btnNewButton.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridwidth = 2;
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 1;
		gbc_btnNewButton.gridy = 3;
		add(btnNewButton, gbc_btnNewButton);

		setPreferredSize(new Dimension(1500, 700));
	}

	public JTable createNewTable() {
		Database.loadAccMapData();
		List<UserAccount> currentManagers = Database.getManagers();
		Boolean managersExist = false;
		int size = currentManagers.size();
		String[][] actualData = new String[size][5];
		int index = 0;
		if (currentManagers.size() > 0) {
			managersExist = true;
			for (UserAccount m : currentManagers) {
				actualData[index][0] = m.getIdentifier();
				actualData[index][1] = m.getPassword();
				actualData[index][2] = m.getName();
				actualData[index][3] = m.getEmail();
				if (((ManagerAccount) m).getStore() != null) {
					actualData[index][4] = ((ManagerAccount) m).getStore().getId();
				} else {
					actualData[index][4] = "N/A (Empty)";
				}
				index++;
			}
		}

		String[][] emptyData = new String[1][5];
		emptyData[0][0] = "N/A (Empty)";
		emptyData[0][1] = "N/A (Empty)";
		emptyData[0][2] = "N/A (Empty)";
		emptyData[0][3] = "N/A (Empty)";
		emptyData[0][4] = "N/A (Empty)";

		String[] headers = { "Username", "Password", "Name", "Email", "StoreID"};
		if (managersExist) {
			existingManagers = new JTable(actualData, headers);
		} else {
			existingManagers = new JTable(emptyData, headers);
		}
		existingManagers.getTableHeader().setReorderingAllowed(false);
		existingManagers.getTableHeader().setFont(new Font("Arial Narrow", Font.BOLD, 20));
		existingManagers.getTableHeader().setResizingAllowed(false);
		existingManagers.setEnabled(false);
		existingManagers.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		return existingManagers;
	}
	
	public boolean checkEnableDeleteBtn() {
		if (Database.getManagers().size() > 0) {
			return true;
		} else {
			return false;
		}
	}

}
