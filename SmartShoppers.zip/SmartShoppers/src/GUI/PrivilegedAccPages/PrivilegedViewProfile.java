package GUI.PrivilegedAccPages;

import javax.swing.JPanel;

import SmartShoppers.SystemDatabase;
import SmartShoppers.UserAccount;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

public class PrivilegedViewProfile extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7664555704826244385L;
	private static SystemDatabase Database;
	/**
	 * Create the panel.
	 */
	public PrivilegedViewProfile(String username) {
		Database = SystemDatabase.getInstance();
		UserAccount accDetails = Database.getAccDetails(username);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 75, 75, 75, 75, 75, 75, 75, 75 };
		gridBagLayout.rowHeights = new int[] { 35, 55, 55, 55, 55, 55, 55 };
		gridBagLayout.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		gridBagLayout.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		setLayout(gridBagLayout);

		JLabel lblNewLabel = new JLabel("Profile Details");
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 40));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridwidth = 4;
		gbc_lblNewLabel.gridx = 2;
		gbc_lblNewLabel.gridy = 1;
		add(lblNewLabel, gbc_lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridwidth = 2;
		gbc_lblNewLabel_1.gridx = 2;
		gbc_lblNewLabel_1.gridy = 2;
		add(lblNewLabel_1, gbc_lblNewLabel_1);

		JLabel usernameOut = new JLabel("");
		usernameOut.setText(accDetails.getIdentifier());
		usernameOut.setForeground(Color.BLUE);
		usernameOut.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_usernameOut = new GridBagConstraints();
		gbc_usernameOut.gridwidth = 2;
		gbc_usernameOut.insets = new Insets(0, 0, 5, 5);
		gbc_usernameOut.gridx = 4;
		gbc_usernameOut.gridy = 2;
		add(usernameOut, gbc_usernameOut);

		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.gridwidth = 2;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 2;
		gbc_lblNewLabel_2.gridy = 3;
		add(lblNewLabel_2, gbc_lblNewLabel_2);

		JLabel passwordOut = new JLabel("");
		passwordOut.setText(accDetails.getPassword());
		passwordOut.setForeground(Color.BLUE);
		passwordOut.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_passwordOut = new GridBagConstraints();
		gbc_passwordOut.gridwidth = 2;
		gbc_passwordOut.insets = new Insets(0, 0, 5, 5);
		gbc_passwordOut.gridx = 4;
		gbc_passwordOut.gridy = 3;
		add(passwordOut, gbc_passwordOut);

		JLabel lblNewLabel_2_1 = new JLabel("Name");
		lblNewLabel_2_1.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_2_1 = new GridBagConstraints();
		gbc_lblNewLabel_2_1.gridwidth = 2;
		gbc_lblNewLabel_2_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2_1.gridx = 2;
		gbc_lblNewLabel_2_1.gridy = 4;
		add(lblNewLabel_2_1, gbc_lblNewLabel_2_1);

		JLabel nameOut = new JLabel("");
		nameOut.setText(accDetails.getName());
		nameOut.setForeground(Color.BLUE);
		nameOut.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_nameOut = new GridBagConstraints();
		gbc_nameOut.gridwidth = 2;
		gbc_nameOut.insets = new Insets(0, 0, 5, 5);
		gbc_nameOut.gridx = 4;
		gbc_nameOut.gridy = 4;
		add(nameOut, gbc_nameOut);

		JLabel lblNewLabel_2_2 = new JLabel("Email");
		lblNewLabel_2_2.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_2_2 = new GridBagConstraints();
		gbc_lblNewLabel_2_2.gridwidth = 2;
		gbc_lblNewLabel_2_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2_2.gridx = 2;
		gbc_lblNewLabel_2_2.gridy = 5;
		add(lblNewLabel_2_2, gbc_lblNewLabel_2_2);

		JLabel emailOut = new JLabel("");
		emailOut.setText(accDetails.getEmail());
		emailOut.setForeground(Color.BLUE);
		emailOut.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_emailOut = new GridBagConstraints();
		gbc_emailOut.gridwidth = 2;
		gbc_emailOut.insets = new Insets(0, 0, 5, 5);
		gbc_emailOut.gridx = 4;
		gbc_emailOut.gridy = 5;
		add(emailOut, gbc_emailOut);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("2FA:");
		lblNewLabel_2_2_1.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_2_2_1 = new GridBagConstraints();
		gbc_lblNewLabel_2_2_1.gridwidth = 2;
		gbc_lblNewLabel_2_2_1.insets = new Insets(0, 0, 0, 5);
		gbc_lblNewLabel_2_2_1.gridx = 2;
		gbc_lblNewLabel_2_2_1.gridy = 6;
		add(lblNewLabel_2_2_1, gbc_lblNewLabel_2_2_1);
		
		JLabel TwoFAOut = new JLabel((String) null);
		if (accDetails.getAuth()) {
			TwoFAOut.setText("ON");
		} else {
			TwoFAOut.setText("OFF");
		}
		TwoFAOut.setForeground(Color.BLUE);
		TwoFAOut.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_TwoFAOut = new GridBagConstraints();
		gbc_TwoFAOut.gridwidth = 2;
		gbc_TwoFAOut.insets = new Insets(0, 0, 0, 5);
		gbc_TwoFAOut.gridx = 4;
		gbc_TwoFAOut.gridy = 6;
		add(TwoFAOut, gbc_TwoFAOut);
		setBounds(100, 100, 1200, 800);
	}

}
