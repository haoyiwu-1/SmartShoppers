package GUI.PrivilegedAccPages;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import javax.swing.JPanel;
import javax.swing.border.Border;

import SmartShoppers.SystemDatabase;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Font;

public class ShowWeeklySaleItems extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3526596799857721057L;
	private static SystemDatabase Database;
	/**
	 * Create the panel.
	 */
	public ShowWeeklySaleItems() {
		Database = SystemDatabase.getInstance();
		setPreferredSize(new Dimension(1500, 700));
		GridBagLayout gridBagLayout_1 = new GridBagLayout();
		gridBagLayout_1.columnWidths = new int[] {500, 500, 500};
		gridBagLayout_1.rowHeights = new int[] {140, 140, 140, 140, 140};
		gridBagLayout_1.columnWeights = new double[]{0.0, 0.0, 0.0};
		gridBagLayout_1.rowWeights = new double[]{0.0};
		setLayout(gridBagLayout_1);
		
		JLabel lblNewLabel_1 = new JLabel("Weekly Sale Items");
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.BOLD, 50));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_1.gridwidth = 3;
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 0;
		add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		JLabel showWeeklySaleItems = new JLabel("");
		Border blackline = BorderFactory.createLineBorder(Color.black);
		showWeeklySaleItems.setBorder(blackline);
		if (Database.getWeeklySaleItems().size() > 0) {
			showWeeklySaleItems.setText(Database.getWeeklySaleItems().toString());
		} else {
			showWeeklySaleItems.setText("No weekly sale items currently");
		}
		showWeeklySaleItems.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_showWeeklySaleItems = new GridBagConstraints();
		gbc_showWeeklySaleItems.gridheight = 3;
		gbc_showWeeklySaleItems.gridwidth = 3;
		gbc_showWeeklySaleItems.insets = new Insets(0, 0, 5, 5);
		gbc_showWeeklySaleItems.gridx = 0;
		gbc_showWeeklySaleItems.gridy = 1;
		add(showWeeklySaleItems, gbc_showWeeklySaleItems);
	}

}
