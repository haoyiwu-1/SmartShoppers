package GUI.PrivilegedAccPages;

import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.Map;
import java.util.Set;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JTable;

import SmartShoppers.AdministratorAccount;
import SmartShoppers.Item;
import SmartShoppers.ManagerAccount;
import SmartShoppers.SystemDatabase;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JFrame;
import javax.swing.JComboBox;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;

public class UpdateStore extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 347324484011489801L;
	private static SystemDatabase Database;
	private JTable existingItems;
	private JTextField createItemID;
	private JTextField createItemName;
	private JTextField deleteItemID;
	private JTextField createItemPrice;
	private JTextField createItemQuantity;
	private JTextField createItemCategory;
	private JTextField updateItem;
	private JTextField newManager;
	private boolean adminAccess;
	private JTextField addSaleItemForSaleField;
	private JTextField removeSaleItemField;
	private JTextField updateStoreLocField;

	/**
	 * Create the panel.
	 */
	public UpdateStore(String storeid, Component parent) {
		Database = SystemDatabase.getInstance();
		if (Database.getCurrentUser() instanceof AdministratorAccount) {
			adminAccess = true;
		} else {
			adminAccess = false;
		}
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 100, 100, 100, 100, 100, 200, 200, 200, 0 };
		gridBagLayout.columnWeights = new double[] { 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0 };
		gridBagLayout.rowWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
				0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		setLayout(gridBagLayout);

		JTable existingItems = createNewTable(storeid);
		GridBagConstraints gbc_existingItems = new GridBagConstraints();
		gbc_existingItems.insets = new Insets(0, 0, 0, 5);
		gbc_existingItems.gridheight = 5;
		gbc_existingItems.gridwidth = 7;
		gbc_existingItems.fill = GridBagConstraints.BOTH;
		gbc_existingItems.gridx = 2;
		gbc_existingItems.gridy = 3;
		add(existingItems, gbc_existingItems);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setText(storeid + " - Details");
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.BOLD, 50));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.gridwidth = 9;
		gbc_lblNewLabel_1.gridheight = 3;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 1;
		gbc_lblNewLabel_1.gridy = 0;
		add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		JButton backToStoreManagement = new JButton("Store Managment");
		if (!adminAccess) {
			backToStoreManagement.setEnabled(false);
		}
		backToStoreManagement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//back to store page
				JFrame parentFrame = (JFrame) parent;
				parentFrame.getContentPane().removeAll();
				StoreManagement viewStoreManagement = new StoreManagement(parent);
				parentFrame.getContentPane().add(viewStoreManagement);
				parentFrame.pack();
				parentFrame.getContentPane().revalidate();
				parentFrame.getContentPane().repaint();
			}
		});
		backToStoreManagement.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_backToStoreManagement = new GridBagConstraints();
		gbc_backToStoreManagement.gridheight = 3;
		gbc_backToStoreManagement.insets = new Insets(0, 0, 5, 5);
		gbc_backToStoreManagement.gridx = 10;
		gbc_backToStoreManagement.gridy = 0;
		add(backToStoreManagement, gbc_backToStoreManagement);

		JLabel lblNewLabel_2 = new JLabel("Current Items");
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Arial Narrow", Font.BOLD, 40));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.gridheight = 2;
		gbc_lblNewLabel_2.gridwidth = 4;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 3;
		gbc_lblNewLabel_2.gridy = 3;
		add(lblNewLabel_2, gbc_lblNewLabel_2);

		JLabel lblNewLabel = new JLabel("Create Item");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(154, 205, 50));
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.gridheight = 2;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 3;
		add(lblNewLabel, gbc_lblNewLabel);

		JScrollPane scrollPane = new JScrollPane(existingItems, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setEnabled(false);
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.insets = new Insets(5, 5, 0, 5);
		gbc_scrollPane.gridwidth = 4;
		gbc_scrollPane.gridheight = 15;
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 3;
		gbc_scrollPane.gridy = 5;
		add(scrollPane, gbc_scrollPane);

		JLabel lblNewLabel_3 = new JLabel("Opening Time");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.gridheight = 2;
		gbc_lblNewLabel_3.gridwidth = 3;
		gbc_lblNewLabel_3.insets = new Insets(0, 5, 5, 5);
		gbc_lblNewLabel_3.gridx = 7;
		gbc_lblNewLabel_3.gridy = 3;
		add(lblNewLabel_3, gbc_lblNewLabel_3);

		JLabel lblNewLabel_3_1 = new JLabel("Closing Time");
		lblNewLabel_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_3_1 = new GridBagConstraints();
		gbc_lblNewLabel_3_1.gridheight = 2;
		gbc_lblNewLabel_3_1.gridwidth = 2;
		gbc_lblNewLabel_3_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3_1.gridx = 10;
		gbc_lblNewLabel_3_1.gridy = 3;
		add(lblNewLabel_3_1, gbc_lblNewLabel_3_1);

		createItemID = new JTextField("");
		createItemID.setToolTipText("ID");
		GridBagConstraints gbc_createItemID = new GridBagConstraints();
		gbc_createItemID.fill = GridBagConstraints.HORIZONTAL;
		gbc_createItemID.insets = new Insets(15, 35, 15, 35);
		gbc_createItemID.gridx = 0;
		gbc_createItemID.gridy = 5;
		add(createItemID, gbc_createItemID);
		createItemID.setColumns(10);

		createItemName = new JTextField();
		createItemName.setToolTipText("Name");
		createItemName.setColumns(10);
		GridBagConstraints gbc_createItemName = new GridBagConstraints();
		gbc_createItemName.gridwidth = 2;
		gbc_createItemName.insets = new Insets(15, 35, 15, 35);
		gbc_createItemName.fill = GridBagConstraints.HORIZONTAL;
		gbc_createItemName.gridx = 1;
		gbc_createItemName.gridy = 5;
		add(createItemName, gbc_createItemName);

		JComboBox<String> opentimeCombo = new JComboBox<String>();
		opentimeCombo.setModel(new DefaultComboBoxModel<String>(
				new String[] { "6:00am", "7:00am", "8:00am", "9:00am", "10:00am", "11:00am", "12:00am", "1:00pm",
						"2:00pm", "3:00pm", "4:00pm", "5:00pm", "6:00pm", "7:00pm", "8:00pm", "9:00pm", "10:00pm",
						"11:00pm", "12:00pm", "1:00am", "2:00am", "3:00am", "4:00am", "5:00am" }));
		opentimeCombo.setToolTipText("opening time");
		opentimeCombo.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		GridBagConstraints gbc_opentimeCombo = new GridBagConstraints();
		gbc_opentimeCombo.gridwidth = 3;
		gbc_opentimeCombo.insets = new Insets(0, 15, 5, 15);
		gbc_opentimeCombo.fill = GridBagConstraints.HORIZONTAL;
		gbc_opentimeCombo.gridx = 7;
		gbc_opentimeCombo.gridy = 5;
		add(opentimeCombo, gbc_opentimeCombo);

		JComboBox<String> closingTimeCombo = new JComboBox<String>();
		closingTimeCombo.setModel(new DefaultComboBoxModel<String>(
				new String[] { "6:00am", "7:00am", "8:00am", "9:00am", "10:00am", "11:00am", "12:00am", "1:00pm",
						"2:00pm", "3:00pm", "4:00pm", "5:00pm", "6:00pm", "7:00pm", "8:00pm", "9:00pm", "10:00pm",
						"11:00pm", "12:00pm", "1:00am", "2:00am", "3:00am", "4:00am", "5:00am" }));
		closingTimeCombo.setToolTipText("closing time");
		closingTimeCombo.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		GridBagConstraints gbc_closingTimeCombo = new GridBagConstraints();
		gbc_closingTimeCombo.gridwidth = 2;
		gbc_closingTimeCombo.insets = new Insets(0, 10, 5, 10);
		gbc_closingTimeCombo.fill = GridBagConstraints.HORIZONTAL;
		gbc_closingTimeCombo.gridx = 10;
		gbc_closingTimeCombo.gridy = 5;
		add(closingTimeCombo, gbc_closingTimeCombo);

		createItemPrice = new JTextField("");
		createItemPrice.setToolTipText("Price");
		createItemPrice.setColumns(10);
		GridBagConstraints gbc_createItemPrice = new GridBagConstraints();
		gbc_createItemPrice.insets = new Insets(10, 35, 10, 35);
		gbc_createItemPrice.fill = GridBagConstraints.HORIZONTAL;
		gbc_createItemPrice.gridx = 0;
		gbc_createItemPrice.gridy = 6;
		add(createItemPrice, gbc_createItemPrice);

		createItemQuantity = new JTextField("");
		createItemQuantity.setToolTipText("Quantity");
		createItemQuantity.setColumns(10);
		GridBagConstraints gbc_createItemQuantity = new GridBagConstraints();
		gbc_createItemQuantity.gridwidth = 2;
		gbc_createItemQuantity.insets = new Insets(10, 35, 10, 35);
		gbc_createItemQuantity.fill = GridBagConstraints.HORIZONTAL;
		gbc_createItemQuantity.gridx = 1;
		gbc_createItemQuantity.gridy = 6;
		add(createItemQuantity, gbc_createItemQuantity);

		JLabel lblNewLabel_4 = new JLabel("Current Opening Time");
		lblNewLabel_4.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
		gbc_lblNewLabel_4.gridwidth = 3;
		gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4.gridx = 7;
		gbc_lblNewLabel_4.gridy = 7;
		add(lblNewLabel_4, gbc_lblNewLabel_4);

		JLabel lblNewLabel_4_1 = new JLabel("Current Closing Time");
		lblNewLabel_4_1.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_4_1 = new GridBagConstraints();
		gbc_lblNewLabel_4_1.gridwidth = 2;
		gbc_lblNewLabel_4_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4_1.gridx = 10;
		gbc_lblNewLabel_4_1.gridy = 7;
		add(lblNewLabel_4_1, gbc_lblNewLabel_4_1);

		createItemCategory = new JTextField("");
		createItemCategory.setToolTipText("Category");
		createItemCategory.setColumns(10);
		GridBagConstraints gbc_createItemCategory = new GridBagConstraints();
		gbc_createItemCategory.insets = new Insets(10, 35, 10, 35);
		gbc_createItemCategory.fill = GridBagConstraints.HORIZONTAL;
		gbc_createItemCategory.gridx = 0;
		gbc_createItemCategory.gridy = 8;
		add(createItemCategory, gbc_createItemCategory);

		JLabel currentOpenTime = new JLabel("");
		currentOpenTime.setText(Database.getStoreById(storeid).getOpentime());
		currentOpenTime.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_currentOpenTime = new GridBagConstraints();
		gbc_currentOpenTime.gridwidth = 3;
		gbc_currentOpenTime.insets = new Insets(0, 0, 5, 5);
		gbc_currentOpenTime.gridx = 7;
		gbc_currentOpenTime.gridy = 8;
		add(currentOpenTime, gbc_currentOpenTime);

		JLabel currentCloseTime = new JLabel("");
		currentCloseTime.setText(Database.getStoreById(storeid).getClosingtime());
		currentCloseTime.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_currentCloseTime = new GridBagConstraints();
		gbc_currentCloseTime.gridwidth = 2;
		gbc_currentCloseTime.insets = new Insets(0, 0, 5, 5);
		gbc_currentCloseTime.gridx = 10;
		gbc_currentCloseTime.gridy = 8;
		add(currentCloseTime, gbc_currentCloseTime);

		JLabel lblUpdateItem = new JLabel("Update Item");
		lblUpdateItem.setHorizontalAlignment(SwingConstants.CENTER);
		lblUpdateItem.setForeground(Color.YELLOW);
		lblUpdateItem.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblUpdateItem = new GridBagConstraints();
		gbc_lblUpdateItem.insets = new Insets(0, 0, 5, 5);
		gbc_lblUpdateItem.gridx = 0;
		gbc_lblUpdateItem.gridy = 9;
		add(lblUpdateItem, gbc_lblUpdateItem);

		JButton updateItemBtn = new JButton("Update Item");
		updateItemBtn.setEnabled(checkEnableActionBtns(storeid));
		updateItemBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// create new update item page
				// where we have to add in all the things that people should be able to view
				boolean itemExists = false;
				String itemId = updateItem.getText();
				if (Database.getStoreById(storeid).getItems().containsKey(itemId)) {
					itemExists = true;
				}
				if (!itemId.isBlank() && itemExists) {
					// go to update item page
					JFrame parentFrame = (JFrame) parent;
					parentFrame.getContentPane().removeAll();
					UpdateItem viewUpdateItem = new UpdateItem(itemId, storeid, parent);
					parentFrame.getContentPane().add(viewUpdateItem);
					parentFrame.pack();
					parentFrame.getContentPane().revalidate();
					parentFrame.getContentPane().repaint();
				} else if (!itemExists) {
					JOptionPane.showMessageDialog(null, "Item doesn't exist or invalid input...");
				}
				updateItem.setText("");
				updateItemBtn.setEnabled(checkEnableActionBtns(storeid));
			}
		});
		updateItemBtn.setHorizontalAlignment(SwingConstants.LEFT);
		updateItemBtn.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_updateItemBtn = new GridBagConstraints();
		gbc_updateItemBtn.gridwidth = 2;
		gbc_updateItemBtn.insets = new Insets(0, 0, 5, 5);
		gbc_updateItemBtn.gridx = 1;
		gbc_updateItemBtn.gridy = 9;
		add(updateItemBtn, gbc_updateItemBtn);

		JButton updateItemBtn_1_1 = new JButton("Update Time");
		updateItemBtn_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// get the time from the combo boxes and set this store to those times
				String newOpentime = String.valueOf(opentimeCombo.getSelectedItem());
				String newClosetime = String.valueOf(closingTimeCombo.getSelectedItem());
				Database.getStoreById(storeid).updateOpening(newOpentime);
				Database.getStoreById(storeid).updateClosing(newClosetime);
				Database.saveStoreData();
				JOptionPane.showMessageDialog(null, "Store times have been updated.");
				currentOpenTime.setText(Database.getStoreById(storeid).getOpentime());
				currentCloseTime.setText(Database.getStoreById(storeid).getClosingtime());
			}
		});
		updateItemBtn_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		updateItemBtn_1_1.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_updateItemBtn_1_1 = new GridBagConstraints();
		gbc_updateItemBtn_1_1.gridwidth = 3;
		gbc_updateItemBtn_1_1.insets = new Insets(0, 0, 5, 5);
		gbc_updateItemBtn_1_1.gridx = 7;
		gbc_updateItemBtn_1_1.gridy = 9;
		add(updateItemBtn_1_1, gbc_updateItemBtn_1_1);

		updateItem = new JTextField("");
		updateItem.setToolTipText("Item ID");
		updateItem.setColumns(10);
		GridBagConstraints gbc_updateItem = new GridBagConstraints();
		gbc_updateItem.insets = new Insets(10, 35, 10, 35);
		gbc_updateItem.fill = GridBagConstraints.HORIZONTAL;
		gbc_updateItem.gridx = 0;
		gbc_updateItem.gridy = 10;
		add(updateItem, gbc_updateItem);

		JLabel lblNewLabel_3_2 = new JLabel("Manage Sale Items");
		lblNewLabel_3_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_2.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_3_2 = new GridBagConstraints();
		gbc_lblNewLabel_3_2.gridwidth = 5;
		gbc_lblNewLabel_3_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3_2.gridx = 7;
		gbc_lblNewLabel_3_2.gridy = 10;
		add(lblNewLabel_3_2, gbc_lblNewLabel_3_2);

		JLabel lblDeleteManager = new JLabel("Delete Item");
		lblDeleteManager.setForeground(Color.RED);
		lblDeleteManager.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblDeleteManager = new GridBagConstraints();
		gbc_lblDeleteManager.insets = new Insets(0, 0, 5, 5);
		gbc_lblDeleteManager.gridx = 0;
		gbc_lblDeleteManager.gridy = 11;
		add(lblDeleteManager, gbc_lblDeleteManager);

		JLabel lblNewLabel_4_2 = new JLabel("Current Sale Items");
		lblNewLabel_4_2.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel_4_2 = new GridBagConstraints();
		gbc_lblNewLabel_4_2.gridwidth = 6;
		gbc_lblNewLabel_4_2.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_4_2.gridx = 7;
		gbc_lblNewLabel_4_2.gridy = 11;
		add(lblNewLabel_4_2, gbc_lblNewLabel_4_2);

		JLabel currentSaleItems = new JLabel("");
		currentSaleItems.setBorder(BorderFactory.createLineBorder(Color.black));
		currentSaleItems.setText(Database.getStoreById(storeid).showStaffSaleItems());
		currentSaleItems.setHorizontalAlignment(SwingConstants.CENTER);
		currentSaleItems.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		GridBagConstraints gbc_currentSaleItems = new GridBagConstraints();
		gbc_currentSaleItems.gridheight = 2;
		gbc_currentSaleItems.gridwidth = 5;
		gbc_currentSaleItems.insets = new Insets(5, 0, 5, 5);
		gbc_currentSaleItems.gridx = 7;
		gbc_currentSaleItems.gridy = 12;
		add(currentSaleItems, gbc_currentSaleItems);

		addSaleItemForSaleField = new JTextField();
		addSaleItemForSaleField.setToolTipText("Item ID to add");
		GridBagConstraints gbc_addSaleItemForSaleField = new GridBagConstraints();
		gbc_addSaleItemForSaleField.insets = new Insets(0, 30, 5, 30);
		gbc_addSaleItemForSaleField.fill = GridBagConstraints.HORIZONTAL;
		gbc_addSaleItemForSaleField.gridx = 7;
		gbc_addSaleItemForSaleField.gridy = 14;
		add(addSaleItemForSaleField, gbc_addSaleItemForSaleField);
		addSaleItemForSaleField.setColumns(10);

		JLabel currentManagerLbl = new JLabel("");
		currentManagerLbl.setText(Database.getStoreById(storeid).getManagerName());
		currentManagerLbl.setForeground(Color.BLACK);
		currentManagerLbl.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_currentManagerLbl = new GridBagConstraints();
		gbc_currentManagerLbl.gridwidth = 2;
		gbc_currentManagerLbl.insets = new Insets(0, 0, 5, 5);
		gbc_currentManagerLbl.gridx = 1;
		gbc_currentManagerLbl.gridy = 15;
		add(currentManagerLbl, gbc_currentManagerLbl);

		JButton removeManager = new JButton("Remove Manager");
		removeManager.setEnabled(checkForManagerExistence(storeid));
		if (!adminAccess) {
			removeManager.setEnabled(false);
		}
		removeManager.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// simply removes the current manager and leaves it blank
				// change manager for this store
				int result = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to remove current manager from this store?", "Remove Manager",
						JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
				if (result == JOptionPane.YES_OPTION) {
					// need to set manager with no store
					// need to set store to have no manager
					String currentManagerUsername = Database.getStoreById(storeid).getManagerUsername();
					// remove manager from this store
					String pass = Database.getAccDetails(currentManagerUsername).getPassword();
					String name = Database.getAccDetails(currentManagerUsername).getName();
					String email = Database.getAccDetails(currentManagerUsername).getEmail();
					ManagerAccount resetManager = new ManagerAccount(currentManagerUsername, pass, name, email);
					Database.getStoreById(storeid).removeManager();
					Database.removeUserAccount(currentManagerUsername);
					Database.addUserAcc(resetManager);
					Database.saveAccMapData();
					Database.saveStoreData();
					JOptionPane.showMessageDialog(null, "The manager for this store has been removed.");
				} else {
					// don't change manager for this store
					JOptionPane.showMessageDialog(null, "Redirecting back to " + storeid + " details page...");
				}
				removeManager.setEnabled(checkForManagerExistence(storeid));
				currentManagerLbl.setText(Database.getStoreById(storeid).getManagerName());
			}
		});

		removeSaleItemField = new JTextField();
		removeSaleItemField.setToolTipText("Item ID to remove");
		removeSaleItemField.setColumns(10);
		GridBagConstraints gbc_removeSaleItemField = new GridBagConstraints();
		gbc_removeSaleItemField.insets = new Insets(0, 30, 5, 30);
		gbc_removeSaleItemField.fill = GridBagConstraints.HORIZONTAL;
		gbc_removeSaleItemField.gridx = 7;
		gbc_removeSaleItemField.gridy = 15;
		add(removeSaleItemField, gbc_removeSaleItemField);

		JButton removeFromSaleListBtn = new JButton("Remove from Sale List");
		removeFromSaleListBtn.setEnabled(checkForSaleItemExistence(storeid));
		removeFromSaleListBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Item toRemove = null;
				if (!removeSaleItemField.getText().isBlank()) {
					// check for item id existence in the sale item list for this store
					String itemId = removeSaleItemField.getText();
					boolean saleItemExistence = false;
					Set<Item> saleItems = Database.getStoreById(storeid).getSaleItems();
					for (Item i : saleItems) {
						if (i.getId().equals(itemId)) {
							saleItemExistence = true;
							toRemove = i;
						}
					}
					if (!saleItemExistence) {
						JOptionPane.showMessageDialog(null,
								"This item ID (item) does not exist in the sale item list for this store. Please refer to the list of"
										+ " sale items to the above for reference of what items are available currently in this store's "
										+ "sale item list.");
					} else {
						Database.getStoreById(storeid).removeSaleItem(toRemove);
						Database.saveStoreData();
						JOptionPane.showMessageDialog(null, "Item with " + itemId + " removed from sale item list.");
						currentSaleItems.setText(Database.getStoreById(storeid).showStaffSaleItems());
					}
				}
				removeFromSaleListBtn.setEnabled(checkForSaleItemExistence(storeid));
			}
		});
		removeFromSaleListBtn.setHorizontalAlignment(SwingConstants.LEFT);
		removeFromSaleListBtn.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_removeFromSaleListBtn = new GridBagConstraints();
		gbc_removeFromSaleListBtn.gridwidth = 3;
		gbc_removeFromSaleListBtn.insets = new Insets(0, 0, 5, 5);
		gbc_removeFromSaleListBtn.gridx = 9;
		gbc_removeFromSaleListBtn.gridy = 15;
		add(removeFromSaleListBtn, gbc_removeFromSaleListBtn);

		JButton addToSaleListBtn = new JButton("Add to Sale List");
		addToSaleListBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Item toAdd = null;
				if (!addSaleItemForSaleField.getText().isBlank()) {
					String itemId = addSaleItemForSaleField.getText();
					// check for item existence in the store if it doesn't exist not possible to put
					// on sale
					if (!Database.getStoreById(storeid).getItems().containsKey(itemId)) {
						JOptionPane.showMessageDialog(null,
								"This item ID (item) does not exist in this store. Please refer to the table of "
										+ "items to the left for reference of what items are available in this store.");
					} else {
						toAdd = Database.getStoreById(storeid).getItems().get(itemId);
						Database.getStoreById(storeid).addSaleItem(toAdd);
						Database.saveStoreData();
						JOptionPane.showMessageDialog(null,
								"The item associated with this item ID has been put on sale for " + storeid + ".");
						currentSaleItems.setText(Database.getStoreById(storeid).showStaffSaleItems());
					}
				}
				removeFromSaleListBtn.setEnabled(checkForSaleItemExistence(storeid));
			}
		});
		addToSaleListBtn.setHorizontalAlignment(SwingConstants.LEFT);
		addToSaleListBtn.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_addToSaleListBtn = new GridBagConstraints();
		gbc_addToSaleListBtn.gridwidth = 3;
		gbc_addToSaleListBtn.insets = new Insets(0, 0, 5, 5);
		gbc_addToSaleListBtn.gridx = 9;
		gbc_addToSaleListBtn.gridy = 14;
		add(addToSaleListBtn, gbc_addToSaleListBtn);

		JButton updateStoreMapBtn = new JButton("Update Store Map");
		updateStoreMapBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// go to store map page
				// passing the current store id
				JFrame parentFrame = (JFrame) parent;
				parentFrame.getContentPane().removeAll();
				UpdateStoreMap viewUpdateStoreMap = new UpdateStoreMap(storeid, parent);
				parentFrame.getContentPane().add(viewUpdateStoreMap);
				parentFrame.pack();
				parentFrame.getContentPane().revalidate();
				parentFrame.getContentPane().repaint();
			}
		});
		updateStoreMapBtn.setHorizontalAlignment(SwingConstants.LEFT);
		updateStoreMapBtn.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_updateStoreMapBtn = new GridBagConstraints();
		gbc_updateStoreMapBtn.gridwidth = 5;
		gbc_updateStoreMapBtn.insets = new Insets(0, 0, 5, 5);
		gbc_updateStoreMapBtn.gridx = 7;
		gbc_updateStoreMapBtn.gridy = 16;
		add(updateStoreMapBtn, gbc_updateStoreMapBtn);

		removeManager.setHorizontalAlignment(SwingConstants.LEFT);
		removeManager.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_removeManager = new GridBagConstraints();
		gbc_removeManager.gridheight = 2;
		gbc_removeManager.insets = new Insets(0, 0, 5, 5);
		gbc_removeManager.gridx = 0;
		gbc_removeManager.gridy = 17;
		add(removeManager, gbc_removeManager);

		JButton btnDelete = new JButton("Delete Item");
		btnDelete.setEnabled(checkEnableActionBtns(storeid));
		btnDelete.setHorizontalAlignment(SwingConstants.LEFT);
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean itemExists = false;
				Item itemToRemove = null;
				String itemID = deleteItemID.getText();
				itemToRemove = Database.getStoreById(storeid).getItems().get(itemID);
				if (itemToRemove != null) {
					itemExists = true;
				}
				if (!itemID.isBlank() && itemExists) {
					// delete item
					int result = JOptionPane.showConfirmDialog(null,
							"Are you sure you want to delete the item associated with this ID and associated data permanently?",
							"Delete Item", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					if (result == JOptionPane.YES_OPTION) {
						// delete item
						Database.getStoreById(storeid).removeItem(itemToRemove);
						Database.getStoreById(storeid).removeSaleItem(itemToRemove);
						Database.saveStoreData();
						JOptionPane.showMessageDialog(null, "The item and data has been deleted.");
					} else {
						// don't delete item
						JOptionPane.showMessageDialog(null, "Redirecting back to store management page...");
					}
				} else if (!itemExists) {
					JOptionPane.showMessageDialog(null, "Item ID doesn't exist or invalid input...");
				}
				deleteItemID.setText("");
				scrollPane.setViewportView(createNewTable(storeid));
				scrollPane.setEnabled(false);
				btnDelete.setEnabled(checkEnableActionBtns(storeid));
				currentSaleItems.setText(Database.getStoreById(storeid).showStaffSaleItems());
			}
		});
		btnDelete.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_btnDelete = new GridBagConstraints();
		gbc_btnDelete.gridwidth = 2;
		gbc_btnDelete.insets = new Insets(0, 0, 5, 5);
		gbc_btnDelete.gridx = 1;
		gbc_btnDelete.gridy = 11;
		add(btnDelete, gbc_btnDelete);

		JButton updateItemBtn_1 = new JButton("Update Manager");
		if (!adminAccess) {
			updateItemBtn_1.setEnabled(false);
		}
		updateItemBtn_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean managerExists = false;
				String newId = newManager.getText();
				if (Database.doesAccExists(newId)) {
					if (Database.getAccDetails(newId) instanceof ManagerAccount) {
						managerExists = true;
					}
				}
				if (!newId.isBlank() && managerExists) {
					// change manager for this store
					int result = JOptionPane.showConfirmDialog(null,
							"Are you sure you want to change the manager for this store?", "Update Manager",
							JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					if (result == JOptionPane.YES_OPTION) {
						// change manager for this store
						// need to set manager with new store
						// need to set store to have new manager
						String pass = Database.getAccDetails(newId).getPassword();
						String name = Database.getAccDetails(newId).getName();
						String email = Database.getAccDetails(newId).getEmail();
						ManagerAccount newManager = new ManagerAccount(newId, pass, name, email);
						newManager.changeStore(Database.getStoreById(storeid));
						Database.removeUserAccount(newId);
						Database.addUserAcc(newManager);
						Database.saveAccMapData();
						Database.getStoreById(storeid).changeManager((ManagerAccount) Database.getAccDetails(newId));
						Database.saveStoreData();
						JOptionPane.showMessageDialog(null, "The manager for this store has been updated.");
					} else {
						// don't change manager for this store
						JOptionPane.showMessageDialog(null, "Redirecting back to " + storeid + " details page...");
					}
				} else if (!managerExists) {
					JOptionPane.showMessageDialog(null, "Manager ID doesn't exist or invalid input...");
				}
				scrollPane.setViewportView(createNewTable(storeid));
				scrollPane.setEnabled(false);
				// update the manager for the store and activate remove button
				removeManager.setEnabled(checkForManagerExistence(storeid));
				// clear text field
				newManager.setText("");
				currentManagerLbl.setText(Database.getStoreById(storeid).getManagerName());
			}
		});
		updateItemBtn_1.setHorizontalAlignment(SwingConstants.LEFT);
		updateItemBtn_1.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_updateItemBtn_1 = new GridBagConstraints();
		gbc_updateItemBtn_1.gridheight = 2;
		gbc_updateItemBtn_1.gridwidth = 2;
		gbc_updateItemBtn_1.insets = new Insets(0, 0, 5, 5);
		gbc_updateItemBtn_1.gridx = 1;
		gbc_updateItemBtn_1.gridy = 17;
		add(updateItemBtn_1, gbc_updateItemBtn_1);

		JButton createItem = new JButton("Create Item");
		createItem.setHorizontalAlignment(SwingConstants.LEFT);
		createItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean proceed = true;
				String newID = null;
				String newName = null;
				String newPrice = null;
				String newQuantity = null;
				String newCategory = null;
				if (!createItemID.getText().isBlank()) {
					newID = createItemID.getText();
				}
				if (!createItemName.getText().isBlank()) {
					newName = createItemName.getText();
				}
				if (!createItemPrice.getText().isBlank()) {
					newPrice = createItemPrice.getText();
					if (!newPrice.matches("^(?:[1-9]\\d*|0)?(?:\\.\\d+)?$")) {
						JOptionPane.showMessageDialog(null, "Price must be a positive floating point value.");
						proceed = false;
					}
				}
				if (!createItemQuantity.getText().isBlank()) {
					newQuantity = createItemQuantity.getText();
					if (!newQuantity.matches("[0-9]+")) {
						JOptionPane.showMessageDialog(null, "Quantity must be a positive integer number.");
						proceed = false;
					}
				}
				if (!createItemCategory.getText().isBlank()) {
					newCategory = createItemCategory.getText();
				}
				if (proceed) {
					if (Database.getStoreById(storeid).getItems().containsKey(newID) && proceed) {
						// give warning item exists
						JOptionPane.showMessageDialog(null, "Item ID already exists.");
						createItemID.setText("");
					} else if (createItemID.getText().isBlank() || createItemName.getText().isBlank()
							|| createItemPrice.getText().isBlank() || createItemQuantity.getText().isBlank()
							|| createItemCategory.getText().isBlank()) {
						JOptionPane.showMessageDialog(null, "Fill all fields.");
					} else {
						Double price = Double.parseDouble(newPrice);
						int quantity = Integer.parseInt(newQuantity);
						Item newItem = new Item(newID, newName, price, newCategory);
						// add new item
						Database.getStoreById(storeid).addItem(newItem);
						// set inv count from 0
						Database.getStoreById(storeid).changeInventory(newItem, quantity);
						// save to database
						Database.saveStoreData();
						JOptionPane.showMessageDialog(null, "Item created.");
						createItemID.setText("");
						createItemName.setText("");
						createItemPrice.setText("");
						createItemQuantity.setText("");
						createItemCategory.setText("");
					}
					scrollPane.setViewportView(createNewTable(storeid));
					scrollPane.setEnabled(false);
					btnDelete.setEnabled(checkEnableActionBtns(storeid));
					updateItemBtn.setEnabled(checkEnableActionBtns(storeid));
					currentSaleItems.setText(Database.getStoreById(storeid).showStaffSaleItems());
				}
			};
		});
		createItem.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_createItem = new GridBagConstraints();
		gbc_createItem.gridheight = 2;
		gbc_createItem.gridwidth = 2;
		gbc_createItem.insets = new Insets(0, 0, 5, 5);
		gbc_createItem.gridx = 1;
		gbc_createItem.gridy = 3;
		add(createItem, gbc_createItem);

		deleteItemID = new JTextField();
		deleteItemID.setToolTipText("Item ID");
		deleteItemID.setColumns(10);
		GridBagConstraints gbc_deleteItemID = new GridBagConstraints();
		gbc_deleteItemID.insets = new Insets(15, 35, 15, 35);
		gbc_deleteItemID.fill = GridBagConstraints.HORIZONTAL;
		gbc_deleteItemID.gridx = 0;
		gbc_deleteItemID.gridy = 13;
		add(deleteItemID, gbc_deleteItemID);

		JLabel lblUpdateManager = new JLabel("Update Manager");
		lblUpdateManager.setForeground(Color.BLACK);
		lblUpdateManager.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblUpdateManager = new GridBagConstraints();
		gbc_lblUpdateManager.gridwidth = 3;
		gbc_lblUpdateManager.insets = new Insets(0, 0, 5, 5);
		gbc_lblUpdateManager.gridx = 0;
		gbc_lblUpdateManager.gridy = 14;
		add(lblUpdateManager, gbc_lblUpdateManager);

		JLabel lblCurrent = new JLabel("Current");
		lblCurrent.setForeground(Color.BLACK);
		lblCurrent.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_lblCurrent = new GridBagConstraints();
		gbc_lblCurrent.insets = new Insets(0, 0, 5, 5);
		gbc_lblCurrent.gridx = 0;
		gbc_lblCurrent.gridy = 15;
		add(lblCurrent, gbc_lblCurrent);

		setPreferredSize(new Dimension(1500, 700));

		JLabel lblNew = new JLabel("New");
		lblNew.setForeground(Color.BLACK);
		lblNew.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_lblNew = new GridBagConstraints();
		gbc_lblNew.insets = new Insets(0, 0, 5, 5);
		gbc_lblNew.gridx = 0;
		gbc_lblNew.gridy = 16;
		add(lblNew, gbc_lblNew);

		newManager = new JTextField("");
		if (!adminAccess) {
			newManager.setEnabled(false);
		}
		newManager.setToolTipText("username");
		newManager.setColumns(10);
		GridBagConstraints gbc_newManager = new GridBagConstraints();
		gbc_newManager.gridwidth = 2;
		gbc_newManager.insets = new Insets(5, 45, 5, 45);
		gbc_newManager.fill = GridBagConstraints.HORIZONTAL;
		gbc_newManager.gridx = 1;
		gbc_newManager.gridy = 16;
		add(newManager, gbc_newManager);

		JLabel lblNewLabel_4_2_1 = new JLabel("Current Store Location");
		lblNewLabel_4_2_1.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_4_2_1 = new GridBagConstraints();
		gbc_lblNewLabel_4_2_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4_2_1.gridx = 7;
		gbc_lblNewLabel_4_2_1.gridy = 17;
		add(lblNewLabel_4_2_1, gbc_lblNewLabel_4_2_1);

		updateStoreLocField = new JTextField();
		if (!adminAccess) {
			updateStoreLocField.setEnabled(false);
		}
		updateStoreLocField.setToolTipText("New Store Location");
		updateStoreLocField.setColumns(10);
		GridBagConstraints gbc_updateStoreLocField = new GridBagConstraints();
		gbc_updateStoreLocField.gridwidth = 2;
		gbc_updateStoreLocField.insets = new Insets(0, 0, 5, 5);
		gbc_updateStoreLocField.fill = GridBagConstraints.HORIZONTAL;
		gbc_updateStoreLocField.gridx = 9;
		gbc_updateStoreLocField.gridy = 17;
		add(updateStoreLocField, gbc_updateStoreLocField);

		JLabel currentStoreLocation = new JLabel("");
		currentStoreLocation.setText(Database.getStoreById(storeid).getLocation());
		currentStoreLocation.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_currentStoreLocation = new GridBagConstraints();
		gbc_currentStoreLocation.insets = new Insets(0, 0, 5, 5);
		gbc_currentStoreLocation.gridx = 7;
		gbc_currentStoreLocation.gridy = 18;
		add(currentStoreLocation, gbc_currentStoreLocation);

		JButton updateStoreLocationBtn = new JButton("Update Store Location");
		if (!adminAccess) {
			updateStoreLocationBtn.setEnabled(false);
		}
		updateStoreLocationBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String newloc = updateStoreLocField.getText();
				if (!newloc.isBlank()) {
					// change manager for this store
					int result = JOptionPane.showConfirmDialog(null,
							"Are you sure you want to change the location for this store?", "Update Location",
							JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					if (result == JOptionPane.YES_OPTION) {
						// change location for this store
						Database.getStoreById(storeid).changeLocation(newloc);
						Database.saveStoreData();
						JOptionPane.showMessageDialog(null, "The location for this store has been updated.");
						currentStoreLocation.setText(Database.getStoreById(storeid).getLocation());
					} else {
						// don't change manager for this store
						JOptionPane.showMessageDialog(null, "Redirecting back to " + storeid + " details page...");
					}
				} else {
					JOptionPane.showMessageDialog(null, "Location cannot be blank (invalid input)...");
				}
			}
		});
		updateStoreLocationBtn.setHorizontalAlignment(SwingConstants.LEFT);
		updateStoreLocationBtn.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_updateStoreLocationBtn = new GridBagConstraints();
		gbc_updateStoreLocationBtn.gridwidth = 4;
		gbc_updateStoreLocationBtn.insets = new Insets(0, 0, 5, 5);
		gbc_updateStoreLocationBtn.gridx = 8;
		gbc_updateStoreLocationBtn.gridy = 18;
		add(updateStoreLocationBtn, gbc_updateStoreLocationBtn);

		revalidate();
		repaint();
	}

	public JTable createNewTable(String storeid) {
		Database.loadStoreData();
		Map<String, Item> currentItems = Database.getStoreById(storeid).getItems();
		Map<Item, Integer> currentInv = Database.getStoreById(storeid).getInv();
		boolean itemsExist = false;
		int size = currentItems.size();
		String[][] actualData = new String[size][5];
		int index = 0;
		if (currentItems.size() > 0) {
			itemsExist = true;
			for (Map.Entry<String, Item> pair : currentItems.entrySet()) {
				actualData[index][0] = pair.getKey();
				actualData[index][1] = pair.getValue().name;
				actualData[index][2] = String.valueOf(pair.getValue().price);
				actualData[index][3] = String.valueOf(currentInv.get(pair.getValue()));
				actualData[index][4] = pair.getValue().category;
				index++;
			}
		}

		String[][] emptyData = new String[1][5];
		emptyData[0][0] = "N/A (Empty)";
		emptyData[0][1] = "N/A (Empty)";
		emptyData[0][2] = "N/A (Empty)";
		emptyData[0][3] = "N/A (Empty)";
		emptyData[0][4] = "N/A (Empty)";

		String[] headers = { "Item Id", "Name", "Price", "Quantity", "Category" };
		if (itemsExist) {
			existingItems = new JTable(actualData, headers);
		} else {
			existingItems = new JTable(emptyData, headers);
		}
		existingItems.getTableHeader().setReorderingAllowed(false);
		existingItems.getTableHeader().setFont(new Font("Arial Narrow", Font.BOLD, 20));
		existingItems.getTableHeader().setResizingAllowed(false);
		existingItems.setEnabled(false);
		existingItems.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		return existingItems;
	}

	public boolean checkEnableActionBtns(String storeid) {
		if (Database.getStoreById(storeid).getItems().size() > 0) {
			return true;
		} else {
			return false;
		}
	}

	public boolean checkForManagerExistence(String storeid) {
		if (Database.getStoreById(storeid).getManagerName().equals("N/A (Empty)")) {
			return false;
		} else {
			return true;
		}
	}

	public boolean checkForSaleItemExistence(String storeid) {
		if (!Database.getStoreById(storeid).showStaffSaleItems().equals("No items on sale currently.")) {
			return true;
		} else {
			return false;
		}
	}

}
