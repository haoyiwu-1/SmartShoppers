package GUI.PrivilegedAccPages;
import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.List;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JTable;
import SmartShoppers.Store;
import SmartShoppers.SystemDatabase;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.DefaultComboBoxModel;

public class StoreManagement extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4700443873628582918L;
	private static SystemDatabase Database;
	private JTable existingStores;
	private JTextField createId;
	private JTextField createLocation;
	private JTextField deleteId;
	private JTextField updateStore;

	/**
	 * Create the panel.
	 */
	public StoreManagement(Component parent) {
		Database = SystemDatabase.getInstance();
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 100, 100, 100, 100, 100, 200, 200, 200 };
		gridBagLayout.rowHeights = new int[] { 70, 30, 30, 0, 70, 70, 0, 70, 70, 0, 0 };
		gridBagLayout.columnWeights = new double[] { 1.0, 1.0, Double.MIN_VALUE, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0,
				0.0 };
		gridBagLayout.rowWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		setLayout(gridBagLayout);

		JTable existingStores = createNewTable();
		GridBagConstraints gbc_existingStores = new GridBagConstraints();
		gbc_existingStores.insets = new Insets(0, 0, 0, 5);
		gbc_existingStores.gridheight = 5;
		gbc_existingStores.gridwidth = 7;
		gbc_existingStores.fill = GridBagConstraints.BOTH;
		gbc_existingStores.gridx = 2;
		gbc_existingStores.gridy = 3;
		add(existingStores, gbc_existingStores);

		JLabel lblNewLabel_1 = new JLabel("Store Management");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.BOLD, 65));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.gridwidth = 12;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 0;
		add(lblNewLabel_1, gbc_lblNewLabel_1);

		JLabel lblUpdateStore = new JLabel("Update store");
		lblUpdateStore.setForeground(Color.YELLOW);
		lblUpdateStore.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblUpdateStore = new GridBagConstraints();
		gbc_lblUpdateStore.insets = new Insets(0, 0, 5, 5);
		gbc_lblUpdateStore.gridx = 0;
		gbc_lblUpdateStore.gridy = 2;
		add(lblUpdateStore, gbc_lblUpdateStore);

		JLabel updateWarning = new JLabel("");
		updateWarning.setForeground(new Color(154, 205, 50));
		updateWarning.setFont(new Font("Arial Narrow", Font.BOLD, 12));
		GridBagConstraints gbc_updateWarning = new GridBagConstraints();
		gbc_updateWarning.insets = new Insets(0, 0, 5, 5);
		gbc_updateWarning.gridx = 0;
		gbc_updateWarning.gridy = 3;
		add(updateWarning, gbc_updateWarning);

		updateStore = new JTextField("");
		updateStore.setToolTipText("store id");
		updateStore.setColumns(10);
		GridBagConstraints gbc_updateStore = new GridBagConstraints();
		gbc_updateStore.insets = new Insets(15, 35, 15, 35);
		gbc_updateStore.fill = GridBagConstraints.HORIZONTAL;
		gbc_updateStore.gridx = 0;
		gbc_updateStore.gridy = 4;
		add(updateStore, gbc_updateStore);

		JScrollPane scrollPane = new JScrollPane(existingStores, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setEnabled(false);
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.insets = new Insets(5, 5, 0, 0);
		gbc_scrollPane.gridwidth = 9;
		gbc_scrollPane.gridheight = 9;
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 3;
		gbc_scrollPane.gridy = 4;
		add(scrollPane, gbc_scrollPane);

		JLabel lblNewLabel_2 = new JLabel("Existing Stores");
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Arial Narrow", Font.BOLD, 50));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.gridwidth = 9;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_2.gridx = 3;
		gbc_lblNewLabel_2.gridy = 2;
		add(lblNewLabel_2, gbc_lblNewLabel_2);

		JLabel lblNewLabel = new JLabel("Create store");
		lblNewLabel.setForeground(new Color(154, 205, 50));
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 5;
		add(lblNewLabel, gbc_lblNewLabel);

		JLabel createWarning = new JLabel("");
		createWarning.setForeground(new Color(154, 205, 50));
		createWarning.setFont(new Font("Arial Narrow", Font.BOLD, 12));
		GridBagConstraints gbc_createWarning = new GridBagConstraints();
		gbc_createWarning.insets = new Insets(0, 0, 5, 5);
		gbc_createWarning.gridx = 0;
		gbc_createWarning.gridy = 6;
		add(createWarning, gbc_createWarning);

		createId = new JTextField("");
		createId.setToolTipText("store id");
		GridBagConstraints gbc_createId = new GridBagConstraints();
		gbc_createId.fill = GridBagConstraints.HORIZONTAL;
		gbc_createId.insets = new Insets(15, 35, 15, 35);
		gbc_createId.gridx = 0;
		gbc_createId.gridy = 7;
		add(createId, gbc_createId);
		createId.setColumns(10);

		createLocation = new JTextField();
		createLocation.setToolTipText("location");
		createLocation.setColumns(10);
		GridBagConstraints gbc_createLocation = new GridBagConstraints();
		gbc_createLocation.gridwidth = 2;
		gbc_createLocation.insets = new Insets(15, 20, 15, 25);
		gbc_createLocation.fill = GridBagConstraints.HORIZONTAL;
		gbc_createLocation.gridx = 1;
		gbc_createLocation.gridy = 7;
		add(createLocation, gbc_createLocation);

		JComboBox<String> opentimeCombo = new JComboBox<String>();
		opentimeCombo.setToolTipText("opening time");
		opentimeCombo.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		opentimeCombo.setModel(
				new DefaultComboBoxModel<String>(new String[] {"6:00am", "7:00am", "8:00am", "9:00am", "10:00am", "11:00am", "12:00am", "1:00pm", "2:00pm", "3:00pm", "4:00pm", "5:00pm", "6:00pm", "7:00pm", "8:00pm", "9:00pm", "10:00pm", "11:00pm", "12:00pm", "1:00am", "2:00am", "3:00am", "4:00am", "5:00am"}));
		GridBagConstraints gbc_opentimeCombo = new GridBagConstraints();
		gbc_opentimeCombo.insets = new Insets(25, 25, 25, 25);
		gbc_opentimeCombo.fill = GridBagConstraints.HORIZONTAL;
		gbc_opentimeCombo.gridx = 0;
		gbc_opentimeCombo.gridy = 8;
		add(opentimeCombo, gbc_opentimeCombo);

		JComboBox<String> closingTimeCombo = new JComboBox<String>();
		closingTimeCombo.setToolTipText("closing time");
		closingTimeCombo.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		closingTimeCombo.setModel(
				new DefaultComboBoxModel<String>(new String[] { "6:00am", "7:00am", "8:00am", "9:00am", "10:00am", "11:00am",
						"12:00am", "1:00pm", "2:00pm", "3:00pm", "4:00pm", "5:00pm", "6:00pm", "7:00pm", "8:00pm",
						"9:00pm", "10:00pm", "11:00pm", "12:00pm", "1:00am", "2:00am", "3:00am", "4:00am", "5:00am" }));
		GridBagConstraints gbc_closingTimeCombo = new GridBagConstraints();
		gbc_closingTimeCombo.gridwidth = 2;
		gbc_closingTimeCombo.insets = new Insets(10, 10, 10, 10);
		gbc_closingTimeCombo.fill = GridBagConstraints.HORIZONTAL;
		gbc_closingTimeCombo.gridx = 1;
		gbc_closingTimeCombo.gridy = 8;
		add(closingTimeCombo, gbc_closingTimeCombo);

		deleteId = new JTextField();
		deleteId.setToolTipText("store id");
		deleteId.setColumns(10);
		GridBagConstraints gbc_deleteId = new GridBagConstraints();
		gbc_deleteId.insets = new Insets(15, 35, 15, 35);
		gbc_deleteId.fill = GridBagConstraints.HORIZONTAL;
		gbc_deleteId.gridx = 0;
		gbc_deleteId.gridy = 10;
		add(deleteId, gbc_deleteId);

		JLabel delWarning = new JLabel("");
		delWarning.setForeground(new Color(154, 205, 50));
		delWarning.setFont(new Font("Arial Narrow", Font.BOLD, 12));
		GridBagConstraints gbc_delWarning = new GridBagConstraints();
		gbc_delWarning.gridwidth = 2;
		gbc_delWarning.insets = new Insets(10, 10, 10, 10);
		gbc_delWarning.gridx = 0;
		gbc_delWarning.gridy = 11;
		add(delWarning, gbc_delWarning);

		JButton updateStoreBtn = new JButton("Update");
		updateStoreBtn.setEnabled(checkEnableActionBtns());
		updateStoreBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean storeExists = false;
				String storeId = updateStore.getText();
				if (Database.checkStore(storeId)) {
					storeExists = true;
				}
				if (!storeId.isBlank() && storeExists) {
					// go to update store page
					JFrame parentFrame = (JFrame) parent;
					parentFrame.getContentPane().removeAll();
					UpdateStore viewUpdateStore = new UpdateStore(storeId, parentFrame);
					parentFrame.getContentPane().add(viewUpdateStore);
					parentFrame.pack();
					parentFrame.getContentPane().revalidate();
					parentFrame.getContentPane().repaint();
				} else if (!storeExists) {
					updateWarning.setText("Store doesn't exist (or blank input)");
					updateWarning.setForeground(Color.RED);
					JOptionPane.showMessageDialog(null, "Store doesn't exist or invalid input...");
					updateWarning.setText("");
				}
				updateStore.setText("");
				updateStoreBtn.setEnabled(checkEnableActionBtns());
			}
		});
		updateStoreBtn.setHorizontalAlignment(SwingConstants.LEFT);
		updateStoreBtn.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_updateStoreBtn = new GridBagConstraints();
		gbc_updateStoreBtn.gridwidth = 2;
		gbc_updateStoreBtn.insets = new Insets(0, 0, 5, 5);
		gbc_updateStoreBtn.gridx = 1;
		gbc_updateStoreBtn.gridy = 2;
		add(updateStoreBtn, gbc_updateStoreBtn);

		JButton btnDelete = new JButton("Delete");
		btnDelete.setEnabled(checkEnableActionBtns());
		btnDelete.setHorizontalAlignment(SwingConstants.LEFT);
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean storeExists = false;
				String storeId = deleteId.getText();
				if (Database.checkStore(storeId)) {
					storeExists = true;
				}
				if (!storeId.isBlank() && storeExists) {
					// delete store
					int result = JOptionPane.showConfirmDialog(null,
							"Are you sure you want to delete this store and associated data permanently?",
							"Delete Store", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					if (result == JOptionPane.YES_OPTION) {
						// delete acc
						Database.removeStore(storeId);
						Database.saveStoreData();
						JOptionPane.showMessageDialog(null, "The store and data has been deleted.");
					} else {
						// don't delete acc
						JOptionPane.showMessageDialog(null, "Redirecting back to store management page...");
					}
				} else if (!storeExists) {
					delWarning.setText("Store doesn't exist (or blank input)");
					delWarning.setForeground(Color.RED);
					JOptionPane.showMessageDialog(null, "Store doesn't exist or invalid input...");
					delWarning.setText("");
				}
				deleteId.setText("");
				scrollPane.setViewportView(createNewTable());
				scrollPane.setEnabled(false);
				btnDelete.setEnabled(checkEnableActionBtns());
				updateStoreBtn.setEnabled(checkEnableActionBtns());
			}
		});

		JLabel lblDeleteManager = new JLabel("Delete store");
		lblDeleteManager.setForeground(Color.RED);
		lblDeleteManager.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblDeleteManager = new GridBagConstraints();
		gbc_lblDeleteManager.insets = new Insets(0, 0, 5, 5);
		gbc_lblDeleteManager.gridx = 0;
		gbc_lblDeleteManager.gridy = 9;
		add(lblDeleteManager, gbc_lblDeleteManager);
		btnDelete.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_btnDelete = new GridBagConstraints();
		gbc_btnDelete.gridwidth = 2;
		gbc_btnDelete.insets = new Insets(0, 0, 5, 5);
		gbc_btnDelete.gridx = 1;
		gbc_btnDelete.gridy = 9;
		add(btnDelete, gbc_btnDelete);

		JButton btnNewButton = new JButton("Create");
		btnNewButton.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String newId = null;
				String newLoc = null;
				if (!createId.getText().isBlank()) {
					newId = createId.getText();
				}
				if (!createLocation.getText().isBlank()) {
					newLoc = createLocation.getText();
				}
				String newOpentime = String.valueOf(opentimeCombo.getSelectedItem());
				String newClosetime = String.valueOf(closingTimeCombo.getSelectedItem());
				if (Database.checkStore(newId)) {
					// give warning store exists
					createWarning.setText("Store already exists");
					createWarning.setForeground(Color.RED);
					JOptionPane.showMessageDialog(null, "Store already exists.");
					createWarning.setText("");
					createId.setText("");
				} else if (createId.getText().isBlank() || createLocation.getText().isBlank()) {
					createWarning.setText("Fill all fields");
					createWarning.setForeground(Color.RED);
					JOptionPane.showMessageDialog(null, "Fill all fields.");
					createWarning.setText("");
				} else {
					Store newStore = new Store(newId, newLoc, newOpentime, newClosetime);
					Database.addStore(newStore);
					Database.saveStoreData();
					JOptionPane.showMessageDialog(null, "Store created.");
					createId.setText("");
					createLocation.setText("");
				}
				scrollPane.setViewportView(createNewTable());
				scrollPane.setEnabled(false);
				btnDelete.setEnabled(checkEnableActionBtns());
				updateStoreBtn.setEnabled(checkEnableActionBtns());
			};
		});
		btnNewButton.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridwidth = 2;
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 1;
		gbc_btnNewButton.gridy = 5;
		add(btnNewButton, gbc_btnNewButton);

		setPreferredSize(new Dimension(1500, 700));
	}

	public JTable createNewTable() {
		Database.loadAccMapData();
		List<Store> currentStores = Database.getStores();
		Boolean storesExist = false;
		int size = currentStores.size();
		String[][] actualData = new String[size][5];
		int index = 0;
		if (currentStores.size() > 0) {
			storesExist = true;
			for (Store m : currentStores) {
				actualData[index][0] = m.getId();
				actualData[index][1] = m.getLocation();
				actualData[index][2] = m.getOpentime();
				actualData[index][3] = m.getClosingtime();
				actualData[index][4] = m.getManagerName();
				index++;
			}
		}

		String[][] emptyData = new String[1][5];
		emptyData[0][0] = "N/A (Empty)";
		emptyData[0][1] = "N/A (Empty)";
		emptyData[0][2] = "N/A (Empty)";
		emptyData[0][3] = "N/A (Empty)";
		emptyData[0][4] = "N/A (Empty)";

		String[] headers = { "ID", "Location", "Opening Time", "Closing Time", "Manager" };
		if (storesExist) {
			existingStores = new JTable(actualData, headers);
		} else {
			existingStores = new JTable(emptyData, headers);
		}
		existingStores.getTableHeader().setReorderingAllowed(false);
		existingStores.getTableHeader().setFont(new Font("Arial Narrow", Font.BOLD, 20));
		existingStores.getTableHeader().setResizingAllowed(false);
		existingStores.setEnabled(false);
		existingStores.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		return existingStores;
	}

	public boolean checkEnableActionBtns() {
		if (Database.getStores().size() > 0) {
			return true;
		} else {
			return false;
		}
	}
}
