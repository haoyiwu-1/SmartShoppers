package GUI.PrivilegedAccPages;

import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JTextField;

import SmartShoppers.Item;
import SmartShoppers.SystemDatabase;

import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class UpdateItem extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6026974446601554397L;
	private static SystemDatabase Database;
	private JTextField newNameField;
	private JTextField newPriceField;
	private JTextField newSizeField;
	private JTextField newQuantityField;
	private JTextField newCategoryField;

	/**
	 * Create the panel.
	 */
	public UpdateItem(String itemID, String storeid, Component parent) {
		Database = SystemDatabase.getInstance();
		setBounds(100, 100, 1500, 700);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 300, 300, 300, 300, 300 };
		gridBagLayout.rowHeights = new int[] { 87, 87, 87, 87, 87, 87, 87, 87 };
		gridBagLayout.columnWeights = new double[] { 1.0, 0.0, 1.0 };
		gridBagLayout.rowWeights = new double[] { 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		setLayout(gridBagLayout);
		
		JButton backToStoreDetails = new JButton("");
		backToStoreDetails.setText("Back to " + storeid + " details page");
		backToStoreDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//back to store page
				JFrame parentFrame = (JFrame) parent;
				parentFrame.getContentPane().removeAll();
				UpdateStore viewUpdateStore = new UpdateStore(storeid, parent);
				parentFrame.getContentPane().add(viewUpdateStore);
				parentFrame.pack();
				parentFrame.getContentPane().revalidate();
				parentFrame.getContentPane().repaint();
			}
		});
		backToStoreDetails.setFont(new Font("Arial Narrow", Font.BOLD, 18));
		GridBagConstraints gbc_backToStoreDetails = new GridBagConstraints();
		gbc_backToStoreDetails.insets = new Insets(0, 0, 5, 5);
		gbc_backToStoreDetails.gridx = 0;
		gbc_backToStoreDetails.gridy = 0;
		add(backToStoreDetails, gbc_backToStoreDetails);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setText(itemID + " - Details");
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 60));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.gridwidth = 3;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 0;
		add(lblNewLabel, gbc_lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Item Name");
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 1;
		add(lblNewLabel_1, gbc_lblNewLabel_1);

		JLabel oldName = new JLabel("");
		oldName.setText(Database.getStoreById(storeid).getItems().get(itemID).name);
		oldName.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_oldName = new GridBagConstraints();
		gbc_oldName.insets = new Insets(0, 0, 5, 5);
		gbc_oldName.gridx = 1;
		gbc_oldName.gridy = 1;
		add(oldName, gbc_oldName);

		JLabel lblNewLabel_1_1 = new JLabel("New Item Name");
		lblNewLabel_1_1.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel_1_1 = new GridBagConstraints();
		gbc_lblNewLabel_1_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1_1.gridx = 2;
		gbc_lblNewLabel_1_1.gridy = 1;
		add(lblNewLabel_1_1, gbc_lblNewLabel_1_1);

		newNameField = new JTextField();
		GridBagConstraints gbc_newNameField = new GridBagConstraints();
		gbc_newNameField.insets = new Insets(0, 0, 5, 5);
		gbc_newNameField.fill = GridBagConstraints.HORIZONTAL;
		gbc_newNameField.gridx = 3;
		gbc_newNameField.gridy = 1;
		add(newNameField, gbc_newNameField);
		newNameField.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("Item Description");
		lblNewLabel_2.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 0;
		gbc_lblNewLabel_2.gridy = 2;
		add(lblNewLabel_2, gbc_lblNewLabel_2);

		JLabel oldDesc = new JLabel("");
		oldDesc.setText(Database.getStoreById(storeid).getItems().get(itemID).description);
		oldDesc.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		GridBagConstraints gbc_oldDesc = new GridBagConstraints();
		gbc_oldDesc.insets = new Insets(0, 0, 5, 5);
		gbc_oldDesc.gridx = 1;
		gbc_oldDesc.gridy = 2;
		add(oldDesc, gbc_oldDesc);

		JLabel lblNewLabel_2_1 = new JLabel("New Item Description");
		lblNewLabel_2_1.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel_2_1 = new GridBagConstraints();
		gbc_lblNewLabel_2_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2_1.gridx = 2;
		gbc_lblNewLabel_2_1.gridy = 2;
		add(lblNewLabel_2_1, gbc_lblNewLabel_2_1);

		JTextArea newDescriptionField = new JTextArea();
		GridBagConstraints gbc_newDescriptionField = new GridBagConstraints();
		gbc_newDescriptionField.insets = new Insets(0, 0, 5, 5);
		gbc_newDescriptionField.fill = GridBagConstraints.BOTH;
		gbc_newDescriptionField.gridx = 3;
		gbc_newDescriptionField.gridy = 2;
		add(newDescriptionField, gbc_newDescriptionField);

		JLabel lblNewLabel_3 = new JLabel("Item Price");
		lblNewLabel_3.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3.gridx = 0;
		gbc_lblNewLabel_3.gridy = 3;
		add(lblNewLabel_3, gbc_lblNewLabel_3);

		JLabel oldPrice = new JLabel("");
		oldPrice.setText(String.valueOf(Database.getStoreById(storeid).getItems().get(itemID).price));
		oldPrice.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_oldPrice = new GridBagConstraints();
		gbc_oldPrice.insets = new Insets(0, 0, 5, 5);
		gbc_oldPrice.gridx = 1;
		gbc_oldPrice.gridy = 3;
		add(oldPrice, gbc_oldPrice);

		JLabel lblNewLabel_3_1 = new JLabel("New Item Price");
		lblNewLabel_3_1.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel_3_1 = new GridBagConstraints();
		gbc_lblNewLabel_3_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3_1.gridx = 2;
		gbc_lblNewLabel_3_1.gridy = 3;
		add(lblNewLabel_3_1, gbc_lblNewLabel_3_1);

		newPriceField = new JTextField();
		newPriceField.setColumns(10);
		GridBagConstraints gbc_newPriceField = new GridBagConstraints();
		gbc_newPriceField.insets = new Insets(0, 0, 5, 5);
		gbc_newPriceField.fill = GridBagConstraints.HORIZONTAL;
		gbc_newPriceField.gridx = 3;
		gbc_newPriceField.gridy = 3;
		add(newPriceField, gbc_newPriceField);

		JLabel lblNewLabel_4 = new JLabel("Item Size");
		lblNewLabel_4.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
		gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4.gridx = 0;
		gbc_lblNewLabel_4.gridy = 4;
		add(lblNewLabel_4, gbc_lblNewLabel_4);

		JLabel oldSize = new JLabel("");
		oldSize.setText(Database.getStoreById(storeid).getItems().get(itemID).size);
		oldSize.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_oldSize = new GridBagConstraints();
		gbc_oldSize.insets = new Insets(0, 0, 5, 5);
		gbc_oldSize.gridx = 1;
		gbc_oldSize.gridy = 4;
		add(oldSize, gbc_oldSize);

		JLabel lblNewLabel_4_1 = new JLabel("New Item Size");
		lblNewLabel_4_1.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel_4_1 = new GridBagConstraints();
		gbc_lblNewLabel_4_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4_1.gridx = 2;
		gbc_lblNewLabel_4_1.gridy = 4;
		add(lblNewLabel_4_1, gbc_lblNewLabel_4_1);

		newSizeField = new JTextField();
		newSizeField.setColumns(10);
		GridBagConstraints gbc_newSizeField = new GridBagConstraints();
		gbc_newSizeField.insets = new Insets(0, 0, 5, 5);
		gbc_newSizeField.fill = GridBagConstraints.HORIZONTAL;
		gbc_newSizeField.gridx = 3;
		gbc_newSizeField.gridy = 4;
		add(newSizeField, gbc_newSizeField);

		JLabel lblNewLabel_5 = new JLabel("Item Quantity");
		lblNewLabel_5.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
		gbc_lblNewLabel_5.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_5.gridx = 0;
		gbc_lblNewLabel_5.gridy = 5;
		add(lblNewLabel_5, gbc_lblNewLabel_5);

		JLabel oldQuantity = new JLabel("");
		oldQuantity.setText(String.valueOf(
				Database.getStoreById(storeid).getInv().get(Database.getStoreById(storeid).getItems().get(itemID))));
		oldQuantity.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_oldQuantity = new GridBagConstraints();
		gbc_oldQuantity.insets = new Insets(0, 0, 5, 5);
		gbc_oldQuantity.gridx = 1;
		gbc_oldQuantity.gridy = 5;
		add(oldQuantity, gbc_oldQuantity);

		JLabel lblNewLabel_5_1 = new JLabel("New Item Quantity");
		lblNewLabel_5_1.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel_5_1 = new GridBagConstraints();
		gbc_lblNewLabel_5_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_5_1.gridx = 2;
		gbc_lblNewLabel_5_1.gridy = 5;
		add(lblNewLabel_5_1, gbc_lblNewLabel_5_1);

		newQuantityField = new JTextField();
		newQuantityField.setColumns(10);
		GridBagConstraints gbc_newQuantityField = new GridBagConstraints();
		gbc_newQuantityField.insets = new Insets(0, 0, 5, 5);
		gbc_newQuantityField.fill = GridBagConstraints.HORIZONTAL;
		gbc_newQuantityField.gridx = 3;
		gbc_newQuantityField.gridy = 5;
		add(newQuantityField, gbc_newQuantityField);

		JLabel lblNewLabel_6 = new JLabel("Item Category");
		lblNewLabel_6.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel_6 = new GridBagConstraints();
		gbc_lblNewLabel_6.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_6.gridx = 0;
		gbc_lblNewLabel_6.gridy = 6;
		add(lblNewLabel_6, gbc_lblNewLabel_6);

		JLabel oldCategory = new JLabel("");
		oldCategory.setText(Database.getStoreById(storeid).getItems().get(itemID).category);
		oldCategory.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_oldCategory = new GridBagConstraints();
		gbc_oldCategory.insets = new Insets(0, 0, 5, 5);
		gbc_oldCategory.gridx = 1;
		gbc_oldCategory.gridy = 6;
		add(oldCategory, gbc_oldCategory);

		JLabel lblNewLabel_6_1 = new JLabel("Item Category");
		lblNewLabel_6_1.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel_6_1 = new GridBagConstraints();
		gbc_lblNewLabel_6_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_6_1.gridx = 2;
		gbc_lblNewLabel_6_1.gridy = 6;
		add(lblNewLabel_6_1, gbc_lblNewLabel_6_1);

		newCategoryField = new JTextField();
		newCategoryField.setColumns(10);
		GridBagConstraints gbc_newCategoryField = new GridBagConstraints();
		gbc_newCategoryField.insets = new Insets(0, 0, 5, 5);
		gbc_newCategoryField.fill = GridBagConstraints.HORIZONTAL;
		gbc_newCategoryField.gridx = 3;
		gbc_newCategoryField.gridy = 6;
		add(newCategoryField, gbc_newCategoryField);

		JButton btnNewButton = new JButton("Update Item");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean proceed = true;
				String newName = null;
				String newDescValue = null;
				String newPriceValue = null;
				String newSizeValue = null;
				String newQuantityValue = null;
				String newCategory = null;
				Item newItem = Database.getStoreById(storeid).getItems().get(itemID);
				if (!newNameField.getText().isBlank()) {
					newName = newNameField.getText();
				}
				if (!newDescriptionField.getText().isBlank()) {
					newDescValue = newDescriptionField.getText();
				}
				if (!newPriceField.getText().isBlank()) {
					newPriceValue = newPriceField.getText();
					if (!newPriceValue.matches("^(?:[1-9]\\d*|0)?(?:\\.\\d+)?$")) {
						JOptionPane.showMessageDialog(null, "Price must be a positive floating point value.");
						proceed = false;
					}
				}
				if (!newSizeField.getText().isBlank()) {
					newSizeValue = newSizeField.getText();
				}
				if (!newQuantityField.getText().isBlank()) {
					newQuantityValue = newQuantityField.getText();
					if (!newQuantityValue.matches("[0-9]+")) {
						JOptionPane.showMessageDialog(null, "Quantity must be a positive integer number.");
						proceed = false;
					}
				}
				if (!newCategoryField.getText().isBlank()) {
					newCategory = newCategoryField.getText();
				}
				if (proceed) {
					if (newNameField.getText().isBlank() || newDescriptionField.getText().isBlank()
							|| newPriceField.getText().isBlank() || newSizeField.getText().isBlank()
							|| newQuantityField.getText().isBlank() || newCategoryField.getText().isBlank()) {
						JOptionPane.showMessageDialog(null, "Fill all fields.");
					} else {
						newItem.name = newName;
						newItem.description = newDescValue;
						Double price = Double.parseDouble(newPriceValue);
						newItem.price = price;
						newItem.size = newSizeValue;
						int quantity = Integer.parseInt(newQuantityValue);
						newItem.category = newCategory;
						Database.getStoreById(storeid).removeItem(Database.getStoreById(storeid).getItems().get(itemID));
						Database.getStoreById(storeid).addItem(newItem);
						Database.getStoreById(storeid).changeInventory(newItem, quantity);
						Database.saveStoreData();
						JOptionPane.showMessageDialog(null,
								"Item updated. Exiting back to " + storeid + " details page...");
						newNameField.setText("");
						newDescriptionField.setText("");
						newPriceField.setText("");
						newSizeField.setText("");
						newQuantityField.setText("");
						newCategoryField.setText("");
						
						// exiting back to store details page on success of changing item
						JFrame parentFrame = (JFrame) parent;
						parentFrame.getContentPane().removeAll();
						UpdateStore viewUpdateStore = new UpdateStore(storeid, parent);
						parentFrame.getContentPane().add(viewUpdateStore);
						parentFrame.pack();
						parentFrame.getContentPane().revalidate();
						parentFrame.getContentPane().repaint();
					}
				}
			}
		});
		btnNewButton.setFont(new Font("Arial Narrow", Font.BOLD, 40));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridx = 4;
		gbc_btnNewButton.gridy = 7;
		add(btnNewButton, gbc_btnNewButton);
	}
}
