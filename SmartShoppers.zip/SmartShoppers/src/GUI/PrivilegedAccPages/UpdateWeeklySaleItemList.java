package GUI.PrivilegedAccPages;
import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JTextField;
import SmartShoppers.Store;
import SmartShoppers.SystemDatabase;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.awt.event.ActionEvent;

public class UpdateWeeklySaleItemList extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6026974446601554397L;
	private static SystemDatabase Database;
	private JTextField addItemId;
	private JTextField removeItemId;
	private JTextField addStoreId;
	private JTextField removeStoreId;

	/**
	 * Create the panel.
	 */
	public UpdateWeeklySaleItemList(Component parent) {
		Database = SystemDatabase.getInstance();
		setBounds(100, 100, 1500, 700);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 300, 300, 300, 300, 300 };
		gridBagLayout.rowHeights = new int[] { 87, 87, 87, 87, 87, 87, 87, 87 };
		gridBagLayout.columnWeights = new double[] { 1.0, 0.0, 1.0 };
		gridBagLayout.rowWeights = new double[] { 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		setLayout(gridBagLayout);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setText("Update Weekly Sale Item List");
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 60));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.gridwidth = 5;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		add(lblNewLabel, gbc_lblNewLabel);

		JLabel lblWeeklySaleItem = new JLabel("Weekly Sale Item List");
		lblWeeklySaleItem.setFont(new Font("Arial Narrow", Font.BOLD, 40));
		GridBagConstraints gbc_lblWeeklySaleItem = new GridBagConstraints();
		gbc_lblWeeklySaleItem.gridwidth = 3;
		gbc_lblWeeklySaleItem.insets = new Insets(0, 0, 5, 5);
		gbc_lblWeeklySaleItem.gridx = 0;
		gbc_lblWeeklySaleItem.gridy = 1;
		add(lblWeeklySaleItem, gbc_lblWeeklySaleItem);

		JLabel currentWeeklySaleList = new JLabel("");
		if (Database.getWeeklySaleItems().size() > 0) {
			currentWeeklySaleList.setText(Database.getWeeklySaleItems().toString());
		} else {
			currentWeeklySaleList.setText("No weekly sale items (mostly like since stores are empty)");
		}
		currentWeeklySaleList.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_currentWeeklySaleList = new GridBagConstraints();
		gbc_currentWeeklySaleList.gridheight = 6;
		gbc_currentWeeklySaleList.gridwidth = 3;
		gbc_currentWeeklySaleList.insets = new Insets(0, 0, 0, 5);
		gbc_currentWeeklySaleList.gridx = 0;
		gbc_currentWeeklySaleList.gridy = 2;
		add(currentWeeklySaleList, gbc_currentWeeklySaleList);

		JButton btnRemoveFromList = new JButton("Remove from list");
		if (Database.getWeeklySaleItems().size() > 0) {
			btnRemoveFromList.setEnabled(true);
		} else {
			btnRemoveFromList.setEnabled(false);
		}
		btnRemoveFromList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!removeItemId.getText().isBlank() && !removeStoreId.getText().isBlank()) {
					String itemId = removeItemId.getText();
					String storeid = removeStoreId.getText();
					// check for item existence in the list before removing
					String itemName = Database.getStoreById(storeid).getItems().get(itemId).name;
					if (Database.getStoresID().contains(storeid)) {
						if (Database.getWeeklySaleItems().contains(storeid + " - " + itemName)) {
							Database.removeWeeklySaleItem(itemName, storeid);
							Database.saveWeeklySaleItems();
							JOptionPane.showMessageDialog(null, "Weekly Sale Item List updated. Item removed.");
							Database.loadWeeklySaleItemsData();
						} else {
							JOptionPane.showMessageDialog(null,
									"Weekly Sale Item List doesn't contain this " + storeid + " - " + itemName);
						}
					}
					removeItemId.setText("");
					removeStoreId.setText("");
				} else {
					JOptionPane.showMessageDialog(null, "Fill both fields.");
				}
				if (Database.getWeeklySaleItems().size() > 0) {
					btnRemoveFromList.setEnabled(true);
				} else {
					btnRemoveFromList.setEnabled(false);
				}
				if (Database.getWeeklySaleItems().size() > 0) {
					currentWeeklySaleList.setText(Database.getWeeklySaleItems().toString());
				} else {
					currentWeeklySaleList.setText("No weekly sale items (mostly like since stores are empty)");
				}
			}
		});

		JButton btnBackToDetails = new JButton("Add to list");
		btnBackToDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!addItemId.getText().isBlank() && !addStoreId.getText().isBlank()) {
					String itemId = addItemId.getText();
					String storeid = addStoreId.getText();
					String itemName = null;
					// check for item existence before adding in (maybe inv as well)
					if (Database.getStoresID().contains(storeid)) {
						if (Database.getStoreById(storeid).getItems().get(itemId) != null) {
							if (Database.getStoreById(storeid).getInv()
									.get(Database.getStoreById(storeid).getItems().get(itemId)) > 0) {
								itemName = Database.getStoreById(storeid).getItems().get(itemId).name;
								Database.addWeeklySaleItem(itemName, storeid);
								Database.saveWeeklySaleItems();
								JOptionPane.showMessageDialog(null, "Weekly Sale Item List updated. Item added.");
								Database.loadWeeklySaleItemsData();
							} else {
								JOptionPane.showMessageDialog(null,
										itemId + " - " + itemName + " out of stock and not available in " + storeid + ".");
							}
						} else {
							JOptionPane.showMessageDialog(null,
									itemId + " - " + itemName + " doesn't exist in " + storeid + ".");
						}
					} else {
						JOptionPane.showMessageDialog(null, "Store with id: " + storeid + " doesn't exist.");
					}
					addItemId.setText("");
					addStoreId.setText("");
				} else {
					JOptionPane.showMessageDialog(null, "Fill both fields.");
				}
				if (Database.getWeeklySaleItems().size() > 0) {
					btnRemoveFromList.setEnabled(true);
				} else {
					btnRemoveFromList.setEnabled(false);
				}
				if (Database.getWeeklySaleItems().size() > 0) {
					currentWeeklySaleList.setText(Database.getWeeklySaleItems().toString());
				} else {
					currentWeeklySaleList.setText("No weekly sale items (mostly like since stores are empty)");
				}
			}
		});
		btnBackToDetails.setFont(new Font("Arial Narrow", Font.BOLD, 35));
		GridBagConstraints gbc_btnBackToDetails = new GridBagConstraints();
		gbc_btnBackToDetails.gridwidth = 2;
		gbc_btnBackToDetails.insets = new Insets(0, 0, 5, 5);
		gbc_btnBackToDetails.gridx = 3;
		gbc_btnBackToDetails.gridy = 2;
		add(btnBackToDetails, gbc_btnBackToDetails);

		addItemId = new JTextField();
		addItemId.setToolTipText("item ID");
		GridBagConstraints gbc_addItemId = new GridBagConstraints();
		gbc_addItemId.insets = new Insets(0, 50, 5, 50);
		gbc_addItemId.fill = GridBagConstraints.HORIZONTAL;
		gbc_addItemId.gridx = 3;
		gbc_addItemId.gridy = 3;
		add(addItemId, gbc_addItemId);
		addItemId.setColumns(10);

		addStoreId = new JTextField();
		addStoreId.setToolTipText("store ID");
		addStoreId.setColumns(10);
		GridBagConstraints gbc_addStoreId = new GridBagConstraints();
		gbc_addStoreId.insets = new Insets(0, 50, 5, 50);
		gbc_addStoreId.fill = GridBagConstraints.HORIZONTAL;
		gbc_addStoreId.gridx = 4;
		gbc_addStoreId.gridy = 3;
		add(addStoreId, gbc_addStoreId);
		btnRemoveFromList.setFont(new Font("Arial Narrow", Font.BOLD, 35));
		GridBagConstraints gbc_btnRemoveFromList = new GridBagConstraints();
		gbc_btnRemoveFromList.gridwidth = 2;
		gbc_btnRemoveFromList.insets = new Insets(0, 0, 5, 5);
		gbc_btnRemoveFromList.gridx = 3;
		gbc_btnRemoveFromList.gridy = 4;
		add(btnRemoveFromList, gbc_btnRemoveFromList);

		JButton generateBtn = new JButton("Generate Random Sale List");
		generateBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Random random = new Random();
				List<String> randomlyGeneratedItemList = new ArrayList<String>();
				for (Store store : Database.getStores()) {
					int limit = store.getItemsByName().size();
					String item = null;
					if (limit > 1) {
						item = store.getId() + " - " + store.getItemsByName().get(random.nextInt(limit));
						randomlyGeneratedItemList.add(item);
					} else if (limit == 1) {
						item = store.getId() + " - " + store.getItemsByName().get(0);
						randomlyGeneratedItemList.add(item);
					}
				}
				JOptionPane.showMessageDialog(null,
						"Weekly Sale Item List generated. If unchanged not enough items exist in stores.");
				Database.setWeeklySaleItems(randomlyGeneratedItemList);
				Database.saveWeeklySaleItems();
				Database.loadWeeklySaleItemsData();
				if (Database.getWeeklySaleItems().size() > 0) {
					btnRemoveFromList.setEnabled(true);
				} else {
					btnRemoveFromList.setEnabled(false);
				}
				if (Database.getWeeklySaleItems().size() > 0) {
					currentWeeklySaleList.setText(Database.getWeeklySaleItems().toString());
				} else {
					currentWeeklySaleList.setText("No weekly sale items (mostly like since stores are empty)");
				}
			}
		});

		removeItemId = new JTextField();
		removeItemId.setToolTipText("item ID");
		removeItemId.setColumns(10);
		GridBagConstraints gbc_removeItemId = new GridBagConstraints();
		gbc_removeItemId.insets = new Insets(0, 50, 5, 50);
		gbc_removeItemId.fill = GridBagConstraints.HORIZONTAL;
		gbc_removeItemId.gridx = 3;
		gbc_removeItemId.gridy = 5;
		add(removeItemId, gbc_removeItemId);

		removeStoreId = new JTextField();
		removeStoreId.setToolTipText("store ID");
		removeStoreId.setColumns(10);
		GridBagConstraints gbc_removeStoreId = new GridBagConstraints();
		gbc_removeStoreId.insets = new Insets(0, 50, 5, 50);
		gbc_removeStoreId.fill = GridBagConstraints.HORIZONTAL;
		gbc_removeStoreId.gridx = 4;
		gbc_removeStoreId.gridy = 5;
		add(removeStoreId, gbc_removeStoreId);
		generateBtn.setFont(new Font("Arial Narrow", Font.BOLD, 35));
		GridBagConstraints gbc_generateBtn = new GridBagConstraints();
		gbc_generateBtn.gridwidth = 2;
		gbc_generateBtn.insets = new Insets(0, 0, 5, 5);
		gbc_generateBtn.gridx = 3;
		gbc_generateBtn.gridy = 6;
		add(generateBtn, gbc_generateBtn);
	}
}
