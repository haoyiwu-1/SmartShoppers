package GUI.PrivilegedAccPages;

import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JTable;
import SmartShoppers.Item;
import SmartShoppers.SystemDatabase;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;

public class UpdateStoreMap extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2134304359779481090L;
	private static SystemDatabase Database;
	private JTable existingManagers;
	private JTextField addAisleNumber;
	private JTextField addItemCategory;
	private JTextField removeAisleNumber;
	private JTextField removeItemCategory;

	/**
	 * Create the panel.
	 */
	public UpdateStoreMap(String storeid, Component parent) {
		Database = SystemDatabase.getInstance();
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 100, 100, 100, 100, 100, 200, 200, 200 };
		gridBagLayout.rowHeights = new int[] { 70, 30, 30, 70, 70, 0, 70, 70 };
		gridBagLayout.columnWeights = new double[] { 1.0, 1.0, Double.MIN_VALUE, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0,
				0.0 };
		gridBagLayout.rowWeights = new double[] { 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		setLayout(gridBagLayout);

		JTable existingManagers = createNewTable(storeid);
		GridBagConstraints gbc_existingManagers = new GridBagConstraints();
		gbc_existingManagers.insets = new Insets(0, 0, 0, 5);
		gbc_existingManagers.gridheight = 5;
		gbc_existingManagers.gridwidth = 7;
		gbc_existingManagers.fill = GridBagConstraints.BOTH;
		gbc_existingManagers.gridx = 2;
		gbc_existingManagers.gridy = 3;
		add(existingManagers, gbc_existingManagers);
		JScrollPane scrollPane = new JScrollPane(existingManagers, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setEnabled(false);
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.insets = new Insets(5, 5, 0, 0);
		gbc_scrollPane.gridwidth = 9;
		gbc_scrollPane.gridheight = 8;
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 3;
		gbc_scrollPane.gridy = 3;
		add(scrollPane, gbc_scrollPane);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setText(storeid + " - Map Management");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.BOLD, 65));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.gridwidth = 12;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 0;
		add(lblNewLabel_1, gbc_lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Current Store Mapping");
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Arial Narrow", Font.BOLD, 50));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.gridwidth = 9;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_2.gridx = 3;
		gbc_lblNewLabel_2.gridy = 2;
		add(lblNewLabel_2, gbc_lblNewLabel_2);

		JLabel lblNewLabel = new JLabel("Add to Aisle");
		lblNewLabel.setForeground(new Color(154, 205, 50));
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 3;
		add(lblNewLabel, gbc_lblNewLabel);

		addAisleNumber = new JTextField("");
		addAisleNumber.setToolTipText("Aisle number");
		GridBagConstraints gbc_addAisleNumber = new GridBagConstraints();
		gbc_addAisleNumber.fill = GridBagConstraints.HORIZONTAL;
		gbc_addAisleNumber.insets = new Insets(15, 35, 15, 35);
		gbc_addAisleNumber.gridx = 0;
		gbc_addAisleNumber.gridy = 4;
		add(addAisleNumber, gbc_addAisleNumber);
		addAisleNumber.setColumns(10);

		addItemCategory = new JTextField();
		addItemCategory.setToolTipText("Item Category");
		addItemCategory.setColumns(10);
		GridBagConstraints gbc_addItemCategory = new GridBagConstraints();
		gbc_addItemCategory.gridwidth = 2;
		gbc_addItemCategory.insets = new Insets(15, 0, 15, 5);
		gbc_addItemCategory.fill = GridBagConstraints.HORIZONTAL;
		gbc_addItemCategory.gridx = 1;
		gbc_addItemCategory.gridy = 4;
		add(addItemCategory, gbc_addItemCategory);

		JLabel lblDeleteManager = new JLabel("Remove from Aisle");
		lblDeleteManager.setForeground(Color.RED);
		lblDeleteManager.setFont(new Font("Arial Narrow", Font.BOLD, 32));
		GridBagConstraints gbc_lblDeleteManager = new GridBagConstraints();
		gbc_lblDeleteManager.insets = new Insets(0, 0, 5, 5);
		gbc_lblDeleteManager.gridx = 0;
		gbc_lblDeleteManager.gridy = 6;
		add(lblDeleteManager, gbc_lblDeleteManager);

		JButton btnDelete = new JButton("Delete");
		btnDelete.setEnabled(checkEnableDeleteBtn(storeid));
		btnDelete.setHorizontalAlignment(SwingConstants.LEFT);
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String aisleNumber = null;
				String newCategory = null;
				boolean proceed = true;
				if (!removeAisleNumber.getText().isBlank()) {
					aisleNumber = removeAisleNumber.getText();
					if (!aisleNumber.matches("[0-9]+")) {
						JOptionPane.showMessageDialog(null, "Aisle number must be a positive integer number.");
						proceed = false;
					}
				}
				if (!removeItemCategory.getText().isBlank()) {
					newCategory = removeItemCategory.getText();
				}
				if (proceed) {
					if (removeAisleNumber.getText().isBlank() || removeItemCategory.getText().isBlank()) {
						JOptionPane.showMessageDialog(null, "Fill all fields.");
					} else {
						// must check for aisle existence and category existence
						int aisleValue = Integer.parseInt(aisleNumber);
						if (Database.getStoreById(storeid).getStoreMap().get(aisleValue) == null) {
							proceed = false;
							JOptionPane.showMessageDialog(null,
									"Aisle number doesn't exist within store please refer to the right for existing aisle values.");
						} else {
							Database.getStoreById(storeid).removeFromAisle(aisleValue, newCategory);
							Database.saveStoreData();
							removeAisleNumber.setText("");
							removeItemCategory.setText("");
							JOptionPane.showMessageDialog(null, "Aisle updated. Category removed.");
						}
					}
				}
				scrollPane.setViewportView(createNewTable(storeid));
				scrollPane.setEnabled(false);
				btnDelete.setEnabled(checkEnableDeleteBtn(storeid));
			}
		});
		btnDelete.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_btnDelete = new GridBagConstraints();
		gbc_btnDelete.gridwidth = 2;
		gbc_btnDelete.insets = new Insets(0, 0, 5, 5);
		gbc_btnDelete.gridx = 1;
		gbc_btnDelete.gridy = 6;
		add(btnDelete, gbc_btnDelete);

		removeAisleNumber = new JTextField();
		removeAisleNumber.setToolTipText("Aisle number");
		removeAisleNumber.setColumns(10);
		GridBagConstraints gbc_removeAisleNumber = new GridBagConstraints();
		gbc_removeAisleNumber.insets = new Insets(15, 35, 15, 35);
		gbc_removeAisleNumber.fill = GridBagConstraints.HORIZONTAL;
		gbc_removeAisleNumber.gridx = 0;
		gbc_removeAisleNumber.gridy = 7;
		add(removeAisleNumber, gbc_removeAisleNumber);

		JButton btnAdd = new JButton("Add");
		btnAdd.setHorizontalAlignment(SwingConstants.LEFT);
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String aisleNumber = null;
				String newCategory = null;
				boolean proceed = true;
				if (!addAisleNumber.getText().isBlank()) {
					aisleNumber = addAisleNumber.getText();
					if (!aisleNumber.matches("[0-9]+")) {
						JOptionPane.showMessageDialog(null, "Aisle number must be a positive integer number.");
						proceed = false;
					}
				}
				if (!addItemCategory.getText().isBlank()) {
					newCategory = addItemCategory.getText();
				}
				if (proceed) {
					if (addAisleNumber.getText().isBlank() || addItemCategory.getText().isBlank()) {
						JOptionPane.showMessageDialog(null, "Fill all fields.");
					} else {
						int aisleValue = Integer.parseInt(aisleNumber);
						Database.getStoreById(storeid).addtoAisle(aisleValue, newCategory);
						Database.saveStoreData();
						addAisleNumber.setText("");
						addItemCategory.setText("");
						JOptionPane.showMessageDialog(null, "Aisle updated. Category add.");
					}
				}
				scrollPane.setViewportView(createNewTable(storeid));
				scrollPane.setEnabled(false);
				btnDelete.setEnabled(checkEnableDeleteBtn(storeid));
			};
		});
		btnAdd.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_btnAdd = new GridBagConstraints();
		gbc_btnAdd.gridwidth = 2;
		gbc_btnAdd.insets = new Insets(0, 0, 5, 5);
		gbc_btnAdd.gridx = 1;
		gbc_btnAdd.gridy = 3;
		add(btnAdd, gbc_btnAdd);

		setPreferredSize(new Dimension(1500, 700));

		removeItemCategory = new JTextField();
		removeItemCategory.setToolTipText("Item Category");
		removeItemCategory.setColumns(10);
		GridBagConstraints gbc_removeItemCategory = new GridBagConstraints();
		gbc_removeItemCategory.gridwidth = 2;
		gbc_removeItemCategory.insets = new Insets(0, 0, 5, 5);
		gbc_removeItemCategory.fill = GridBagConstraints.HORIZONTAL;
		gbc_removeItemCategory.gridx = 1;
		gbc_removeItemCategory.gridy = 7;
		add(removeItemCategory, gbc_removeItemCategory);

		JButton backToStorePageBtn = new JButton("");
		backToStorePageBtn.setText("Back to " + storeid + " details page");
		backToStorePageBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// back to store page
				JFrame parentFrame = (JFrame) parent;
				parentFrame.getContentPane().removeAll();
				UpdateStore viewUpdateStore = new UpdateStore(storeid, parent);
				parentFrame.getContentPane().add(viewUpdateStore);
				parentFrame.pack();
				parentFrame.getContentPane().revalidate();
				parentFrame.getContentPane().repaint();
			}
		});
		backToStorePageBtn.setHorizontalAlignment(SwingConstants.LEFT);
		backToStorePageBtn.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_backToStorePageBtn = new GridBagConstraints();
		gbc_backToStorePageBtn.insets = new Insets(0, 0, 5, 5);
		gbc_backToStorePageBtn.gridx = 0;
		gbc_backToStorePageBtn.gridy = 9;
		add(backToStorePageBtn, gbc_backToStorePageBtn);
	}

	public JTable createNewTable(String storeid) {
		Database.loadAccMapData();
		Map<Integer, List<String>> currentMapping = Database.getStoreById(storeid).getStoreMap();
		Map<String, Set<Item>> categoryItems = Database.getStoreById(storeid).getCategoryItems();
		Boolean mappingExists = false;
		int size = currentMapping.size();
		String[][] actualData = new String[size][3];
		int index = 0;
		if (currentMapping.size() > 0) {
			mappingExists = true;
			for (Entry<Integer, List<String>> pair : currentMapping.entrySet()) {
				actualData[index][0] = String.valueOf(pair.getKey());
				actualData[index][1] = pair.getValue().toString();

				List<Set<Item>> itemIDList = new ArrayList<Set<Item>>();
				for (String cat : pair.getValue()) {
					if (categoryItems.get(cat) != null) {
						itemIDList.add(categoryItems.get(cat));
					}
				}
				String itemIds;
				if (itemIDList.size() > 0) {
					itemIds = itemIDList.toString();
				} else {
					itemIds = "N/A (Empty)";
				}
				actualData[index][2] = itemIds;
				index++;
			}
		}

		String[][] emptyData = new String[1][3];
		emptyData[0][0] = "N/A (Empty)";
		emptyData[0][1] = "N/A (Empty)";
		emptyData[0][2] = "N/A (Empty)";

		String[] headers = { "Aisle Number", "Items Categories Contained", "Item IDs Contained" };
		if (mappingExists) {
			existingManagers = new JTable(actualData, headers);
		} else {
			existingManagers = new JTable(emptyData, headers);
		}
		existingManagers.getTableHeader().setReorderingAllowed(false);
		existingManagers.getTableHeader().setFont(new Font("Arial Narrow", Font.BOLD, 20));
		existingManagers.getTableHeader().setResizingAllowed(false);
		existingManagers.setEnabled(false);
		existingManagers.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		return existingManagers;
	}

	public boolean checkEnableDeleteBtn(String storeid) {
		if (Database.getStoreById(storeid).getStoreMap().size() > 0) {
			return true;
		} else {
			return false;
		}
	}

}
