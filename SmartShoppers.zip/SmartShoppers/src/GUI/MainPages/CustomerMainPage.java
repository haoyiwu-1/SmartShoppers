package GUI.MainPages;
import java.awt.EventQueue;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import GUI.CustomerAccPages.CustEditProfile;
import GUI.CustomerAccPages.CustViewProfile;
import GUI.CustomerAccPages.StoreSelector;
import GUI.PrivilegedAccPages.ShowWeeklySaleItems;
import GUI.SharedMenus.helpMenuAboutText;
import GUI.SharedMenus.helpMenuText;
import GUI.SharedMenus.homeMenuText;
import SmartShoppers.SystemDatabase;
import java.awt.CardLayout;
import java.awt.Component;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CustomerMainPage extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3596624114021235882L;
	private JPanel contentPane;
	private static SystemDatabase Database;
	private ImageIcon helpIcon, houseIcon, aboutIcon, editIcon, viewIcon, searchIcon, logoutIcon;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerMainPage frame = new CustomerMainPage(args);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerMainPage(String[] numberOfStores) {
		Database = SystemDatabase.getInstance();
		Component custMainPage = this;
		helpIcon = new ImageIcon("Resources/Help.png");
		houseIcon = new ImageIcon("Resources/House.jpg");
		aboutIcon = new ImageIcon("Resources/About.png");
		editIcon = new ImageIcon("Resources/Edit.jpg");
		viewIcon = new ImageIcon("Resources/View.png");
		searchIcon = new ImageIcon("Resources/Search.jpg");
		logoutIcon = new ImageIcon("Resources/Logout.png");
		setTitle("SmartShoppers V1.0 - Customer Page");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1500, 700);
		setResizable(false);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnNewMenu = new JMenu("Home");
		menuBar.add(mnNewMenu);

		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Home");
		mntmNewMenuItem_2.setIcon(houseIcon);
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().removeAll();
				homeMenuText viewHomeText = new homeMenuText();
				getContentPane().add(viewHomeText);
				pack();
				contentPane.revalidate();
				contentPane.repaint();
			}
		});
		mnNewMenu.add(mntmNewMenuItem_2);

		JMenuItem mntmNewMenuItem_3 = new JMenuItem("Logout");
		mntmNewMenuItem_3.setIcon(logoutIcon);
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(null, "Logout?", "Logout", JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE);
				if (result == JOptionPane.YES_OPTION) {
					// logout
					JOptionPane.showMessageDialog(null,
							"You are being logged out. Please login again to use our system.");
					System.exit(0);
				} else {
					JOptionPane.showMessageDialog(null, "Log out operation canceled.");
				}
			}
		});
		mnNewMenu.add(mntmNewMenuItem_3);

		JMenu mnNewMenu_1 = new JMenu("Profile");
		menuBar.add(mnNewMenu_1);

		JMenuItem mntmNewMenuItem = new JMenuItem("View");
		mntmNewMenuItem.setIcon(viewIcon);
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().removeAll();
				CustViewProfile viewProfileView = new CustViewProfile(Database.getCurrentUser().getIdentifier());
				getContentPane().add(viewProfileView);
				pack();
				contentPane.revalidate();
				contentPane.repaint();
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem);

		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Edit");
		mntmNewMenuItem_1.setIcon(editIcon);
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().removeAll();
				CustEditProfile viewEditProfileView = new CustEditProfile(Database.getCurrentUser().getIdentifier());
				getContentPane().add(viewEditProfileView);
				pack();
				contentPane.revalidate();
				contentPane.repaint();
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_1);

		JMenu mnNewMenu_2 = new JMenu("Actions");
		menuBar.add(mnNewMenu_2);

		JMenuItem mntmNewMenuItem_4 = new JMenuItem("Store Locator");
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().removeAll();
				StoreSelector viewStoreSelector = new StoreSelector(custMainPage, Database.getCurrentUser().getIdentifier(), numberOfStores);
				getContentPane().add(viewStoreSelector);
				pack();
				contentPane.revalidate();
				contentPane.repaint();
			}
		});
		mntmNewMenuItem_4.setIcon(searchIcon);
		mnNewMenu_2.add(mntmNewMenuItem_4);
		
		JMenuItem mntmNewMenuItem_7 = new JMenuItem("See Weekly Sale Items");
		mntmNewMenuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().removeAll();
				ShowWeeklySaleItems viewWeeklySaleItems = new ShowWeeklySaleItems();
				getContentPane().add(viewWeeklySaleItems);
				pack();
				contentPane.revalidate();
				contentPane.repaint();
			}
		});
		mntmNewMenuItem_7.setIcon(viewIcon);
		mnNewMenu_2.add(mntmNewMenuItem_7);

		JMenu mnNewMenu_3 = new JMenu("Help");
		menuBar.add(mnNewMenu_3);

		JMenuItem mntmNewMenuItem_5 = new JMenuItem("Help");
		mntmNewMenuItem_5.setIcon(helpIcon);
		mntmNewMenuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().removeAll();
				helpMenuText viewHelpText = new helpMenuText();
				getContentPane().add(viewHelpText);
				pack();
				contentPane.revalidate();
				contentPane.repaint();
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_5);

		JMenuItem mntmNewMenuItem_6 = new JMenuItem("About");
		mntmNewMenuItem_6.setIcon(aboutIcon);
		mntmNewMenuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().removeAll();
				helpMenuAboutText viewAboutText = new helpMenuAboutText();
				getContentPane().add(viewAboutText);
				pack();
				contentPane.revalidate();
				contentPane.repaint();
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_6);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		
		// show weekly sale list on main page of customer
		getContentPane().removeAll();
		ShowWeeklySaleItems viewWeeklySaleItems = new ShowWeeklySaleItems();
		getContentPane().add(viewWeeklySaleItems);
		pack();
		contentPane.revalidate();
		contentPane.repaint();
	}

}
