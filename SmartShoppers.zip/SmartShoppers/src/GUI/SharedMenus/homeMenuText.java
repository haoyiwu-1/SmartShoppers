package GUI.SharedMenus;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

import SmartShoppers.SystemDatabase;

import java.awt.Insets;

public class homeMenuText extends JPanel {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -5834127355465790382L;
	public JLabel homeText;
	private SystemDatabase Database;

	public homeMenuText() {
		Database = SystemDatabase.getInstance();
		homeText = new JLabel("Home Screen");
		homeText.setFont(new Font("Arial Narrow", Font.PLAIN, 99));
		
		GridBagLayout gridBag = new GridBagLayout();
		setLayout(gridBag);
		
		GridBagConstraints home = new GridBagConstraints();
		home.gridx = 0;
		home.gridy = 0;
		home.gridheight = 1;
		home.gridwidth = 1;
		home.fill = GridBagConstraints.HORIZONTAL;
		gridBag.setConstraints(homeText, home);
		GridBagConstraints gbc_homeText = new GridBagConstraints();
		gbc_homeText.insets = new Insets(0, 0, 5, 0);
		gbc_homeText.gridx = 0;
		gbc_homeText.gridy = 0;
		add(homeText, gbc_homeText);
		setPreferredSize(new Dimension(1000, 540) );
		
		JLabel welcomeText = new JLabel("");
		welcomeText.setText("Welcome " + Database.getCurrentUser().getName() + "!");
		welcomeText.setFont(new Font("Arial Narrow", Font.BOLD, 40));
		GridBagConstraints gbc_welcomeText = new GridBagConstraints();
		gbc_welcomeText.insets = new Insets(0, 0, 5, 0);
		gbc_welcomeText.gridx = 0;
		gbc_welcomeText.gridy = 1;
		add(welcomeText, gbc_welcomeText);
		
		JLabel todayDate = new JLabel("");
		todayDate.setText(java.time.LocalDate.now().toString());
		todayDate.setFont(new Font("Arial Narrow", Font.BOLD, 55));
		GridBagConstraints gbc_todayDate = new GridBagConstraints();
		gbc_todayDate.gridx = 0;
		gbc_todayDate.gridy = 2;
		add(todayDate, gbc_todayDate);
	}
}
