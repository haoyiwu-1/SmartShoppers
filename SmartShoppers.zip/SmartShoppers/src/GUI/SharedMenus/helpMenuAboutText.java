package GUI.SharedMenus;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Insets;

public class helpMenuAboutText extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4652233283075008434L;

	public helpMenuAboutText() {

		GridBagConstraints about = new GridBagConstraints();
		about.gridx = 0;
		about.gridy = 0;
		about.gridheight = 1;
		about.gridwidth = 1;
		about.fill = GridBagConstraints.BOTH;
		setPreferredSize(new Dimension(1000, 540));
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 960, 0 };
		gridBagLayout.rowHeights = new int[] { 540, 0 };
		gridBagLayout.columnWeights = new double[] { 0.0, Double.MIN_VALUE };
		gridBagLayout.rowWeights = new double[] { 0.0, Double.MIN_VALUE };
		setLayout(gridBagLayout);

		JLabel lblNewLabel = new JLabel(
				"<html> About Smart Shoppers <br/>SmartShoppers System is a new online system that "
						+ "allows customers to find products in physical retail stores with a greater precision. The main "
						+ "goal of the software is to provide customers with a faster and smooth shopping experience in store. "
						+ "SmartShoppers will allow customers (you) to find the products that are available in a specific store "
						+ "and its location in store. This will enable you to do shopping with efficiency and grace. The team at "
						+ "SmartShoppers Inc hope that you find this system useful and to your liking. Please continue to use our "
						+ "products and stay tuned for updates.</html>");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 35));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(30, 30, 30, 30);
		gbc_lblNewLabel.ipady = 30;
		gbc_lblNewLabel.ipadx = 30;
		gbc_lblNewLabel.fill = GridBagConstraints.BOTH;
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		add(lblNewLabel, gbc_lblNewLabel);
	}
}
