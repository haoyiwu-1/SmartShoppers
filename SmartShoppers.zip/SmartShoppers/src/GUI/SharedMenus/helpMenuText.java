package GUI.SharedMenus;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Insets;

public class helpMenuText extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7528426711054836232L;
	public JLabel helpMenuText;

	public helpMenuText() {

		GridBagConstraints help = new GridBagConstraints();
		help.gridx = 0;
		help.gridy = 0;
		help.gridheight = 1;
		help.gridwidth = 1;
		help.fill = GridBagConstraints.BOTH;
		setPreferredSize(new Dimension(1000, 540));
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 960, 0 };
		gridBagLayout.rowHeights = new int[] { 540, 0 };
		gridBagLayout.columnWeights = new double[] { 0.0, Double.MIN_VALUE };
		gridBagLayout.rowWeights = new double[] { 0.0, Double.MIN_VALUE };
		setLayout(gridBagLayout);
		helpMenuText = new JLabel(
				"<html>Help Section<br/> Having troubles with our system? No worries all your data is saved and even if you log out"
						+ " your session data is saved as well.<br/>Please contact SmartShoppers support for more support at 656-565-5656 or at SmartShoppersSupp@gmail.com.</html>");
		helpMenuText.setHorizontalAlignment(SwingConstants.CENTER);
		helpMenuText.setFont(new Font("Arial Narrow", Font.BOLD, 40));
		GridBagConstraints gbc_helpMenuText = new GridBagConstraints();
		gbc_helpMenuText.insets = new Insets(30, 30, 30, 30);
		gbc_helpMenuText.fill = GridBagConstraints.BOTH;
		gbc_helpMenuText.gridx = 0;
		gbc_helpMenuText.gridy = 0;
		add(helpMenuText, gbc_helpMenuText);
	}
}
