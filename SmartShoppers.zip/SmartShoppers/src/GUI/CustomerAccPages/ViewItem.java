package GUI.CustomerAccPages;

import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JTextField;

import SmartShoppers.CustomerAccount;
import SmartShoppers.Item;
import SmartShoppers.ShoppingList;
import SmartShoppers.SystemDatabase;

import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.awt.event.ActionEvent;

public class ViewItem extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6026974446601554397L;
	private static SystemDatabase Database;
	private JTextField removeAmt;
	private JTextField addAmt;
	private JButton btnRemoveFromCart;

	/**
	 * Create the panel.
	 */
	public ViewItem(String user, String storeid, String itemID, Component parent) {
		Database = SystemDatabase.getInstance();
		setBounds(100, 100, 1500, 700);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 300, 300, 300, 300, 300 };
		gridBagLayout.rowHeights = new int[] { 87, 87, 87, 87, 87, 87, 87, 87 };
		gridBagLayout.columnWeights = new double[] { 1.0, 1.0, 1.0 };
		gridBagLayout.rowWeights = new double[] { 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		setLayout(gridBagLayout);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setText(Database.getStoreById(storeid).getItems().get(itemID).name + " - Details");
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 65));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.gridwidth = 2;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 0;
		add(lblNewLabel, gbc_lblNewLabel);

		JLabel lblNewLabel_7 = new JLabel("Current Shopping List");
		lblNewLabel_7.setFont(new Font("Arial Narrow", Font.BOLD, 50));
		GridBagConstraints gbc_lblNewLabel_7 = new GridBagConstraints();
		gbc_lblNewLabel_7.gridwidth = 2;
		gbc_lblNewLabel_7.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_7.gridx = 3;
		gbc_lblNewLabel_7.gridy = 0;
		add(lblNewLabel_7, gbc_lblNewLabel_7);

		JLabel lblNewLabel_1 = new JLabel("Item Name");
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.BOLD, 35));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 1;
		add(lblNewLabel_1, gbc_lblNewLabel_1);

		JLabel itemName = new JLabel("");
		itemName.setText(Database.getStoreById(storeid).getItems().get(itemID).name);
		itemName.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_itemName = new GridBagConstraints();
		gbc_itemName.gridwidth = 2;
		gbc_itemName.insets = new Insets(0, 0, 5, 5);
		gbc_itemName.gridx = 1;
		gbc_itemName.gridy = 1;
		add(itemName, gbc_itemName);

		JLabel currentShoppingList = new JLabel("");
		ShoppingList currentList = ((CustomerAccount) Database.getAccDetails(user)).getShoppingListFromStore(storeid);
		List<String> displayList = new ArrayList<String>();
		String itemDescription = null;
		for (Entry<String, Integer> entry : currentList.getList().entrySet()) {
			if (Database.getStoreById(storeid).getItems().get(entry.getKey()) != null) {
				itemDescription = Database.getStoreById(storeid).getItems().get(entry.getKey()).name;
				itemDescription += " - ";
				itemDescription += String.valueOf(entry.getValue());
				displayList.add(itemDescription);
			}
		}
		if (displayList.size() > 0) {
			currentShoppingList.setText(Arrays.toString(displayList.toArray(new String[0])));
		} else {
			currentShoppingList.setText("Shopping cart is empty");
		}
		currentShoppingList.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_currentShoppingList = new GridBagConstraints();
		gbc_currentShoppingList.gridheight = 4;
		gbc_currentShoppingList.gridwidth = 2;
		gbc_currentShoppingList.insets = new Insets(0, 0, 5, 0);
		gbc_currentShoppingList.gridx = 3;
		gbc_currentShoppingList.gridy = 1;
		add(currentShoppingList, gbc_currentShoppingList);

		JLabel lblNewLabel_2 = new JLabel("Item Description");
		lblNewLabel_2.setFont(new Font("Arial Narrow", Font.BOLD, 35));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 0;
		gbc_lblNewLabel_2.gridy = 2;
		add(lblNewLabel_2, gbc_lblNewLabel_2);

		JLabel itemDesc = new JLabel("");
		itemDesc.setText(Database.getStoreById(storeid).getItems().get(itemID).description);
		itemDesc.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_itemDesc = new GridBagConstraints();
		gbc_itemDesc.gridwidth = 2;
		gbc_itemDesc.insets = new Insets(0, 0, 5, 5);
		gbc_itemDesc.gridx = 1;
		gbc_itemDesc.gridy = 2;
		add(itemDesc, gbc_itemDesc);

		JLabel lblNewLabel_3 = new JLabel("Item Price");
		lblNewLabel_3.setFont(new Font("Arial Narrow", Font.BOLD, 35));
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3.gridx = 0;
		gbc_lblNewLabel_3.gridy = 3;
		add(lblNewLabel_3, gbc_lblNewLabel_3);

		JLabel itemPrice = new JLabel("");
		itemPrice.setText(String.valueOf(Database.getStoreById(storeid).getItems().get(itemID).price));
		itemPrice.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_itemPrice = new GridBagConstraints();
		gbc_itemPrice.gridwidth = 2;
		gbc_itemPrice.insets = new Insets(0, 0, 5, 5);
		gbc_itemPrice.gridx = 1;
		gbc_itemPrice.gridy = 3;
		add(itemPrice, gbc_itemPrice);

		JLabel lblNewLabel_4 = new JLabel("Item Size");
		lblNewLabel_4.setFont(new Font("Arial Narrow", Font.BOLD, 35));
		GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
		gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4.gridx = 0;
		gbc_lblNewLabel_4.gridy = 4;
		add(lblNewLabel_4, gbc_lblNewLabel_4);

		JLabel itemSize = new JLabel("");
		itemSize.setText(Database.getStoreById(storeid).getItems().get(itemID).size);
		itemSize.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_itemSize = new GridBagConstraints();
		gbc_itemSize.gridwidth = 2;
		gbc_itemSize.insets = new Insets(0, 0, 5, 5);
		gbc_itemSize.gridx = 1;
		gbc_itemSize.gridy = 4;
		add(itemSize, gbc_itemSize);

		JLabel lblNewLabel_5 = new JLabel("Item Availability");
		lblNewLabel_5.setFont(new Font("Arial Narrow", Font.BOLD, 35));
		GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
		gbc_lblNewLabel_5.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_5.gridx = 0;
		gbc_lblNewLabel_5.gridy = 5;
		add(lblNewLabel_5, gbc_lblNewLabel_5);

		JLabel ItemAvailability = new JLabel("");
		int amount = Database.getStoreById(storeid).getInv().get(Database.getStoreById(storeid).getItems().get(itemID));
		if (amount > 0) {
			ItemAvailability.setText("This item is available.");
		} else {
			ItemAvailability.setText("This item is not available.");
		}
		ItemAvailability.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_ItemAvailability = new GridBagConstraints();
		gbc_ItemAvailability.gridwidth = 2;
		gbc_ItemAvailability.insets = new Insets(0, 0, 5, 5);
		gbc_ItemAvailability.gridx = 1;
		gbc_ItemAvailability.gridy = 5;
		add(ItemAvailability, gbc_ItemAvailability);

		addAmt = new JTextField();
		addAmt.setToolTipText("Amount to add");
		addAmt.setColumns(10);
		GridBagConstraints gbc_addAmt = new GridBagConstraints();
		gbc_addAmt.insets = new Insets(0, 65, 5, 65);
		gbc_addAmt.fill = GridBagConstraints.HORIZONTAL;
		gbc_addAmt.gridx = 3;
		gbc_addAmt.gridy = 5;
		add(addAmt, gbc_addAmt);

		removeAmt = new JTextField();
		removeAmt.setToolTipText("Amount to remove");
		GridBagConstraints gbc_removeAmt = new GridBagConstraints();
		gbc_removeAmt.insets = new Insets(0, 65, 5, 65);
		gbc_removeAmt.fill = GridBagConstraints.HORIZONTAL;
		gbc_removeAmt.gridx = 4;
		gbc_removeAmt.gridy = 5;
		add(removeAmt, gbc_removeAmt);
		removeAmt.setColumns(10);

		JLabel lblNewLabel_6 = new JLabel("Item Category");
		lblNewLabel_6.setFont(new Font("Arial Narrow", Font.BOLD, 35));
		GridBagConstraints gbc_lblNewLabel_6 = new GridBagConstraints();
		gbc_lblNewLabel_6.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_6.gridx = 0;
		gbc_lblNewLabel_6.gridy = 6;
		add(lblNewLabel_6, gbc_lblNewLabel_6);

		JLabel itemCategory = new JLabel("");
		itemCategory.setText(Database.getStoreById(storeid).getItems().get(itemID).category);
		itemCategory.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_itemCategory = new GridBagConstraints();
		gbc_itemCategory.gridwidth = 2;
		gbc_itemCategory.insets = new Insets(0, 0, 5, 5);
		gbc_itemCategory.gridx = 1;
		gbc_itemCategory.gridy = 6;
		add(itemCategory, gbc_itemCategory);

		JButton backToStoreDetails = new JButton("");
		backToStoreDetails.setText("Back to " + storeid + " main page");
		backToStoreDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// back to store page
				JFrame parentFrame = (JFrame) parent;
				parentFrame.getContentPane().removeAll();
				VisitStore viewVisitStore = new VisitStore(storeid, user, parent);
				parentFrame.getContentPane().add(viewVisitStore);
				parentFrame.pack();
				parentFrame.getContentPane().revalidate();
				parentFrame.getContentPane().repaint();
			}
		});

		JButton btnAddToList = new JButton("Add To Shopping List");
		if (Database.getStoreById(storeid).getInv().get(Database.getStoreById(storeid).getItems().get(itemID)) > 0) {
			btnAddToList.setEnabled(true);
		} else {
			btnAddToList.setEnabled(false);
		}
		btnAddToList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// add to this specific store's shopping list for this user
				String addQuantityValue = null;
				int inventory = Database.getStoreById(storeid).getInv()
						.get(Database.getStoreById(storeid).getItems().get(itemID));
				boolean proceed = true;
				if (!addAmt.getText().isBlank()) {
					addQuantityValue = addAmt.getText();

					if (!addQuantityValue.matches("[0-9]+") || Integer.parseInt(addQuantityValue) > inventory) {
						JOptionPane.showMessageDialog(null,
								"Quantity must be a positive integer number and not larger than available stock.");
						proceed = false;
					}
				}
				if (proceed) {
					if (addAmt.getText().isBlank()) {
						JOptionPane.showMessageDialog(null, "Add field cannot be blank.");
					} else {
						int quantity = Integer.parseInt(addQuantityValue);
						((CustomerAccount) Database.getAccDetails(user)).getShoppingListFromStore(storeid)
								.addItem(itemID, quantity);
						Database.saveAccMapData();
						// fix inventory of store as we add and remove items
						// remove items from inventory
						Item itemToUpdate = Database.getStoreById(storeid).getItems().get(itemID);
						Database.getStoreById(storeid).changeInventory(itemToUpdate, inventory - quantity);
						Database.saveStoreData();
						JOptionPane.showMessageDialog(null, "Item(s) added to shopping list.");
					}
				}
				ShoppingList currentList = ((CustomerAccount) Database.getAccDetails(user))
						.getShoppingListFromStore(storeid);
				List<String> displayList = new ArrayList<String>();
				String itemDescription = null;
				for (Entry<String, Integer> entry : currentList.getList().entrySet()) {
					if (Database.getStoreById(storeid).getItems().get(entry.getKey()) != null) {
						itemDescription = Database.getStoreById(storeid).getItems().get(entry.getKey()).name;
						itemDescription += " - ";
						itemDescription += String.valueOf(entry.getValue());
						displayList.add(itemDescription);
					}
				}
				if (displayList.size() > 0) {
					currentShoppingList.setText(Arrays.toString(displayList.toArray(new String[0])));
				} else {
					currentShoppingList.setText("Shopping cart is empty");
				}
				if (Database.getStoreById(storeid).getInv()
						.get(Database.getStoreById(storeid).getItems().get(itemID)) > 0) {
					btnAddToList.setEnabled(true);
				} else {
					btnAddToList.setEnabled(false);
				}
				if (((CustomerAccount) Database.getAccDetails(user)).getShoppingListFromStore(storeid).getList()
						.containsKey(itemID)) {
					btnRemoveFromCart.setEnabled(true);
				} else {
					btnRemoveFromCart.setEnabled(false);
				}
			}
		});
		btnAddToList.setFont(new Font("Arial Narrow", Font.BOLD, 25));

		GridBagConstraints gbc_btnAddToList = new GridBagConstraints();
		gbc_btnAddToList.insets = new Insets(0, 0, 5, 5);
		gbc_btnAddToList.gridx = 3;
		gbc_btnAddToList.gridy = 6;

		add(btnAddToList, gbc_btnAddToList);

		btnRemoveFromCart = new JButton("Remove From Shopping List");
		if (((CustomerAccount) Database.getAccDetails(user)).getShoppingListFromStore(storeid).getList()
				.containsKey(itemID)) {
			btnRemoveFromCart.setEnabled(true);
		} else {
			btnRemoveFromCart.setEnabled(false);
		}
		btnRemoveFromCart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// remove from this specific store's shopping list for this user
				// add to this specific store's shopping list for this user
				String removeQuantityValue = null;
				int inventory = Database.getStoreById(storeid).getInv()
						.get(Database.getStoreById(storeid).getItems().get(itemID));
				int currentAmt = ((CustomerAccount) Database.getAccDetails(user)).getShoppingListFromStore(storeid)
						.getList().get(itemID);
				boolean proceed = true;
				if (!removeAmt.getText().isBlank()) {

					removeQuantityValue = removeAmt.getText();
					if (!removeQuantityValue.matches("[0-9]+") || Integer.parseInt(removeQuantityValue) > currentAmt) {
						JOptionPane.showMessageDialog(null,
								"Quantity must be a positive integer number and not larger than amount in shopping list.");
						proceed = false;
					}
				}
				if (proceed) {
					if (removeAmt.getText().isBlank()) {
						JOptionPane.showMessageDialog(null, "Remove field cannot be blank.");
					} else {
						int quantity = Integer.parseInt(removeQuantityValue);
						((CustomerAccount) Database.getAccDetails(user)).getShoppingListFromStore(storeid)
								.removeItem(itemID, quantity);
						Database.saveAccMapData();
						// fix inventory of store as we add and remove items
						// add items back to inventory
						Item itemToUpdate = Database.getStoreById(storeid).getItems().get(itemID);
						Database.getStoreById(storeid).changeInventory(itemToUpdate, inventory + quantity);
						Database.saveStoreData();
						JOptionPane.showMessageDialog(null, "Item(s) removed from shopping list.");
					}
				}
				ShoppingList currentList = ((CustomerAccount) Database.getAccDetails(user))
						.getShoppingListFromStore(storeid);
				List<String> displayList = new ArrayList<String>();
				String itemDescription = null;
				for (Entry<String, Integer> entry : currentList.getList().entrySet()) {
					if (Database.getStoreById(storeid).getItems().get(entry.getKey()) != null) {
						itemDescription = Database.getStoreById(storeid).getItems().get(entry.getKey()).name;
						itemDescription += " - ";
						itemDescription += String.valueOf(entry.getValue());
						displayList.add(itemDescription);
					}
				}
				if (displayList.size() > 0) {
					currentShoppingList.setText(Arrays.toString(displayList.toArray(new String[0])));
				} else {
					currentShoppingList.setText("Shopping cart is empty");
				}
				if (Database.getStoreById(storeid).getInv()
						.get(Database.getStoreById(storeid).getItems().get(itemID)) > 0) {
					btnAddToList.setEnabled(true);
				} else {
					btnAddToList.setEnabled(false);
				}
				if (((CustomerAccount) Database.getAccDetails(user)).getShoppingListFromStore(storeid).getList()
						.containsKey(itemID)) {
					btnRemoveFromCart.setEnabled(true);
				} else {
					btnRemoveFromCart.setEnabled(false);
				}
			}
		});
		btnRemoveFromCart.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_btnRemoveFromCart = new GridBagConstraints();
		gbc_btnRemoveFromCart.insets = new Insets(0, 0, 5, 0);
		gbc_btnRemoveFromCart.gridx = 4;
		gbc_btnRemoveFromCart.gridy = 6;
		add(btnRemoveFromCart, gbc_btnRemoveFromCart);
		backToStoreDetails.setFont(new Font("Arial Narrow", Font.BOLD, 40));
		GridBagConstraints gbc_backToStoreDetails = new GridBagConstraints();
		gbc_backToStoreDetails.gridwidth = 2;
		gbc_backToStoreDetails.gridx = 3;
		gbc_backToStoreDetails.gridy = 7;
		add(backToStoreDetails, gbc_backToStoreDetails);
	}
}
