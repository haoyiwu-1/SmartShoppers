package GUI.CustomerAccPages;

import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;

import SmartShoppers.CustomerAccount;
import SmartShoppers.SystemDatabase;
import SmartShoppers.UserAccount;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;

public class CustEditProfile extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5784238681166304040L;
	private JTextField userInput;
	private JTextField passInput;
	private JTextField nameInput;
	private JTextField emailInput;
	private static SystemDatabase Database;
	private static String existingAccOrNot;
	private boolean changingUser;
	private JButton off2FA, on2FA;

	/**
	 * Create the panel.
	 */
	public CustEditProfile(String username) {
		Database = SystemDatabase.getInstance();
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.rowHeights = new int[] { 70, 70, 0, 70, 70, 70, 70, 80 };
		gridBagLayout.columnWidths = new int[] { 240, 240, 240, 240 };
		gridBagLayout.columnWeights = new double[] { 1.0 };
		gridBagLayout.rowWeights = new double[] { Double.MIN_VALUE, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		setLayout(gridBagLayout);

		JLabel title = new JLabel("Edit Profile");
		title.setFont(new Font("Arial Narrow", Font.BOLD, 40));
		GridBagConstraints gbc_title = new GridBagConstraints();
		gbc_title.gridwidth = 2;
		gbc_title.insets = new Insets(0, 0, 5, 5);
		gbc_title.gridx = 1;
		gbc_title.gridy = 0;
		add(title, gbc_title);

		JLabel usernameLbl = new JLabel("Username");
		usernameLbl.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_usernameLbl = new GridBagConstraints();
		gbc_usernameLbl.insets = new Insets(0, 0, 5, 5);
		gbc_usernameLbl.gridx = 1;
		gbc_usernameLbl.gridy = 1;
		add(usernameLbl, gbc_usernameLbl);

		userInput = new JTextField();
		userInput.setFont(new Font("Tahoma", Font.PLAIN, 11));
		GridBagConstraints gbc_userInput = new GridBagConstraints();
		gbc_userInput.insets = new Insets(0, 0, 5, 5);
		gbc_userInput.fill = GridBagConstraints.HORIZONTAL;
		gbc_userInput.gridx = 2;
		gbc_userInput.gridy = 1;
		add(userInput, gbc_userInput);
		userInput.setColumns(10);

		JLabel warning = new JLabel("");
		warning.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		GridBagConstraints gbc_warning = new GridBagConstraints();
		gbc_warning.insets = new Insets(0, 0, 5, 5);
		gbc_warning.gridx = 2;
		gbc_warning.gridy = 2;
		add(warning, gbc_warning);

		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 1;
		gbc_lblNewLabel_1.gridy = 3;
		add(lblNewLabel_1, gbc_lblNewLabel_1);

		passInput = new JTextField();
		passInput.setFont(new Font("Tahoma", Font.PLAIN, 11));
		passInput.setColumns(10);
		GridBagConstraints gbc_passInput = new GridBagConstraints();
		gbc_passInput.insets = new Insets(0, 0, 5, 5);
		gbc_passInput.fill = GridBagConstraints.HORIZONTAL;
		gbc_passInput.gridx = 2;
		gbc_passInput.gridy = 3;
		add(passInput, gbc_passInput);

		JLabel lblNewLabel_2 = new JLabel("Name");
		lblNewLabel_2.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 1;
		gbc_lblNewLabel_2.gridy = 4;
		add(lblNewLabel_2, gbc_lblNewLabel_2);

		nameInput = new JTextField();
		nameInput.setFont(new Font("Tahoma", Font.PLAIN, 11));
		nameInput.setColumns(10);
		GridBagConstraints gbc_nameInput = new GridBagConstraints();
		gbc_nameInput.insets = new Insets(0, 0, 5, 5);
		gbc_nameInput.fill = GridBagConstraints.HORIZONTAL;
		gbc_nameInput.gridx = 2;
		gbc_nameInput.gridy = 4;
		add(nameInput, gbc_nameInput);

		JLabel lblNewLabel_3 = new JLabel("Email");
		lblNewLabel_3.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3.gridx = 1;
		gbc_lblNewLabel_3.gridy = 5;
		add(lblNewLabel_3, gbc_lblNewLabel_3);

		emailInput = new JTextField();
		emailInput.setFont(new Font("Tahoma", Font.PLAIN, 11));
		emailInput.setColumns(10);
		GridBagConstraints gbc_emailInput = new GridBagConstraints();
		gbc_emailInput.insets = new Insets(0, 0, 5, 5);
		gbc_emailInput.fill = GridBagConstraints.HORIZONTAL;
		gbc_emailInput.gridx = 2;
		gbc_emailInput.gridy = 5;
		add(emailInput, gbc_emailInput);

		JButton btnDeleteAccount = new JButton("Delete Account");
		btnDeleteAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to delete your account and associated data permanently?",
						"Delete Account", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
				if (result == JOptionPane.YES_OPTION) {
					// delete acc
					Database.removeUserAccount(username);
					Database.saveAccMapData();
					JOptionPane.showMessageDialog(null,
							"Your account and data has been deleted. You will now be forced out of the SmartShoppers System. We will miss you. "
									+ "To use our system again in the future please know that you must create a new account for access.");
					System.exit(0);
				} else {
					// don't delete acc
					JOptionPane.showMessageDialog(null,
							"Good choice. We at SmartShoppers Inc would like you to stay. Redirecting back to edit profile page...");
				}
			}
		});

		JComboBox<String> comboBox = new JComboBox<String>();
		List<String> stores = Database.getStoresID();
		List<String> storesLocs = new ArrayList<String>();
		for (String ids : stores) {
			storesLocs.add(Database.getStoreById(ids).getLocation());
		}
		List<String> combinedStoreValues = new ArrayList<String>();
		for (int i = 0; i < stores.size(); i++) {
			combinedStoreValues.add(i, stores.get(i) + " - " + storesLocs.get(i));
		}
		for (String value : combinedStoreValues) {
			comboBox.addItem(value);
		}
		GridBagConstraints gbc_comboBox = new GridBagConstraints();
		gbc_comboBox.insets = new Insets(0, 0, 5, 5);
		gbc_comboBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_comboBox.gridx = 2;
		gbc_comboBox.gridy = 6;
		add(comboBox, gbc_comboBox);

		JLabel lblNewLabel_3_1 = new JLabel("Preferred Store");
		lblNewLabel_3_1.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel_3_1 = new GridBagConstraints();
		gbc_lblNewLabel_3_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3_1.gridx = 1;
		gbc_lblNewLabel_3_1.gridy = 6;
		add(lblNewLabel_3_1, gbc_lblNewLabel_3_1);

		JButton btnNewButton = new JButton("Save Changes");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserAccount newAcc = Database.getAccDetails(username);
				if (!userInput.getText().isBlank()) {
					newAcc.setIdentifier(userInput.getText());
					existingAccOrNot = userInput.getText();
				} else {
					existingAccOrNot = username;
				}
				if (!passInput.getText().isBlank()) {
					newAcc.setPassword(passInput.getText());
				}
				if (!nameInput.getText().isBlank()) {
					newAcc.setName(nameInput.getText());
				}
				if (!emailInput.getText().isBlank()) {
					newAcc.setEmail(emailInput.getText());
				}
				if (comboBox.getSelectedItem() != null) {
					String storeId = comboBox.getSelectedItem().toString().split("-")[0].strip();
					((CustomerAccount) newAcc)
							.changePrefStore(Database.getStoreById(storeId));
				}
				if (!existingAccOrNot.equals(username)) {
					changingUser = true;
				}
				
				if (userInput.getText().isBlank() && passInput.getText().isBlank() && nameInput.getText().isBlank()
						&& emailInput.getText().isBlank() && comboBox.getSelectedItem() == null) {
					JOptionPane.showMessageDialog(null, "Please fill at least one field.");
				} else {
					if (Database.doesAccExists(existingAccOrNot) && changingUser) {
						warning.setText("Username already exists");
						warning.setForeground(Color.RED);
						userInput.setText("");
					} else {
						Database.removeUserAccount(username);
						Database.addUserAcc(newAcc);
						Database.saveAccMapData();
						Database.loadCurrentUser(newAcc.getIdentifier());
						JOptionPane.showMessageDialog(null, "Changes have been applied to your account.");
						userInput.setText("");
						passInput.setText("");
						nameInput.setText("");
						emailInput.setText("");
					}
				}

			}
		});

		btnNewButton.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton.gridx = 2;
		gbc_btnNewButton.gridy = 7;
		add(btnNewButton, gbc_btnNewButton);

		on2FA = new JButton("Turn on 2FA");
		if (Database.getAccDetails(username).getAuth()) {
			on2FA.setEnabled(false);
		} else {
			on2FA.setEnabled(true);
		}
		on2FA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserAccount newAcc = Database.getAccDetails(username);
				newAcc.setAuth(true);
				Database.removeUserAccount(username);
				Database.addUserAcc(newAcc);
				Database.saveAccMapData();
				Database.loadCurrentUser(newAcc.getIdentifier());
				JOptionPane.showMessageDialog(null, "2FA for your account has been turned on.");
				on2FA.setEnabled(false);
				off2FA.setEnabled(true);
			}
		});
		on2FA.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_on2FA = new GridBagConstraints();
		gbc_on2FA.insets = new Insets(0, 0, 5, 0);
		gbc_on2FA.gridx = 3;
		gbc_on2FA.gridy = 6;
		add(on2FA, gbc_on2FA);
		btnDeleteAccount.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_btnDeleteAccount = new GridBagConstraints();
		gbc_btnDeleteAccount.insets = new Insets(0, 0, 0, 5);
		gbc_btnDeleteAccount.gridx = 1;
		gbc_btnDeleteAccount.gridy = 7;
		add(btnDeleteAccount, gbc_btnDeleteAccount);

		off2FA = new JButton("Turn off 2FA");
		if (Database.getAccDetails(username).getAuth()) {
			off2FA.setEnabled(true);
		} else {
			off2FA.setEnabled(false);
		}
		off2FA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserAccount newAcc = Database.getAccDetails(username);
				newAcc.setAuth(false);
				Database.removeUserAccount(username);
				Database.addUserAcc(newAcc);
				Database.saveAccMapData();
				Database.loadCurrentUser(newAcc.getIdentifier());
				JOptionPane.showMessageDialog(null, "2FA for your account has been turned off.");
				off2FA.setEnabled(false);
				on2FA.setEnabled(true);
			}
		});
		off2FA.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_off2FA = new GridBagConstraints();
		gbc_off2FA.gridx = 3;
		gbc_off2FA.gridy = 7;
		add(off2FA, gbc_off2FA);

		setBounds(100, 100, 1200, 800);
	}
}
