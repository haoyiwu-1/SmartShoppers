package GUI.CustomerAccPages;
import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import SmartShoppers.CustomerAccount;
import SmartShoppers.SystemDatabase;
import java.awt.Insets;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.awt.event.ActionEvent;

public class StoreSelector extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3471972329424538248L;
	private static SystemDatabase Database;

	/**
	 * Create the panel.
	 */
	public StoreSelector(Component parent, String user, String[] storeCount) {
		Database = SystemDatabase.getInstance();
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 50, 50, 50, 50, 50, 50 };
		gridBagLayout.rowHeights = new int[] { 50, 50, 30, 50, 50 };
		gridBagLayout.columnWeights = new double[] { 0.0, 0.0, 1.0 };
		gridBagLayout.rowWeights = new double[] { 0.0, 0.0, Double.MIN_VALUE };
		setLayout(gridBagLayout);

		JLabel lblNewLabel = new JLabel("Store Search");
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 45));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridwidth = 2;
		gbc_lblNewLabel.gridx = 2;
		gbc_lblNewLabel.gridy = 1;
		add(lblNewLabel, gbc_lblNewLabel);

		JComboBox<String> comboBox = new JComboBox<String>();
		List<String> stores = Database.getStoresID();
		List<String> storesLocs = new ArrayList<String>();
		for (String ids : stores) {
			storesLocs.add(Database.getStoreById(ids).getLocation());
		}
		List<String> combinedStoreValues = new ArrayList<String>();
		for (int i = 0; i < stores.size(); i++) {
			combinedStoreValues.add(i, stores.get(i) + " - " + storesLocs.get(i));
		}
		// generate random number between 1 and size of store list for amount this will be generate on login
		// generate random numbers (not repeating to pick stores at random) for the user
		Set<String> randomStoreSet = new HashSet<String>();
		if (combinedStoreValues.size() > 1) {
			for (int i = 0; i < Integer.parseInt(storeCount[0]); i++) {
				randomStoreSet.add(combinedStoreValues.get(i));
			}
			for (String value : randomStoreSet) {
				comboBox.addItem(value);
			}
		} else {
			for (String value : combinedStoreValues) {
				comboBox.addItem(value);
			}
		}
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// to that store page
				JFrame parentFrame = (JFrame) parent;
				parentFrame.getContentPane().removeAll();
				String storeId = comboBox.getSelectedItem().toString().split("-")[0].strip();

				if (((CustomerAccount) Database.getAccDetails(user)).getShoppingListFromStore(storeId) != null) {

				} else {
					((CustomerAccount) Database.getAccDetails(user)).addNewShoppingListToStore(storeId);
				}
				Database.saveAccMapData();
				VisitStore viewVisitStore = new VisitStore(storeId, user, parentFrame);
				parentFrame.getContentPane().add(viewVisitStore);
				parentFrame.pack();
				parentFrame.getContentPane().revalidate();
				parentFrame.getContentPane().repaint();
			}
		});
		comboBox.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_comboBox = new GridBagConstraints();
		gbc_comboBox.gridwidth = 2;
		gbc_comboBox.insets = new Insets(0, 0, 5, 5);
		gbc_comboBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_comboBox.gridx = 2;
		gbc_comboBox.gridy = 2;
		add(comboBox, gbc_comboBox);
		setPreferredSize(new Dimension(1500, 700));
	}

}
