package GUI.CustomerAccPages;

import javax.swing.JPanel;
import SmartShoppers.CustomerAccount;
import SmartShoppers.SystemDatabase;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import javax.swing.SwingConstants;

public class CustViewProfile extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8001509127330381002L;
	private static SystemDatabase Database;

	/**
	 * Create the panel.
	 */
	public CustViewProfile(String username) {
		Database = SystemDatabase.getInstance();
		CustomerAccount accDetails = (CustomerAccount) Database.getAccDetails(username);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 75, 75, 75, 75, 75, 75, 75, 75 };
		gridBagLayout.rowHeights = new int[] { 50, 50, 50, 50, 50, 50, 50, 50, 55, 55, 0 };
		gridBagLayout.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		gridBagLayout.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		setLayout(gridBagLayout);

		JLabel lblNewLabel = new JLabel("Profile Details");
		lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 40));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridwidth = 6;
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 0;
		add(lblNewLabel, gbc_lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Username:");
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridwidth = 2;
		gbc_lblNewLabel_1.gridx = 2;
		gbc_lblNewLabel_1.gridy = 1;
		add(lblNewLabel_1, gbc_lblNewLabel_1);

		JLabel usernameOut = new JLabel("");
		usernameOut.setText(accDetails.getIdentifier());
		usernameOut.setForeground(Color.BLUE);
		usernameOut.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_usernameOut = new GridBagConstraints();
		gbc_usernameOut.gridwidth = 2;
		gbc_usernameOut.insets = new Insets(0, 0, 5, 5);
		gbc_usernameOut.gridx = 4;
		gbc_usernameOut.gridy = 1;
		add(usernameOut, gbc_usernameOut);

		JLabel lblNewLabel_2 = new JLabel("Password:");
		lblNewLabel_2.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.gridwidth = 2;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 2;
		gbc_lblNewLabel_2.gridy = 2;
		add(lblNewLabel_2, gbc_lblNewLabel_2);

		JLabel passwordOut = new JLabel("");
		passwordOut.setText(accDetails.getPassword());
		passwordOut.setForeground(Color.BLUE);
		passwordOut.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_passwordOut = new GridBagConstraints();
		gbc_passwordOut.gridwidth = 2;
		gbc_passwordOut.insets = new Insets(0, 0, 5, 5);
		gbc_passwordOut.gridx = 4;
		gbc_passwordOut.gridy = 2;
		add(passwordOut, gbc_passwordOut);

		JLabel lblNewLabel_2_1 = new JLabel("Name:");
		lblNewLabel_2_1.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_2_1 = new GridBagConstraints();
		gbc_lblNewLabel_2_1.gridwidth = 2;
		gbc_lblNewLabel_2_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2_1.gridx = 2;
		gbc_lblNewLabel_2_1.gridy = 3;
		add(lblNewLabel_2_1, gbc_lblNewLabel_2_1);

		JLabel nameOut = new JLabel("");
		nameOut.setText(accDetails.getName());
		nameOut.setForeground(Color.BLUE);
		nameOut.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_nameOut = new GridBagConstraints();
		gbc_nameOut.gridwidth = 2;
		gbc_nameOut.insets = new Insets(0, 0, 5, 5);
		gbc_nameOut.gridx = 4;
		gbc_nameOut.gridy = 3;
		add(nameOut, gbc_nameOut);

		JLabel lblNewLabel_2_2 = new JLabel("Email:");
		lblNewLabel_2_2.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_2_2 = new GridBagConstraints();
		gbc_lblNewLabel_2_2.gridwidth = 2;
		gbc_lblNewLabel_2_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2_2.gridx = 2;
		gbc_lblNewLabel_2_2.gridy = 4;
		add(lblNewLabel_2_2, gbc_lblNewLabel_2_2);

		JLabel emailOut = new JLabel("");
		emailOut.setText(accDetails.getEmail());
		emailOut.setForeground(Color.BLUE);
		emailOut.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_emailOut = new GridBagConstraints();
		gbc_emailOut.gridwidth = 2;
		gbc_emailOut.insets = new Insets(0, 0, 5, 5);
		gbc_emailOut.gridx = 4;
		gbc_emailOut.gridy = 4;
		add(emailOut, gbc_emailOut);

		JLabel lblNewLabel_2_2_1 = new JLabel("Preferred Store:");
		lblNewLabel_2_2_1.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_2_2_1 = new GridBagConstraints();
		gbc_lblNewLabel_2_2_1.gridwidth = 2;
		gbc_lblNewLabel_2_2_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2_2_1.gridx = 2;
		gbc_lblNewLabel_2_2_1.gridy = 5;
		add(lblNewLabel_2_2_1, gbc_lblNewLabel_2_2_1);

		JLabel prefStoreOut = new JLabel((String) null);
		CustomerAccount newCustAcc = (CustomerAccount) accDetails;
		prefStoreOut.setText(newCustAcc.getPrefStore());
		prefStoreOut.setForeground(Color.BLUE);
		prefStoreOut.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_perfStoreOut = new GridBagConstraints();
		gbc_perfStoreOut.gridwidth = 2;
		gbc_perfStoreOut.insets = new Insets(0, 0, 5, 5);
		gbc_perfStoreOut.gridx = 4;
		gbc_perfStoreOut.gridy = 5;
		add(prefStoreOut, gbc_perfStoreOut);

		JLabel lblNewLabel_2_2_1_1_1 = new JLabel("Saved Stores:");
		lblNewLabel_2_2_1_1_1.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_2_2_1_1_1 = new GridBagConstraints();
		gbc_lblNewLabel_2_2_1_1_1.gridwidth = 2;
		gbc_lblNewLabel_2_2_1_1_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2_2_1_1_1.gridx = 2;
		gbc_lblNewLabel_2_2_1_1_1.gridy = 6;
		add(lblNewLabel_2_2_1_1_1, gbc_lblNewLabel_2_2_1_1_1);
		
		JLabel TwoFAOut = new JLabel((String) null);
		if (accDetails.getAuth()) {
			TwoFAOut.setText("ON");
		} else {
			TwoFAOut.setText("OFF");
		}
		TwoFAOut.setForeground(Color.BLUE);
		TwoFAOut.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_TwoFAOut = new GridBagConstraints();
		gbc_TwoFAOut.gridwidth = 2;
		gbc_TwoFAOut.insets = new Insets(0, 0, 5, 5);
		gbc_TwoFAOut.gridx = 4;
		gbc_TwoFAOut.gridy = 9;
		add(TwoFAOut, gbc_TwoFAOut);
		
		JLabel savedStoresOut = new JLabel((String) null);
		savedStoresOut.setHorizontalAlignment(SwingConstants.CENTER);
		savedStoresOut.setText(newCustAcc.getSavedStoresString());
		savedStoresOut.setForeground(Color.BLUE);
		savedStoresOut.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		GridBagConstraints gbc_savedStoresOut = new GridBagConstraints();
		gbc_savedStoresOut.gridheight = 2;
		gbc_savedStoresOut.gridwidth = 4;
		gbc_savedStoresOut.insets = new Insets(0, 0, 5, 5);
		gbc_savedStoresOut.gridx = 2;
		gbc_savedStoresOut.gridy = 7;
		add(savedStoresOut, gbc_savedStoresOut);

		setBounds(100, 100, 1200, 800);
		JLabel lblNewLabel_2_2_1_1 = new JLabel("2FA:");
		lblNewLabel_2_2_1_1.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_2_2_1_1 = new GridBagConstraints();
		gbc_lblNewLabel_2_2_1_1.gridwidth = 2;
		gbc_lblNewLabel_2_2_1_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2_2_1_1.gridx = 2;
		gbc_lblNewLabel_2_2_1_1.gridy = 9;
		add(lblNewLabel_2_2_1_1, gbc_lblNewLabel_2_2_1_1);
	}

}
