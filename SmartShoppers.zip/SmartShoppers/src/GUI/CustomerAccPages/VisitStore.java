package GUI.CustomerAccPages;

import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JTable;
import SmartShoppers.CustomerAccount;
import SmartShoppers.Item;
import SmartShoppers.ShoppingList;
import SmartShoppers.SystemDatabase;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.BorderFactory;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JTextArea;

public class VisitStore extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 347324484011489801L;
	private static SystemDatabase Database;
	private JTable existingItems;
	private JButton btnUnsaveStore;
	private JButton btnSaveStore;
	private JTextField searchByName;

	/**
	 * Create the panel.
	 */
	public VisitStore(String storeid, String user, Component parent) {
		Database = SystemDatabase.getInstance();
		Database.getStoreById(storeid).setSuggestedItemList(Database.generateSuggestedList(storeid, user));
		Database.saveStoreData();
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 100, 100, 100, 100, 100, 200, 200, 200, 0 };
		gridBagLayout.columnWeights = new double[] { 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0 };
		gridBagLayout.rowWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
				0.0, 0.0, 0.0, 1.0, 0.0, 0.0 };
		setLayout(gridBagLayout);

		JTable existingItems = createNewTable(storeid);
		GridBagConstraints gbc_existingItems = new GridBagConstraints();
		gbc_existingItems.insets = new Insets(0, 0, 0, 5);
		gbc_existingItems.gridheight = 5;
		gbc_existingItems.gridwidth = 7;
		gbc_existingItems.fill = GridBagConstraints.BOTH;
		gbc_existingItems.gridx = 2;
		gbc_existingItems.gridy = 3;
		add(existingItems, gbc_existingItems);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setText(storeid + " - Details");
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.BOLD, 60));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.gridwidth = 6;
		gbc_lblNewLabel_1.gridheight = 3;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 0;
		add(lblNewLabel_1, gbc_lblNewLabel_1);

		JLabel lblNewLabel_3_3 = new JLabel("Shopping Cart");
		lblNewLabel_3_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_3.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_3_3 = new GridBagConstraints();
		gbc_lblNewLabel_3_3.gridwidth = 2;
		gbc_lblNewLabel_3_3.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3_3.gridx = 6;
		gbc_lblNewLabel_3_3.gridy = 0;
		add(lblNewLabel_3_3, gbc_lblNewLabel_3_3);

		JLabel shoppingCartLbl = new JLabel("");
		ShoppingList currentList = ((CustomerAccount) Database.getAccDetails(user)).getShoppingListFromStore(storeid);
		List<String> displayList = new ArrayList<String>();
		String itemDescription = null;
		for (Entry<String, Integer> entry : currentList.getList().entrySet()) {
			if (Database.getStoreById(storeid).getItems().get(entry.getKey()) != null) {
				itemDescription = Database.getStoreById(storeid).getItems().get(entry.getKey()).name;
				itemDescription += " - ";
				itemDescription += String.valueOf(entry.getValue());
				displayList.add(itemDescription);
			}
		}
		if (displayList.size() > 0) {
			shoppingCartLbl.setText(Arrays.toString(displayList.toArray(new String[0])));
		} else {
			shoppingCartLbl.setText("Shopping cart is empty");
		}

		JLabel lblNewLabel_3_3_1 = new JLabel("Suggested Items");
		lblNewLabel_3_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_3_1.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_3_3_1 = new GridBagConstraints();
		gbc_lblNewLabel_3_3_1.gridwidth = 7;
		gbc_lblNewLabel_3_3_1.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_3_3_1.gridx = 8;
		gbc_lblNewLabel_3_3_1.gridy = 0;
		add(lblNewLabel_3_3_1, gbc_lblNewLabel_3_3_1);
		shoppingCartLbl.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		GridBagConstraints gbc_shoppingCartLbl = new GridBagConstraints();
		gbc_shoppingCartLbl.gridheight = 4;
		gbc_shoppingCartLbl.gridwidth = 2;
		gbc_shoppingCartLbl.insets = new Insets(0, 0, 5, 5);
		gbc_shoppingCartLbl.gridx = 6;
		gbc_shoppingCartLbl.gridy = 1;
		add(shoppingCartLbl, gbc_shoppingCartLbl);

		JLabel suggestedItems = new JLabel("");
		if (Database.getStoreById(storeid).getSuggestedItemList().size() > 0) {
			suggestedItems.setText(Database.getStoreById(storeid).getSuggestedItemList().toString());
		} else {
			suggestedItems.setText("No suggested items currently");
		}
//		if (Database.generateSuggestedList(storeid, user).size() > 0) {
//			suggestedItems.setText(Database.generateSuggestedList(storeid, user).toString());
//		} else {
//			suggestedItems.setText("No suggested items currently");
//		}
		suggestedItems.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		GridBagConstraints gbc_suggestedItems = new GridBagConstraints();
		gbc_suggestedItems.gridheight = 4;
		gbc_suggestedItems.gridwidth = 7;
		gbc_suggestedItems.insets = new Insets(0, 0, 5, 0);
		gbc_suggestedItems.gridx = 8;
		gbc_suggestedItems.gridy = 1;
		add(suggestedItems, gbc_suggestedItems);

		JLabel lblNewLabel_2 = new JLabel("Current Items");
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Arial Narrow", Font.BOLD, 50));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.gridheight = 2;
		gbc_lblNewLabel_2.gridwidth = 6;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 0;
		gbc_lblNewLabel_2.gridy = 3;
		add(lblNewLabel_2, gbc_lblNewLabel_2);

		JScrollPane scrollPane = new JScrollPane(existingItems, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setEnabled(false);
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.insets = new Insets(5, 5, 0, 5);
		gbc_scrollPane.gridwidth = 7;
		gbc_scrollPane.gridheight = 15;
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 5;
		add(scrollPane, gbc_scrollPane);

		JLabel lblNewLabel_3 = new JLabel("Opening Time");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.gridwidth = 3;
		gbc_lblNewLabel_3.insets = new Insets(0, 5, 5, 5);
		gbc_lblNewLabel_3.gridx = 7;
		gbc_lblNewLabel_3.gridy = 5;
		add(lblNewLabel_3, gbc_lblNewLabel_3);

		JLabel lblNewLabel_3_1 = new JLabel("Closing Time");
		lblNewLabel_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_3_1 = new GridBagConstraints();
		gbc_lblNewLabel_3_1.gridwidth = 4;
		gbc_lblNewLabel_3_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3_1.gridx = 10;
		gbc_lblNewLabel_3_1.gridy = 5;
		add(lblNewLabel_3_1, gbc_lblNewLabel_3_1);

		JLabel currentOpenTime = new JLabel("");
		currentOpenTime.setText(Database.getStoreById(storeid).getOpentime());
		currentOpenTime.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_currentOpenTime = new GridBagConstraints();
		gbc_currentOpenTime.gridwidth = 3;
		gbc_currentOpenTime.insets = new Insets(0, 0, 5, 5);
		gbc_currentOpenTime.gridx = 7;
		gbc_currentOpenTime.gridy = 6;
		add(currentOpenTime, gbc_currentOpenTime);

		JLabel currentCloseTime = new JLabel("");
		currentCloseTime.setText(Database.getStoreById(storeid).getClosingtime());
		currentCloseTime.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_currentCloseTime = new GridBagConstraints();
		gbc_currentCloseTime.gridwidth = 4;
		gbc_currentCloseTime.insets = new Insets(0, 0, 5, 5);
		gbc_currentCloseTime.gridx = 10;
		gbc_currentCloseTime.gridy = 6;
		add(currentCloseTime, gbc_currentCloseTime);

		JLabel lblNewLabel_4_2 = new JLabel("Current Sale Items");
		lblNewLabel_4_2.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel_4_2 = new GridBagConstraints();
		gbc_lblNewLabel_4_2.gridwidth = 8;
		gbc_lblNewLabel_4_2.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_4_2.gridx = 7;
		gbc_lblNewLabel_4_2.gridy = 7;
		add(lblNewLabel_4_2, gbc_lblNewLabel_4_2);

		JLabel currentSaleItems = new JLabel("");
		currentSaleItems.setText(Database.getStoreById(storeid).showCustomerSaleItems());
		currentSaleItems.setBorder(BorderFactory.createLineBorder(Color.black));
		currentSaleItems.setHorizontalAlignment(SwingConstants.CENTER);
		currentSaleItems.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_currentSaleItems = new GridBagConstraints();
		gbc_currentSaleItems.gridheight = 3;
		gbc_currentSaleItems.gridwidth = 7;
		gbc_currentSaleItems.insets = new Insets(5, 0, 5, 5);
		gbc_currentSaleItems.gridx = 7;
		gbc_currentSaleItems.gridy = 8;
		add(currentSaleItems, gbc_currentSaleItems);

		setPreferredSize(new Dimension(1500, 700));

		JLabel lblNewLabel_3_2_1 = new JLabel("Search Items");
		lblNewLabel_3_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_2_1.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_3_2_1 = new GridBagConstraints();
		gbc_lblNewLabel_3_2_1.gridwidth = 7;
		gbc_lblNewLabel_3_2_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3_2_1.gridx = 7;
		gbc_lblNewLabel_3_2_1.gridy = 11;
		add(lblNewLabel_3_2_1, gbc_lblNewLabel_3_2_1);

		JComboBox<String> comboBox = new JComboBox<String>();
		Database.getStoreById(storeid).getCategoryItems();
		for (Entry<String, Set<Item>> entry : Database.getStoreById(storeid).getCategoryItems().entrySet()) {
			comboBox.addItem(entry.getKey());
		}
		GridBagConstraints gbc_comboBox = new GridBagConstraints();
		gbc_comboBox.gridwidth = 2;
		gbc_comboBox.insets = new Insets(0, 70, 5, 50);
		gbc_comboBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_comboBox.gridx = 7;
		gbc_comboBox.gridy = 12;
		add(comboBox, gbc_comboBox);

		searchByName = new JTextField();
		GridBagConstraints gbc_searchByName = new GridBagConstraints();
		gbc_searchByName.gridwidth = 4;
		gbc_searchByName.insets = new Insets(0, 50, 5, 50);
		gbc_searchByName.fill = GridBagConstraints.HORIZONTAL;
		gbc_searchByName.gridx = 10;
		gbc_searchByName.gridy = 12;
		add(searchByName, gbc_searchByName);
		searchByName.setColumns(10);

		JButton btnSearchByCat = new JButton("Search By Category");
		btnSearchByCat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String categorySelected = comboBox.getSelectedItem().toString();
				// dropped down menu for the items in that category to be chosen to take them to
				// the view item page
				String[] options;
				Set<Item> catItems = Database.getStoreById(storeid).getCategoryItems().get(categorySelected);
				if (catItems.size() > 0) {
					int i = 0;
					options = new String[catItems.size()];
					Iterator<Item> itemIterator = catItems.iterator();
					while (itemIterator.hasNext()) {
						options[i] = itemIterator.next().name;
						i++;
					}
					String getItemFromCategory = (String) JOptionPane.showInputDialog(null,
							"What item would like to interact with?", "Choose item from category",
							JOptionPane.QUESTION_MESSAGE, null, options, null);
					String wantedItemId = null;
					for (Entry<String, Item> entry : Database.getStoreById(storeid).getItems().entrySet()) {
						if (entry.getValue().name.equals(getItemFromCategory)) {
							wantedItemId = entry.getKey();
						}
					}
					// open up view item page
					if (getItemFromCategory != null) {
						JFrame parentFrame = (JFrame) parent;
						parentFrame.getContentPane().removeAll();
						ViewItem viewItem = new ViewItem(user, storeid, wantedItemId, parent);
						parentFrame.getContentPane().add(viewItem);
						parentFrame.pack();
						parentFrame.getContentPane().revalidate();
						parentFrame.getContentPane().repaint();
					}
				} else {
					JOptionPane.showMessageDialog(null, "Category doesn't have any items currently...");
				}
//				if (Database.generateSuggestedList(storeid, user).size() > 0) {
//					suggestedItems.setText(Database.generateSuggestedList(storeid, user).toString());
//				} else {
//					suggestedItems.setText("No suggested items currently");
//				}
				Database.getStoreById(storeid).setSuggestedItemList(Database.generateSuggestedList(storeid, user));
				Database.saveStoreData();
				if (Database.getStoreById(storeid).getSuggestedItemList().size() > 0) {
					suggestedItems.setText(Database.getStoreById(storeid).getSuggestedItemList().toString());
				} else {
					suggestedItems.setText("No suggested items currently");
				}
			}
		});
		btnSearchByCat.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		btnSearchByCat.setEnabled(true);
		GridBagConstraints gbc_btnSearchByCat = new GridBagConstraints();
		gbc_btnSearchByCat.gridwidth = 3;
		gbc_btnSearchByCat.insets = new Insets(0, 0, 5, 5);
		gbc_btnSearchByCat.gridx = 7;
		gbc_btnSearchByCat.gridy = 14;
		add(btnSearchByCat, gbc_btnSearchByCat);

		JButton btnSearchByName = new JButton("Search By Name");
		btnSearchByName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nameSearch = searchByName.getText();
				if (!nameSearch.isBlank()) {
					if (!Database.getStoreById(storeid).getItemsByName().contains(nameSearch)) {
						// pop up that item does not exist
						JOptionPane.showMessageDialog(null, "Search item does not exist in this store...");
					} else {
						String wantedItemId = null;
						for (Entry<String, Item> entry : Database.getStoreById(storeid).getItems().entrySet()) {
							if (entry.getValue().name.equals(nameSearch)) {
								wantedItemId = entry.getKey();
							}
						}
						// open up view item page
						JFrame parentFrame = (JFrame) parent;
						parentFrame.getContentPane().removeAll();
						ViewItem viewItem = new ViewItem(user, storeid, wantedItemId, parent);
						parentFrame.getContentPane().add(viewItem);
						parentFrame.pack();
						parentFrame.getContentPane().revalidate();
						parentFrame.getContentPane().repaint();
					}
				}
//				if (Database.generateSuggestedList(storeid, user).size() > 0) {
//					suggestedItems.setText(Database.generateSuggestedList(storeid, user).toString());
//				} else {
//					suggestedItems.setText("No suggested items currently");
//				}
				Database.getStoreById(storeid).setSuggestedItemList(Database.generateSuggestedList(storeid, user));
				Database.saveStoreData();
				if (Database.getStoreById(storeid).getSuggestedItemList().size() > 0) {
					suggestedItems.setText(Database.getStoreById(storeid).getSuggestedItemList().toString());
				} else {
					suggestedItems.setText("No suggested items currently");
				}
			}
		});
		btnSearchByName.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		btnSearchByName.setEnabled(true);
		GridBagConstraints gbc_btnSearchByName = new GridBagConstraints();
		gbc_btnSearchByName.gridwidth = 4;
		gbc_btnSearchByName.insets = new Insets(0, 0, 5, 5);
		gbc_btnSearchByName.gridx = 10;
		gbc_btnSearchByName.gridy = 14;
		add(btnSearchByName, gbc_btnSearchByName);

		JTextArea textArea = new JTextArea();
		textArea.setWrapStyleWord(true);
		textArea.setEditable(false);
		textArea.setFont(new Font("Arial Narrow", Font.BOLD, 20));
		textArea.setLineWrap(true);
		textArea.setText("Please use the \"Get Shopping Order\" to optimize your shopping experience");
		GridBagConstraints gbc_textArea = new GridBagConstraints();
		gbc_textArea.fill = GridBagConstraints.BOTH;
		gbc_textArea.gridheight = 2;
		gbc_textArea.gridwidth = 7;
		gbc_textArea.insets = new Insets(0, 0, 5, 5);
		gbc_textArea.gridx = 8;
		gbc_textArea.gridy = 17;
		add(textArea, gbc_textArea);

		JButton btnGetShoppingOrder = new JButton("Get Shopping Order");
		btnGetShoppingOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				List<String> shoppingOrderForThisVisit = Database.generateShoppingOrder(user, storeid);
				textArea.setText("The order to get your items is: " + shoppingOrderForThisVisit.toString() + " based "
						+ "on store layout and item counts.");
			}
		});
		btnGetShoppingOrder.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		btnGetShoppingOrder.setEnabled(true);
		GridBagConstraints gbc_btnGetShoppingOrder = new GridBagConstraints();
		gbc_btnGetShoppingOrder.gridwidth = 4;
		gbc_btnGetShoppingOrder.insets = new Insets(0, 0, 5, 5);
		gbc_btnGetShoppingOrder.gridx = 10;
		gbc_btnGetShoppingOrder.gridy = 15;
		add(btnGetShoppingOrder, gbc_btnGetShoppingOrder);

		JLabel lblNewLabel_3_2 = new JLabel("Save/Unsave Store");
		lblNewLabel_3_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_2.setFont(new Font("Arial Narrow", Font.BOLD, 30));
		GridBagConstraints gbc_lblNewLabel_3_2 = new GridBagConstraints();
		gbc_lblNewLabel_3_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3_2.gridx = 7;
		gbc_lblNewLabel_3_2.gridy = 16;
		add(lblNewLabel_3_2, gbc_lblNewLabel_3_2);

		btnSaveStore = new JButton("Save Store");
		if (storeAlreadySaved(Database.getCurrentUser().getIdentifier(), storeid)) {
			btnSaveStore.setEnabled(false);
		} else {
			btnSaveStore.setEnabled(true);
		}
		btnSaveStore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((CustomerAccount) Database.getAccDetails(user)).addSavedStore(Database.getStoreById(storeid));
				Database.saveAccMapData();
				JOptionPane.showMessageDialog(null, "Store has been saved");
				btnSaveStore.setEnabled(false);
				btnUnsaveStore.setEnabled(true);
			}
		});

		btnSaveStore.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_btnSaveStore = new GridBagConstraints();
		gbc_btnSaveStore.insets = new Insets(0, 0, 5, 5);
		gbc_btnSaveStore.gridx = 7;
		gbc_btnSaveStore.gridy = 17;
		add(btnSaveStore, gbc_btnSaveStore);

		btnUnsaveStore = new JButton("Unsave Store");
		if (storeAlreadySaved(Database.getCurrentUser().getIdentifier(), storeid)) {
			btnUnsaveStore.setEnabled(true);
		} else {
			btnUnsaveStore.setEnabled(false);
		}
		btnUnsaveStore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((CustomerAccount) Database.getAccDetails(user)).removeSavedStore(Database.getStoreById(storeid));
				Database.saveAccMapData();
				JOptionPane.showMessageDialog(null, "Store has been unsaved");
				btnUnsaveStore.setEnabled(false);
				btnSaveStore.setEnabled(true);
			}
		});

		btnUnsaveStore.setFont(new Font("Arial Narrow", Font.BOLD, 25));
		GridBagConstraints gbc_btnUnsaveStore = new GridBagConstraints();
		gbc_btnUnsaveStore.insets = new Insets(0, 0, 5, 5);
		gbc_btnUnsaveStore.gridx = 7;
		gbc_btnUnsaveStore.gridy = 18;
		add(btnUnsaveStore, gbc_btnUnsaveStore);
	}

	public JTable createNewTable(String storeid) {
		Database.loadStoreData();
		Map<String, Item> currentItems = Database.getStoreById(storeid).getItems();
		Map<Item, Integer> currentInv = Database.getStoreById(storeid).getInv();
		boolean itemsExist = false;
		int size = currentItems.size();
		String[][] actualData = new String[size][4];
		int index = 0;
		if (currentItems.size() > 0) {
			itemsExist = true;
			for (Map.Entry<String, Item> pair : currentItems.entrySet()) {
				actualData[index][0] = pair.getValue().name;
				actualData[index][1] = String.valueOf(pair.getValue().price);
				actualData[index][2] = String.valueOf(currentInv.get(pair.getValue()));
				actualData[index][3] = pair.getValue().category;
				index++;
			}
		}

		String[][] emptyData = new String[1][4];
		emptyData[0][0] = "N/A (Empty)";
		emptyData[0][1] = "N/A (Empty)";
		emptyData[0][2] = "N/A (Empty)";
		emptyData[0][3] = "N/A (Empty)";

		String[] headers = { "Name", "Price", "Quantity", "Category" };
		if (itemsExist) {
			existingItems = new JTable(actualData, headers);
		} else {
			existingItems = new JTable(emptyData, headers);
		}
		existingItems.getTableHeader().setReorderingAllowed(false);
		existingItems.getTableHeader().setFont(new Font("Arial Narrow", Font.BOLD, 20));
		existingItems.getTableHeader().setResizingAllowed(false);
		existingItems.setEnabled(false);
		existingItems.setFont(new Font("Arial Narrow", Font.BOLD, 15));
		return existingItems;
	}

	public boolean storeAlreadySaved(String user, String storeid) {
		CustomerAccount userAcc = (CustomerAccount) Database.getAccDetails(user);
		if (userAcc.getSavedStoreIds() != null && userAcc.getSavedStoreIds().size() > 0) {
			if (userAcc.getSavedStoreIds().contains(storeid)) {
				return true;
			}
		}
		return false;
	}

}
